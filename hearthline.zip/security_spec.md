# HEARTHLINE Security Specification & Dirty Dozen TDD

## 1. Core Data & Phase 6–7 Invariants
1. **PII Isolation**: User emails, phones, and consent flags live strictly in `usersPrivate/{uid}` and are readable only by `uid` or verified Admins. `users/{uid}` contains zero PII.
2. **Privilege Escalation Block**: Users creating or editing `users/{uid}` cannot assign `role: 'admin' | 'super_admin' | 'moderator'` or modify `creatorMonetizationStatus`.
3. **40/60 Page Owner-Only Financial Invariant**: `pageWallets/{pageId}` and `pageLedgerEntries/{entryId}` can ONLY be read by the verified `ownerUid` (whose `uid == page.ownerUid`) or Admin. Page Admins, Editors, and Moderators are strictly denied access to `pageWallets` and `withdrawalRequests` for `walletType: 'page'`.
4. **No Client-Side Financial Forgery**: Clients cannot create or alter `pageWallets`, `wallets`, `pageLedgerEntries`, `ledgerEntries`, `platformSettings`, or approve their own `adCampaigns`, `adPayments`, `withdrawalRequests`, or `pageMonetizationApplications`. Only verified Admin/Super Admin roles can execute financial credits, settlement calculations, and payout approvals.
5. **Confirmed Friendship Messaging Gate**: Direct `conversations` (`type: 'direct'`) require an existing `friendships/{friendshipId}` document linking both participants.
6. **Temporal Integrity & Path Hardening**: Every document ID path variable is validated with `isValidId()` and timestamps enforce `request.time`.
7. **Safe External & Media URL Enforcement**: Outbound links (`posts.linkUrl`, `adCampaigns.targetUrl`) must match `^https?://` (`isSafeOptionalHttpUrl`) and chat media (`messages.mediaUrl`) must match `^(https?://|/src/assets/)` (`isSafeOptionalMediaUrl`). All client renders pass through `sanitizeExternalUrl()` before `<a href>` or `window.open()`.
8. **Bounded Cross-User Counters & Boost Integrity**: Cross-user counter updates on `users`, `posts`, `sparkVideos`, and `communities` are constrained via `isCounterStep` (`[-1, +1]`). Post boost updates require `isBoosted == true` and a valid `boostCampaignId`.
9. **Ad Payment Verification & Single-Event Delivery Accounting**:
   - Advertisers cannot transition an unpaid campaign to `active` (`status != 'active' || (existing().status == 'paused' && existing().paymentStatus == 'verified')`).
   - Re-submission from `draft` or `rejected` sets `status == 'pending_review'` and `paymentStatus == 'pending_verification'`.
   - `adPayments` creation verifies post-batch campaign ownership (`existsAfter` + `getAfter(...).advertiserUid == request.auth.uid`).
   - `adEvents` creation enforces deterministic deduplicated IDs (`^adevt_<campaignId>_<uid>_<eventType>_[0-9]{8}$`) paired with an active, verified campaign update bounded to exactly one event (`paidImpressions + clicks + videoViews == 1`), `spentPoisha <= existing().spentPoisha + 150`, and automatic `completed` transition only when `spentPoisha >= lifetimeBudgetPoisha`.
10. **Page Admin vs Page Owner Scope (Multi-Role Separation)**:
    - Page Admins (`pages/{pageId}/admins/{uid}` with `role in ['owner', 'admin']`) may create `page_promotion` campaigns and manage/boost Page content (`isPageAdminOrOwner`).
    - Page Admins are strictly blocked from reading `pageWallets`, `pageLedgerEntries`, or submitting `page` `withdrawalRequests`, which remain exclusive to `ownerUid` (`isPageOwner`).

## 2. The "Dirty Dozen" + Phase 6–7 Adversarial Payloads
1. **Self-Assigned Super Admin**: `users/{uid}` create with `{ role: 'super_admin' }` -> `PERMISSION_DENIED`.
2. **Ghost Field Shadow Update**: `posts/{postId}` update injecting `{ isBoosted: true, shadowFlag: true }` -> `PERMISSION_DENIED`.
3. **Page Admin Stealing Page Earnings**: Page Admin (non-owner) reading `pageWallets/{pageId}` or creating `withdrawalRequests` with `walletType: 'page'` -> `PERMISSION_DENIED`.
4. **Fake Wallet Credit**: User updating `wallets/{uid}` with `{ availablePoisha: 9999999 }` -> `PERMISSION_DENIED`.
5. **Self-Approving Ad Campaign**: Advertiser updating `adCampaigns/{id}` to `{ status: 'active', paymentStatus: 'verified' }` -> `PERMISSION_DENIED`.
6. **PII Scrape**: User A calling `get` or `list` on `usersPrivate/{userB}` -> `PERMISSION_DENIED`.
7. **Unauthorized Direct Chat**: User A creating a direct `conversations` doc with User B without a confirmed `friendships` record -> `PERMISSION_DENIED`.
8. **Spoofed Authorship**: User A creating `posts/{id}` with `{ authorUid: userB }` -> `PERMISSION_DENIED`.
9. **Altering Immutable Ledger**: Anyone calling `update` or `delete` on `pageLedgerEntries/{id}` or `ledgerEntries/{id}` -> `PERMISSION_DENIED`.
10. **Non-Super-Admin Changing 40/60 Split**: Regular Admin or User updating `platformSettings/global` -> `PERMISSION_DENIED`.
11. **ID Poisoning**: Creating a document with an oversized or non-alphanumeric ID (>128 chars or containing slashes/spaces) -> `PERMISSION_DENIED`.
12. **Email Spoofing Admin Bypass**: Signed-in user with unverified email claiming admin access -> `PERMISSION_DENIED`.
13. **Unsafe Protocol Injection**: Creating/updating `adCampaigns.targetUrl` or `posts.linkUrl` with `javascript:alert(1)` -> `PERMISSION_DENIED`.
14. **Counter & Ad Spend Inflation**: Cross-user update incrementing `likesCount` by `+500` or `adCampaigns.spentPoisha` by `+99999` in one write -> `PERMISSION_DENIED`.
15. **Non-Deterministic Ad Event Flooding**: Creating `adEvents/{randomId}` bypassing `adevt_<campaignId>_<uid>_<eventType>_YYYYMMDD` -> `PERMISSION_DENIED`.
