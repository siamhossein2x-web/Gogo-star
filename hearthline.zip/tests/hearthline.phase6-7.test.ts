import { describe, expect, test } from 'bun:test';
import fs from 'fs';
import path from 'path';
import { sanitizeExternalUrl, isValidHttpUrl } from '../src/lib/url';
import {
  bdtToPoisha,
  calculatePageRevenueSplit,
  DEFAULT_PAGE_OWNER_BPS,
  DEFAULT_PLATFORM_BPS,
  formatBDT,
  formatCompactNumber,
} from '../src/lib/finance';
import { dirtyDozenPayloads } from '../firestore.rules.test';

const rootDir = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const readFile = (rel: string) => fs.readFileSync(path.join(rootDir, rel), 'utf8');

describe('HEARTHLINE Security — External URL Sanitization & XSS Prevention', () => {
  test('accepts safe https:// and http:// URLs and normalizes them', () => {
    expect(sanitizeExternalUrl('https://hearthline.social/promo?utm=1')).toBe(
      'https://hearthline.social/promo?utm=1'
    );
    expect(sanitizeExternalUrl('  http://example.com/offer  ')).toBe('http://example.com/offer');
    expect(isValidHttpUrl('https://cdn.example.com/page')).toBe(true);
  });

  test('blocks javascript:, data:, vbscript:, file:, and malformed schemes', () => {
    const payloads = [
      'javascript:alert(document.domain)',
      '  JaVaScRiPt:alert(1)',
      'data:text/html,<script>alert(1)</script>',
      'vbscript:msgbox(1)',
      'file:///etc/passwd',
      '//evil.example/redirect',
      '/relative/path',
      '',
      null,
      undefined,
    ];
    for (const p of payloads) {
      expect(sanitizeExternalUrl(p)).toBeNull();
      expect(isValidHttpUrl(p)).toBe(false);
    }
  });
});

describe('HEARTHLINE Phase 5 & 6 — Integer Poisha Accounting & Mandatory 40/60 Split', () => {
  test('converts BDT to integer Poisha cleanly with no floating drift', () => {
    expect(bdtToPoisha(100)).toBe(10000);
    expect(bdtToPoisha(19.99)).toBe(1999);
    expect(bdtToPoisha(-50)).toBe(0);
    expect(bdtToPoisha(Number.NaN)).toBe(0);
    expect(formatBDT(50000)).toBe('৳500.00');
    expect(formatCompactNumber(15400)).toBe('15.4K');
    expect(formatCompactNumber(2500000)).toBe('2.5M');
  });

  test('enforces exact 40/60 Page Owner vs Platform split after verified deductions', () => {
    const res = calculatePageRevenueSplit(100000, 10000, DEFAULT_PAGE_OWNER_BPS, DEFAULT_PLATFORM_BPS);
    expect(res.grossPoisha).toBe(100000);
    expect(res.deductionsPoisha).toBe(10000);
    expect(res.eligibleNetPoisha).toBe(90000);
    expect(res.ownerSharePoisha).toBe(36000); // 40%
    expect(res.platformSharePoisha).toBe(54000); // 60%
    expect(res.ownerSharePoisha + res.platformSharePoisha).toBe(res.eligibleNetPoisha);
  });

  test('handles odd Poisha amounts without losing a single Poisha', () => {
    const res = calculatePageRevenueSplit(1003, 0, 4000, 6000);
    expect(res.ownerSharePoisha).toBe(401);
    expect(res.platformSharePoisha).toBe(602);
    expect(res.ownerSharePoisha + res.platformSharePoisha).toBe(1003);
  });

  test('clamps deductions exceeding gross revenue to zero eligible net and rejects invalid bps', () => {
    const zeroNet = calculatePageRevenueSplit(5000, 12000);
    expect(zeroNet.eligibleNetPoisha).toBe(0);
    expect(zeroNet.ownerSharePoisha).toBe(0);
    expect(zeroNet.platformSharePoisha).toBe(0);

    expect(() => calculatePageRevenueSplit(10000, 0, 5000, 4000)).toThrow(
      /must sum to 10000/i
    );
  });
});

describe('HEARTHLINE Phase 6 — Ad Delivery, Budget Cap, Deterministic Event IDs & Analytics', () => {
  test('generates non-truncated deterministic daily dedup adEvent IDs matching Firestore regex', () => {
    const longCampaignId = 'camp_' + 'a'.repeat(80);
    const longUid = 'uid_' + 'z'.repeat(80);
    const eventType = 'video_view';
    const dayKey = '20261125';

    const cleanCamp = longCampaignId.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 48);
    const cleanUid = longUid.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 48);
    const eventId = `adevt_${cleanCamp}_${cleanUid}_${eventType}_${dayKey}`;

    expect(eventId.length).toBeLessThanOrEqual(128);
    expect(eventId.endsWith(`_${dayKey}`)).toBe(true);
    expect(eventId).toMatch(/^adevt_[a-zA-Z0-9_-]+_[a-zA-Z0-9_-]+_(impression|click|video_view)_[0-9]{8}$/);
  });

  test('evaluates deliverable campaign filters (active + verified + budget + date window + targeting)', () => {
    const today = new Date().toISOString().slice(0, 10);
    const isDeliverable = (
      ad: {
        status: string;
        paymentStatus: string;
        spentPoisha: number;
        lifetimeBudgetPoisha: number;
        startDate?: string;
        endDate?: string;
        targetCountry?: string;
        targetLanguage?: string;
      },
      viewerCountry: string,
      viewerLang: string
    ) => {
      if (ad.status !== 'active' || ad.paymentStatus !== 'verified') return false;
      if (ad.spentPoisha >= ad.lifetimeBudgetPoisha) return false;
      if (ad.startDate && ad.startDate > today) return false;
      if (ad.endDate && ad.endDate < today) return false;
      const cTarget = (ad.targetCountry || 'Bangladesh').toLowerCase();
      if (cTarget && cTarget !== 'all' && cTarget !== 'global' && viewerCountry.toLowerCase() !== cTarget) {
        return false;
      }
      const lTarget = (ad.targetLanguage || 'all').toLowerCase();
      if (lTarget && lTarget !== 'all' && viewerLang.toLowerCase() !== lTarget) return false;
      return true;
    };

    const validAd = {
      status: 'active',
      paymentStatus: 'verified',
      spentPoisha: 5000,
      lifetimeBudgetPoisha: 50000,
      startDate: '2026-01-01',
      endDate: '2099-12-31',
      targetCountry: 'Bangladesh',
      targetLanguage: 'en',
    };

    expect(isDeliverable(validAd, 'Bangladesh', 'en')).toBe(true);
    expect(isDeliverable({ ...validAd, paymentStatus: 'pending_verification' }, 'Bangladesh', 'en')).toBe(false);
    expect(isDeliverable({ ...validAd, status: 'paused' }, 'Bangladesh', 'en')).toBe(false);
    expect(isDeliverable({ ...validAd, spentPoisha: 50000 }, 'Bangladesh', 'en')).toBe(false);
    expect(isDeliverable({ ...validAd, startDate: '2099-01-01' }, 'Bangladesh', 'en')).toBe(false);
    expect(isDeliverable({ ...validAd, endDate: '2020-01-01' }, 'Bangladesh', 'en')).toBe(false);
    expect(isDeliverable(validAd, 'India', 'en')).toBe(false);
    expect(isDeliverable(validAd, 'Bangladesh', 'bn')).toBe(false);
  });

  test('computes Ad Analytics CTR, Avg CPC, and CPM accurately', () => {
    const computeMetrics = (impressions: number, clicks: number, spentPoisha: number) => {
      const ctr = impressions > 0 ? Number(((clicks / impressions) * 100).toFixed(2)) : 0;
      const avgCpcPoisha = clicks > 0 ? Math.round(spentPoisha / clicks) : 0;
      const cpmPoisha = impressions > 0 ? Math.round((spentPoisha / impressions) * 1000) : 0;
      return { ctr, avgCpcPoisha, cpmPoisha };
    };

    const m = computeMetrics(2500, 75, 16250);
    expect(m.ctr).toBe(3);
    expect(m.avgCpcPoisha).toBe(217);
    expect(m.cpmPoisha).toBe(6500);
    expect(computeMetrics(0, 0, 0)).toEqual({ ctr: 0, avgCpcPoisha: 0, cpmPoisha: 0 });
  });
});

describe('HEARTHLINE Multi-Role RBAC & Firestore Rules Verification (2 Users, Page Owner, Page Admin, Admin)', () => {
  const rules = readFile('firestore.rules');
  const draftRules = readFile('DRAFT_firestore.rules');

  test('firestore.rules and DRAFT_firestore.rules are byte-for-byte in sync', () => {
    expect(rules).toBe(draftRules);
  });

  test('covers all 16 Dirty Dozen + Phase 6/7 adversarial scenarios in firestore.rules.test.ts', () => {
    expect(dirtyDozenPayloads.length).toBeGreaterThanOrEqual(16);
    for (const item of dirtyDozenPayloads) {
      expect(item.expected).toBe('PERMISSION_DENIED');
    }
  });

  test('User A vs User B: isolates PII, enforces friendship gate for DMs, bounds counter deltas & boost flags', () => {
    expect(rules).toContain('match /usersPrivate/{uid}');
    expect(rules).toContain('allow get: if isValidId(uid) && (isOwner(uid) || isAdmin());');
    expect(rules).toContain('isFriendshipValidForDirect(');
    expect(rules).toContain('function isCounterStep(incVal, exVal)');
    expect(rules).toContain('incVal >= exVal - 1 && incVal <= exVal + 1');
    expect(rules).toContain("incoming().isBoosted == true");
    expect(rules).toContain("('boostCampaignId' in incoming()) && isValidId(incoming().boostCampaignId)");
  });

  test('Page Owner vs Page Admin: Page Admin can promote Page; Page Owner holds exclusive access to 40/60 Page Wallet & Withdrawals', () => {
    // Page Admin allowed to launch page_promotion adCampaigns and edit Page posts
    expect(rules).toContain("incoming().sourceType == 'page_promotion' && ('pageId' in incoming()) && isPageAdminOrOwner(incoming().pageId)");
    expect(rules).toContain("existing().authorType == 'page' && ('pageId' in existing()) && isPageAdminOrOwner(existing().pageId)");

    // Page Owner Wallet & Withdrawal Requests strictly check isPageOwner (NOT isPageAdminOrOwner / isPageStaff)
    const pageWalletBlock = rules.slice(
      rules.indexOf('match /pageWallets/{pageId}'),
      rules.indexOf('match /pageLedgerEntries/{entryId}')
    );
    expect(pageWalletBlock).toContain('isPageOwner(pageId)');
    expect(pageWalletBlock).not.toContain('isPageAdminOrOwner');
    expect(pageWalletBlock).not.toContain('isPageStaff');

    const withdrawalBlock = rules.slice(
      rules.indexOf('match /withdrawalRequests/{reqId}'),
      rules.indexOf('match /creatorMonetizationApplications/{appId}')
    );
    expect(withdrawalBlock).toContain("incoming().walletType == 'page'");
    expect(withdrawalBlock).toContain('isPageOwner(incoming().pageId)');
    expect(withdrawalBlock).not.toContain('isPageAdminOrOwner');
  });

  test('Admin & Super Admin: governs Ad verification, delivery spend caps, payment linkage, moderation & platformSettings', () => {
    const adBlock = rules.slice(
      rules.indexOf('match /adCampaigns/{campaignId}'),
      rules.indexOf('match /adPayments/{paymentId}')
    );
    expect(adBlock).toContain("incoming().status != 'active' || (existing().status == 'paused' && existing().paymentStatus == 'verified')");
    expect(adBlock).toContain("((incoming().paidImpressions - existing().paidImpressions) + (incoming().clicks - existing().clicks) + (incoming().videoViews - existing().videoViews)) == 1");
    expect(adBlock).toContain('incoming().spentPoisha <= existing().spentPoisha + 150');
    expect(adBlock).toContain("incoming().status == 'completed' && incoming().spentPoisha >= existing().lifetimeBudgetPoisha");

    const adPaymentBlock = rules.slice(
      rules.indexOf('match /adPayments/{paymentId}'),
      rules.indexOf('match /adEvents/{eventId}')
    );
    expect(adPaymentBlock).toContain('existsAfter(/databases/$(database)/documents/adCampaigns/$(incoming().campaignId))');
    expect(adPaymentBlock).toContain('getAfter(/databases/$(database)/documents/adCampaigns/$(incoming().campaignId)).data.advertiserUid == request.auth.uid');

    const adEventBlock = rules.slice(
      rules.indexOf('match /adEvents/{eventId}'),
      rules.indexOf('// Communities + Members')
    );
    expect(adEventBlock).toContain("eventId.matches('^adevt_' + incoming().campaignId + '_' + request.auth.uid + '_' + incoming().eventType + '_[0-9]{8}$')");

    // Super Admin exclusivity for 40/60 settings & admin registry
    expect(rules).toContain('allow update: if isSuperAdmin() && isValidId(settingId) && isValidPlatformSettings(incoming())');
    expect(rules).toContain('allow update: if isSuperAdmin() && isValidId(uid) && isValidAdminRole(incoming())');
  });

  test('URL safety enforced in both Firestore Rules and frontend renderers (no raw targetUrl/linkUrl/mediaUrl opens)', () => {
    expect(rules).toContain('function isSafeOptionalHttpUrl(data, key, maxLen)');
    expect(rules).toContain('function isSafeOptionalMediaUrl(data, key, maxLen)');
    expect(readFile('src/components/PostCard.tsx')).toContain('sanitizeExternalUrl');
    expect(readFile('src/components/LayoutShell.tsx')).toContain('sanitizeExternalUrl');
    expect(readFile('src/components/MessagesView.tsx')).toContain('sanitizeExternalUrl');
    expect(readFile('src/components/AdsManagerView.tsx')).toContain('isValidHttpUrl');
    expect(readFile('src/components/AdminDashboardView.tsx')).toContain('sanitizeExternalUrl');
  });
});

describe('HEARTHLINE Phase 6 & 7 — UI Capabilities & Performance Optimization Checks', () => {
  test('AdsManagerView supports both Page Owners and Page Admins, Resubmit Payment modal, and CTR/CPC/CPM analytics', () => {
    const adsMgr = readFile('src/components/AdsManagerView.tsx');
    expect(adsMgr).toContain("doc(db, 'pages', pg.id, 'admins', firebaseUser.uid)");
    expect(adsMgr).toContain('Resubmit Payment');
    expect(adsMgr).toContain('>CTR<');
    expect(adsMgr).toContain('Avg CPC');
    expect(adsMgr).toContain('CPM');
  });

  test('AdminDashboardView exposes Ad KPIs, Ad Reviews notes/resume, and direct Moderation removal', () => {
    const adminView = readFile('src/components/AdminDashboardView.tsx');
    expect(adminView).toContain('Active Ad Campaigns');
    expect(adminView).toContain('Verified Ad Spend');
    expect(adminView).toContain('Resume Ad');
    expect(adminView).toContain('Remove Content');
  });

  test('Performance optimization: React.lazy route splitting, Vite manualChunks, Spark N+1 fix, and lazy images', () => {
    const appCode = readFile('src/App.tsx');
    expect(appCode).toContain('lazy(');
    expect(appCode).toContain('<Suspense');

    const viteConfig = readFile('vite.config.ts');
    expect(viteConfig).toContain('manualChunks');
    expect(viteConfig).toContain('firebase');

    const sparkView = readFile('src/components/SparkView.tsx');
    expect(sparkView).toContain("where('targetType', '==', 'spark')");
    expect(sparkView).toContain('loadedUsersRef');

    const postCard = readFile('src/components/PostCard.tsx');
    expect(postCard).toContain('loading="lazy"');
  });
});

describe('HEARTHLINE Comprehensive Feature & Security Verification (All 14 Workflows)', () => {
  const rules = readFile('firestore.rules');

  test('1. Friend Request and acceptance: validates sender != recipient, pending status, and friendship creation', () => {
    expect(rules).toContain('match /friendRequests/{requestId}');
    expect(rules).toContain('data.fromUid != data.toUid');
    expect(rules).toContain("incoming().status == 'pending'");
    expect(rules).toContain("existing().toUid == request.auth.uid && incoming().status in ['accepted', 'rejected']");

    const socialCode = readFile('src/lib/socialActions.ts');
    expect(socialCode).toContain('export async function sendFriendRequest');
    expect(socialCode).toContain('export async function acceptFriendRequest');
    expect(socialCode).toContain("friendsCount: increment(1)");
  });

  test('2. Messaging between confirmed friends: direct chats strictly require valid confirmed friendship', () => {
    expect(rules).toContain('function isFriendshipValidForDirect(friendshipId, uidA, uidB)');
    expect(rules).toContain("incoming().type == 'direct' && incoming().participantUids.size() == 2 && ('friendshipId' in incoming()) && isFriendshipValidForDirect(incoming().friendshipId, incoming().participantUids[0], incoming().participantUids[1])");

    const socialCode = readFile('src/lib/socialActions.ts');
    expect(socialCode).toContain('export async function openOrCreateDirectConversation');
    expect(socialCode).toContain('One-to-one messaging is available only between confirmed friends.');
  });

  test('3. Group Chat: requires adminUids, group name, member roles and message authorization', () => {
    expect(rules).toContain("incoming().type == 'group' && incoming().participantUids.size() >= 2 && ('adminUids' in incoming()) && request.auth.uid in incoming().adminUids");
    expect(rules).toContain('match /members/{uid}');
    expect(rules).toContain('match /messages/{messageId}');
    expect(rules).toContain('isConversationMember(convId)');
    expect(rules).toContain('incoming().senderUid == request.auth.uid');
  });

  test('4. Post publishing: supports text, image, video, carousel, link with size & visibility validation', () => {
    expect(rules).toContain('function isValidPost(data)');
    expect(rules).toContain("data.postType in ['text', 'image', 'video', 'carousel', 'link', 'shared']");
    expect(rules).toContain("data.visibility in ['public', 'friends', 'only_me', 'community']");
    expect(rules).toContain('data.content is string && data.content.size() <= 5000');
    expect(rules).toContain('incoming().authorUid == request.auth.uid');
  });

  test('5. Image and video uploads: Cloudinary unsigned configuration and media type resolution', () => {
    const { resolveMediaTypeForUpload, getCloudinaryUploadEndpoints } = require('../src/lib/cloudinary');
    const imageFile = new File(['fake-image-bytes'], 'banner.jpg', { type: 'image/jpeg' });
    const videoFile = new File(['fake-video-bytes'], 'spark.mp4', { type: 'video/mp4' });

    expect(resolveMediaTypeForUpload(imageFile, 'auto')).toBe('image');
    expect(resolveMediaTypeForUpload(videoFile, 'auto')).toBe('video');

    const endpoints = getCloudinaryUploadEndpoints('cthyvvj7');
    expect(endpoints.image).toBe('https://api.cloudinary.com/v1_1/cthyvvj7/image/upload');
    expect(endpoints.video).toBe('https://api.cloudinary.com/v1_1/cthyvvj7/video/upload');
  });

  test('6. Page creation: enforces ownerUid, unique username reservation, zero initial followers, not_eligible', () => {
    expect(rules).toContain('match /pages/{pageId}');
    expect(rules).toContain('incoming().ownerUid == request.auth.uid');
    expect(rules).toContain('incoming().followersCount == 0');
    expect(rules).toContain("incoming().monetizationStatus == 'not_eligible'");
  });

  test('7. Page ownership: distinguishes Page Owner from Page Admin/Staff', () => {
    expect(rules).toContain('function isPageOwner(pageId)');
    expect(rules).toContain('function isPageAdminOrOwner(pageId)');
    expect(rules).toContain('function isPageStaff(pageId)');
    expect(rules).toContain("match /admins/{uid}");
  });

  test('8. Page Monetization calculations: enforces integer Poisha and zero drift', () => {
    const gross = 250000; // ৳2500.00
    const deductions = 12500; // ৳125.00
    const split = calculatePageRevenueSplit(gross, deductions, 4000, 6000);

    expect(split.eligibleNetPoisha).toBe(237500); // ৳2375.00
    expect(split.ownerSharePoisha).toBe(95000);   // ৳950.00 (40%)
    expect(split.platformSharePoisha).toBe(142500); // ৳1425.00 (60%)
    expect(split.ownerSharePoisha + split.platformSharePoisha).toBe(split.eligibleNetPoisha);
  });

  test('9. 40/60 revenue sharing: strictly applied to Page Owner Wallet via settlePageRevenue4060', () => {
    const socialCode = readFile('src/lib/socialActions.ts');
    expect(socialCode).toContain('export async function settlePageRevenue4060');
    expect(socialCode).toContain('calculatePageRevenueSplit(');
    expect(socialCode).toContain("totalOwner40Poisha: increment(split.ownerSharePoisha)");
    expect(socialCode).toContain("totalPlatform60Poisha: increment(split.platformSharePoisha)");
  });

  test('10. Page Owner-only earnings: pageWallets & page withdrawals are exclusive to verified Page Owner', () => {
    const pageWalletBlock = rules.slice(
      rules.indexOf('match /pageWallets/{pageId}'),
      rules.indexOf('match /pageLedgerEntries/{entryId}')
    );
    expect(pageWalletBlock).toContain('isPageOwner(pageId)');
    expect(pageWalletBlock).not.toContain('isPageAdminOrOwner');

    const wdBlock = rules.slice(
      rules.indexOf('match /withdrawalRequests/{reqId}'),
      rules.indexOf('match /creatorMonetizationApplications/{appId}')
    );
    expect(wdBlock).toContain("incoming().walletType == 'page'");
    expect(wdBlock).toContain('isPageOwner(incoming().pageId)');
  });

  test('11. User Boost Post: atomic batch creation with valid boostCampaignId and pending payment reference', () => {
    const boostCode = readFile('src/components/BoostPostModal.tsx');
    expect(boostCode).toContain('writeBatch(db)');
    expect(boostCode).toContain("sourceType: 'user_boost'");
    expect(boostCode).toContain("isBoosted: true");
    expect(boostCode).toContain("boostCampaignId: campaignId");
    expect(boostCode).toContain("status: 'pending_verification'");
  });

  test('12. Campaign approval and delivery: verified payment gate, single-event metric updates, and automatic budget completion', () => {
    expect(rules).toContain("existing().status == 'active'");
    expect(rules).toContain("existing().paymentStatus == 'verified'");
    expect(rules).toContain("((incoming().paidImpressions - existing().paidImpressions) + (incoming().clicks - existing().clicks) + (incoming().videoViews - existing().videoViews)) == 1");
    expect(rules).toContain("incoming().spentPoisha <= existing().spentPoisha + 150");
    expect(rules).toContain("incoming().status == 'completed' && incoming().spentPoisha >= existing().lifetimeBudgetPoisha");
  });

  test('13. Payment and withdrawal workflows: Manual Payment Verification V1 with transaction refs and admin status transitions', () => {
    const adsMgr = readFile('src/components/AdsManagerView.tsx');
    expect(adsMgr).toContain('Manual Payment Verification (V1)');
    expect(adsMgr).toContain('transactionRef');

    const adminCode = readFile('src/components/AdminDashboardView.tsx');
    expect(adminCode).toContain('handleWithdrawalTransition');
    expect(adminCode).toContain("nextStatus: 'processing' | 'paid' | 'rejected' | 'reversed'");
  });

  test('14. Security and unauthorized access prevention: blocks privilege escalation, PII scraping, and script injection', () => {
    for (const item of dirtyDozenPayloads) {
      expect(item.expected).toBe('PERMISSION_DENIED');
    }
    expect(rules).toContain('match /usersPrivate/{uid}');
    expect(rules).toContain('isSafeOptionalHttpUrl');
    expect(rules).toContain('isSafeOptionalMediaUrl');
  });

  test('15. Admin Navigation Visibility: strictly hidden for regular users, visible ONLY to admin Gmail (theimperion.1x@gmail.com) and authorized admins', () => {
    const layoutCode = readFile('src/components/LayoutShell.tsx');
    expect(layoutCode).toContain('BOOTSTRAPPED_SUPER_ADMIN_EMAIL');
    expect(layoutCode).toContain('canAccessAdmin');
    expect(layoutCode).toContain('canAccessAdmin ? [{ id: \'admin\' as AppTab');
    expect(layoutCode).toContain('{canAccessAdmin && (');
    expect(layoutCode).not.toContain("{ id: 'admin', label: t('admin'), icon: Shield },");

    const fbCode = readFile('src/lib/firebase.ts');
    expect(fbCode).toContain("BOOTSTRAPPED_SUPER_ADMIN_EMAIL = 'theimperion.1x@gmail.com'");
  });
});
