import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signOut as firebaseSignOut,
  reload,
  sendEmailVerification,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  onSnapshot,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
} from 'firebase/firestore';
import {
  auth,
  BOOTSTRAPPED_SUPER_ADMIN_EMAIL,
  db,
  handleFirestoreError,
  makeSafeId,
  OperationType,
  testConnection,
} from '../lib/firebase';
import {
  FeatureFlags,
  LanguageCode,
  PlatformSettings,
  ThemeMode,
  UserPrivate,
  UserProfile,
  UserRole,
} from '../types/hearthline';
import { BRAND_ASSETS } from '../lib/assets';

interface AuthContextValue {
  firebaseUser: User | null;
  profile: UserProfile | null;
  privateData: UserPrivate | null;
  effectiveRole: UserRole;
  isSuperAdmin: boolean;
  isAdmin: boolean;
  isModerator: boolean;
  authReady: boolean;
  needsOnboarding: boolean;
  theme: ThemeMode;
  language: LanguageCode;
  platformSettings: PlatformSettings;
  featureFlags: FeatureFlags;
  setTheme: (mode: ThemeMode) => Promise<void>;
  setLanguage: (lang: LanguageCode) => Promise<void>;
  completeOnboarding: (data: {
    username: string;
    displayName: string;
    bio: string;
    photoUrl: string;
    locationCity: string;
    locationCountry: string;
    locationConsent: boolean;
  }) => Promise<void>;
  refreshVerification: () => Promise<boolean>;
  resendVerificationEmail: () => Promise<void>;
  signOut: () => Promise<void>;
}

const DEFAULT_SETTINGS: PlatformSettings = {
  minWithdrawalPoisha: 50000,
  pageMinFollowers: 100,
  pageMinAgeDays: 7,
  creatorMinFollowers: 1000,
  creatorMinAgeDays: 30,
  pageOwnerShareBps: 4000,
  platformShareBps: 6000,
  creatorPoolBps: 4000,
  creatorVideoAllocPct: 50,
  creatorPostAllocPct: 30,
  creatorQualityAllocPct: 20,
  updatedAt: Timestamp.now(),
};

const DEFAULT_FLAGS: FeatureFlags = {
  liveStreamingEnabled: false,
  marketplaceEnabled: false,
  voiceCallsEnabled: false,
  videoCallsEnabled: false,
  creatorGiftsEnabled: false,
  creatorCoinsEnabled: false,
  aiAssistantEnabled: false,
  updatedAt: Timestamp.now(),
};

const AuthContext = createContext<AuthContextValue>({
  firebaseUser: null,
  profile: null,
  privateData: null,
  effectiveRole: 'user',
  isSuperAdmin: false,
  isAdmin: false,
  isModerator: false,
  authReady: false,
  needsOnboarding: false,
  theme: 'dark',
  language: 'en',
  platformSettings: DEFAULT_SETTINGS,
  featureFlags: DEFAULT_FLAGS,
  setTheme: async () => {},
  setLanguage: async () => {},
  completeOnboarding: async () => {},
  refreshVerification: async () => false,
  resendVerificationEmail: async () => {},
  signOut: async () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [privateData, setPrivateData] = useState<UserPrivate | null>(null);
  const [adminRegistryRole, setAdminRegistryRole] = useState<UserRole | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profileChecked, setProfileChecked] = useState(false);

  const [theme, setThemeState] = useState<ThemeMode>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('hl_theme');
      if (saved === 'light' || saved === 'dark') return saved;
    }
    return 'dark';
  });

  const [language, setLanguageState] = useState<LanguageCode>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('hl_lang');
      if (saved === 'en' || saved === 'bn') return saved;
    }
    return 'en';
  });

  const [platformSettings, setPlatformSettings] = useState<PlatformSettings>(DEFAULT_SETTINGS);
  const [featureFlags, setFeatureFlags] = useState<FeatureFlags>(DEFAULT_FLAGS);

  useEffect(() => {
    testConnection();
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    window.localStorage.setItem('hl_theme', theme);
  }, [theme]);

  useEffect(() => {
    window.localStorage.setItem('hl_lang', language);
  }, [language]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      if (!user) {
        setProfile(null);
        setPrivateData(null);
        setAdminRegistryRole(null);
        setProfileChecked(true);
      } else {
        setProfileChecked(false);
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    if (!firebaseUser) return;
    const uid = firebaseUser.uid;

    const unsubProfile = onSnapshot(
      doc(db, 'users', uid),
      (snap) => {
        if (snap.exists()) {
          setProfile(snap.data() as UserProfile);
        } else {
          setProfile(null);
        }
        setProfileChecked(true);
      },
      (err) => {
        setProfileChecked(true);
        handleFirestoreError(err, OperationType.GET, `users/${uid}`);
      }
    );

    const unsubPrivate = onSnapshot(
      doc(db, 'usersPrivate', uid),
      (snap) => {
        if (snap.exists()) {
          const p = snap.data() as UserPrivate;
          setPrivateData(p);
          if (p.theme) setThemeState(p.theme);
          if (p.preferredLanguage) setLanguageState(p.preferredLanguage);
        } else {
          setPrivateData(null);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `usersPrivate/${uid}`)
    );

    const unsubAdmin = onSnapshot(
      doc(db, 'admins', uid),
      (snap) => {
        if (snap.exists()) {
          setAdminRegistryRole((snap.data() as { role: UserRole }).role);
        } else {
          setAdminRegistryRole(null);
        }
      },
      () => {
        setAdminRegistryRole(null);
      }
    );

    const unsubSettings = onSnapshot(
      doc(db, 'platformSettings', 'global'),
      (snap) => {
        if (snap.exists()) {
          setPlatformSettings(snap.data() as PlatformSettings);
        }
      },
      () => {}
    );

    const unsubFlags = onSnapshot(
      doc(db, 'featureFlags', 'global'),
      (snap) => {
        if (snap.exists()) {
          setFeatureFlags(snap.data() as FeatureFlags);
        }
      },
      () => {}
    );

    return () => {
      unsubProfile();
      unsubPrivate();
      unsubAdmin();
      unsubSettings();
      unsubFlags();
    };
  }, [firebaseUser]);

  const isBootstrappedSuperAdmin =
    firebaseUser?.email?.toLowerCase() === BOOTSTRAPPED_SUPER_ADMIN_EMAIL.toLowerCase();

  const effectiveRole: UserRole = isBootstrappedSuperAdmin
    ? 'super_admin'
    : adminRegistryRole || profile?.role || 'user';

  const isSuperAdmin = effectiveRole === 'super_admin';
  const isAdmin = effectiveRole === 'super_admin' || effectiveRole === 'admin';
  const isModerator = isAdmin || effectiveRole === 'moderator';

  // Ensure admins doc, global settings & feature flags documents exist when a Super Admin signs in
  useEffect(() => {
    if (!firebaseUser || !isSuperAdmin) return;
    (async () => {
      try {
        const aRef = doc(db, 'admins', firebaseUser.uid);
        const aSnap = await getDoc(aRef);
        if (!aSnap.exists()) {
          await setDoc(aRef, {
            uid: firebaseUser.uid,
            role: 'super_admin',
            createdAt: serverTimestamp(),
          });
        }

        const sRef = doc(db, 'platformSettings', 'global');
        const sSnap = await getDoc(sRef);
        if (!sSnap.exists()) {
          await setDoc(sRef, {
            minWithdrawalPoisha: 50000,
            pageMinFollowers: 100,
            pageMinAgeDays: 7,
            creatorMinFollowers: 1000,
            creatorMinAgeDays: 30,
            pageOwnerShareBps: 4000,
            platformShareBps: 6000,
            creatorPoolBps: 4000,
            creatorVideoAllocPct: 50,
            creatorPostAllocPct: 30,
            creatorQualityAllocPct: 20,
            updatedBy: firebaseUser.uid,
            updatedAt: serverTimestamp(),
          });
        }
        const fRef = doc(db, 'featureFlags', 'global');
        const fSnap = await getDoc(fRef);
        if (!fSnap.exists()) {
          await setDoc(fRef, {
            liveStreamingEnabled: false,
            marketplaceEnabled: false,
            voiceCallsEnabled: false,
            videoCallsEnabled: false,
            creatorGiftsEnabled: false,
            creatorCoinsEnabled: false,
            aiAssistantEnabled: false,
            updatedBy: firebaseUser.uid,
            updatedAt: serverTimestamp(),
          });
        }
      } catch {
        // ignore if already initialized concurrently
      }
    })();
  }, [firebaseUser, isSuperAdmin]);

  const setTheme = async (mode: ThemeMode) => {
    setThemeState(mode);
    if (firebaseUser && privateData) {
      try {
        await updateDoc(doc(db, 'usersPrivate', firebaseUser.uid), {
          theme: mode,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `usersPrivate/${firebaseUser.uid}`);
      }
    }
  };

  const setLanguage = async (lang: LanguageCode) => {
    setLanguageState(lang);
    if (firebaseUser && privateData) {
      try {
        await updateDoc(doc(db, 'usersPrivate', firebaseUser.uid), {
          preferredLanguage: lang,
          updatedAt: serverTimestamp(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `usersPrivate/${firebaseUser.uid}`);
      }
    }
  };

  const completeOnboarding: AuthContextValue['completeOnboarding'] = async (data) => {
    if (!firebaseUser) throw new Error('Must be signed in.');
    const cleanUsername = data.username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (cleanUsername.length < 3 || cleanUsername.length > 30) {
      throw new Error('Username must be 3–30 lowercase letters, numbers, or underscores.');
    }
    const uid = firebaseUser.uid;

    try {
      await runTransaction(db, async (tx) => {
        const unameRef = doc(db, 'usernames', cleanUsername);
        const unameSnap = await tx.get(unameRef);
        if (unameSnap.exists() && unameSnap.data().uid !== uid) {
          throw new Error('That username is already taken. Please choose another.');
        }

        tx.set(unameRef, {
          uid,
          targetType: 'user',
          targetId: uid,
          createdAt: serverTimestamp(),
        });

        tx.set(doc(db, 'users', uid), {
          uid,
          username: cleanUsername,
          displayName: data.displayName.trim().slice(0, 80),
          bio: data.bio.trim().slice(0, 500),
          photoUrl: data.photoUrl.trim().slice(0, 1024) || firebaseUser.photoURL || '',
          coverUrl: BRAND_ASSETS.defaultProfileCover,
          locationCity: data.locationConsent ? data.locationCity.trim().slice(0, 80) : '',
          locationCountry: data.locationConsent ? data.locationCountry.trim().slice(0, 80) : '',
          role: 'user',
          privacyLevel: 'public',
          friendsCount: 0,
          followersCount: 0,
          followingCount: 0,
          creatorMonetizationStatus: 'not_eligible',
          accountStatus: 'active',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        tx.set(doc(db, 'usersPrivate', uid), {
          uid,
          email: (firebaseUser.email || '').slice(0, 200),
          locationConsent: Boolean(data.locationConsent),
          preferredLanguage: language,
          theme,
          updatedAt: serverTimestamp(),
        });

        if (firebaseUser.emailVerified) {
          tx.set(doc(db, 'wallets', uid), {
            uid,
            pendingPoisha: 0,
            availablePoisha: 0,
            processingPoisha: 0,
            paidPoisha: 0,
            reversedPoisha: 0,
            updatedAt: serverTimestamp(),
          });
        }
      });
    } catch (err) {
      if (err instanceof Error && err.message.includes('already taken')) {
        throw err;
      }
      handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
    }
  };

  const refreshVerification = async (): Promise<boolean> => {
    if (!auth.currentUser) return false;
    await reload(auth.currentUser);
    const refreshed = auth.currentUser;
    setFirebaseUser({ ...refreshed } as User);
    if (refreshed.emailVerified) {
      const walletRef = doc(db, 'wallets', refreshed.uid);
      const wSnap = await getDoc(walletRef);
      if (!wSnap.exists()) {
        await setDoc(walletRef, {
          uid: refreshed.uid,
          pendingPoisha: 0,
          availablePoisha: 0,
          processingPoisha: 0,
          paidPoisha: 0,
          reversedPoisha: 0,
          updatedAt: serverTimestamp(),
        });
      }
    }
    return refreshed.emailVerified;
  };

  const resendVerificationEmail = async () => {
    if (!auth.currentUser) return;
    await sendEmailVerification(auth.currentUser);
  };

  const signOut = async () => {
    await firebaseSignOut(auth);
  };

  const needsOnboarding = Boolean(firebaseUser && profileChecked && !profile);

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        privateData,
        effectiveRole,
        isSuperAdmin,
        isAdmin,
        isModerator,
        authReady: authReady && profileChecked,
        needsOnboarding,
        theme,
        language,
        platformSettings,
        featureFlags,
        setTheme,
        setLanguage,
        completeOnboarding,
        refreshVerification,
        resendVerificationEmail,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export async function createNotification(params: {
  recipientUid: string;
  actorUid: string;
  type: string;
  title: string;
  body: string;
  targetTab?: string;
}) {
  if (!params.recipientUid || params.recipientUid === params.actorUid) return;
  const id = makeSafeId('notif');
  try {
    await setDoc(doc(db, 'notifications', id), {
      recipientUid: params.recipientUid,
      actorUid: params.actorUid,
      type: params.type.slice(0, 60),
      title: params.title.slice(0, 160),
      body: params.body.slice(0, 400),
      targetTab: (params.targetTab || 'home').slice(0, 40),
      read: false,
      createdAt: serverTimestamp(),
    });
  } catch {
    // non-fatal notification failure
  }
}
