import { Post } from '../types/hearthline';

export interface SuggestedPostEntry {
  post: Post;
  score: number;
  engagementTotal: number;
  reason: string;
}

export interface RankSuggestedPostsOptions {
  posts: Post[];
  currentUid?: string | null;
  friendUids: Set<string>;
  followingUids: Set<string>;
  hiddenPostIds?: Set<string>;
  nowMs?: number;
  limit?: number;
}

function getCreatedAtMillis(post: Post, fallbackMs: number): number {
  const ts = post.createdAt as unknown;
  if (ts && typeof (ts as { toMillis?: () => number }).toMillis === 'function') {
    return (ts as { toMillis: () => number }).toMillis();
  }
  if (typeof ts === 'number' && Number.isFinite(ts)) {
    return ts;
  }
  return fallbackMs;
}

export function computePostEngagementScore(
  post: Post,
  context: {
    friendUids: Set<string>;
    followingUids: Set<string>;
    nowMs: number;
  }
): { score: number; engagementTotal: number; reason: string } {
  const likes = Math.max(0, post.likesCount || 0);
  const comments = Math.max(0, post.commentsCount || 0);
  const shares = Math.max(0, post.sharesCount || 0);
  const impressions = Math.max(0, post.organicImpressions || 0);

  const engagementTotal = likes + comments + shares;
  const weightedEngagement =
    likes * 2 + comments * 3 + shares * 4 + Math.min(10, impressions * 0.05);

  const isFriend = context.friendUids.has(post.authorUid);
  const isFollowing =
    context.followingUids.has(post.authorUid) ||
    (post.pageId ? context.followingUids.has(post.pageId) : false);

  const networkBonus = isFriend ? 6 : isFollowing ? 5 : 0;
  const mediaBonus = post.mediaUrls && post.mediaUrls.length > 0 ? 2 : 0;
  const boostBonus = post.isBoosted ? 4 : 0;

  const createdMs = getCreatedAtMillis(post, context.nowMs);
  const ageHours = Math.max(0.5, (context.nowMs - createdMs) / 3600000);
  const score =
    (weightedEngagement + networkBonus + mediaBonus + boostBonus + 1) /
    Math.pow(ageHours + 2, 1.15);

  let reason = 'Fresh discovery';
  if (shares >= 3) {
    reason = 'Widely shared';
  } else if (comments >= 3) {
    reason = 'Active discussion';
  } else if (likes >= 5) {
    reason = 'Popular right now';
  } else if (isFriend) {
    reason = 'From your friends';
  } else if (isFollowing) {
    reason = 'From creators you follow';
  } else if (engagementTotal > 0) {
    reason = 'Trending engagement';
  }

  return { score, engagementTotal, reason };
}

export function rankSuggestedPosts({
  posts,
  currentUid,
  friendUids,
  followingUids,
  hiddenPostIds,
  nowMs = Date.now(),
  limit = 5,
}: RankSuggestedPostsOptions): SuggestedPostEntry[] {
  const entries: SuggestedPostEntry[] = [];

  for (const post of posts) {
    if (hiddenPostIds?.has(post.id)) continue;
    if (currentUid && post.authorUid === currentUid) continue;
    if (post.visibility === 'only_me') continue;
    if (post.visibility === 'friends' && !friendUids.has(post.authorUid)) continue;

    const { score, engagementTotal, reason } = computePostEngagementScore(post, {
      friendUids,
      followingUids,
      nowMs,
    });

    entries.push({
      post,
      score,
      engagementTotal,
      reason,
    });
  }

  entries.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (b.engagementTotal !== a.engagementTotal) return b.engagementTotal - a.engagementTotal;
    return getCreatedAtMillis(b.post, nowMs) - getCreatedAtMillis(a.post, nowMs);
  });

  return entries.slice(0, Math.max(0, limit));
}
