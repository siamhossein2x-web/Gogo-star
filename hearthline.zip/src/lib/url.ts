/**
 * Safe External URL Utilities
 * Strictly permits only http:// and https:// URLs for outbound navigation/links,
 * blocking javascript:, data:, vbscript:, and malformed schemes.
 */

export function sanitizeExternalUrl(raw?: string | null): string | null {
  if (!raw || typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.toString();
    }
    return null;
  } catch {
    return null;
  }
}

export function isValidHttpUrl(raw?: string | null): boolean {
  return sanitizeExternalUrl(raw) !== null;
}
