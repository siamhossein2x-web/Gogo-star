/**
 * Cloudinary Media Upload Client
 * Reads public configuration from import.meta.env for unsigned browser uploads.
 * Never requests, stores, or exposes any Cloudinary API Secret, and never generates client-side signatures.
 */

export interface CloudinaryConfig {
  cloudName: string;
  uploadPreset: string;
  apiKey: string;
  apiKeyConfigured: boolean;
}

export class CloudinaryUploadError extends Error {
  status: number;
  cloudinaryMessage: string;
  responseBody: string;
  endpoint: string;

  constructor(params: {
    message: string;
    status: number;
    cloudinaryMessage: string;
    responseBody: string;
    endpoint: string;
  }) {
    super(params.message);
    this.name = 'CloudinaryUploadError';
    this.status = params.status;
    this.cloudinaryMessage = params.cloudinaryMessage;
    this.responseBody = params.responseBody;
    this.endpoint = params.endpoint;
  }
}

export function getCloudinaryConfig(): CloudinaryConfig {
  const envCloud = import.meta.env.VITE_CLOUDINARY_CLOUD_NAME || '';
  const envPreset = import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET || '';
  const envApiKey = import.meta.env.VITE_CLOUDINARY_API_KEY || '';
  const localCloud =
    typeof window !== 'undefined' ? window.localStorage.getItem('hl_cloudinary_cloud') || '' : '';
  const localPreset =
    typeof window !== 'undefined' ? window.localStorage.getItem('hl_cloudinary_preset') || '' : '';

  return {
    cloudName: (envCloud || localCloud).trim(),
    uploadPreset: (envPreset || localPreset).trim(),
    apiKey: envApiKey.trim(),
    apiKeyConfigured: Boolean(envApiKey.trim()),
  };
}

export function saveCloudinaryConfig(cloudName: string, uploadPreset: string): void {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem('hl_cloudinary_cloud', cloudName.trim());
  window.localStorage.setItem('hl_cloudinary_preset', uploadPreset.trim());
}

export function isCloudinaryConfigured(): boolean {
  const { cloudName, uploadPreset } = getCloudinaryConfig();
  return Boolean(cloudName && uploadPreset);
}

export function getCloudinaryUploadEndpoints(cloudName: string) {
  const encoded = encodeURIComponent(cloudName.trim());
  return {
    image: `https://api.cloudinary.com/v1_1/${encoded}/image/upload`,
    video: `https://api.cloudinary.com/v1_1/${encoded}/video/upload`,
  };
}

export function resolveMediaTypeForUpload(
  file: File,
  expectedType: 'image' | 'video' | 'auto'
): 'image' | 'video' {
  const mime = (file.type || '').toLowerCase();
  const name = (file.name || '').toLowerCase();

  const looksLikeImage =
    mime.startsWith('image/') || /\.(jpe?g|png|gif|webp|avif|bmp|svg)$/i.test(name);
  const looksLikeVideo =
    mime.startsWith('video/') || /\.(mp4|webm|mov|m4v|avi|mkv|3gp)$/i.test(name);

  if (expectedType === 'image') {
    if (!looksLikeImage) {
      throw new Error('Please choose a valid image file (JPG, PNG, WEBP, or GIF).');
    }
    return 'image';
  }

  if (expectedType === 'video') {
    if (!looksLikeVideo) {
      throw new Error('Please choose a valid video file (MP4, WEBM, or MOV).');
    }
    return 'video';
  }

  if (looksLikeVideo) return 'video';
  if (looksLikeImage) return 'image';

  throw new Error('Unsupported file type. Please choose an image or video file.');
}

function extractCloudinaryMessage(responseText: string): string {
  try {
    const parsed = JSON.parse(responseText) as { error?: { message?: string } };
    return (parsed?.error?.message || '').trim();
  } catch {
    return responseText.trim();
  }
}

function buildCloudinaryUploadError(
  status: number,
  responseText: string,
  uploadPreset: string,
  endpoint: string
): CloudinaryUploadError {
  const cloudinaryMessage = extractCloudinaryMessage(responseText);
  const lower = cloudinaryMessage.toLowerCase();

  let hint = '';
  if (lower.includes('whitelisted for unsigned') || lower.includes('upload preset')) {
    hint = `Ensure preset "${uploadPreset}" exists and is enabled for Unsigned uploads.`;
  } else if (lower.includes('unknown api key')) {
    hint =
      'Cloudinary could not resolve the cloud without an account identifier (verify VITE_CLOUDINARY_CLOUD_NAME matches your exact cloud slug).';
  } else if (lower.includes('file size too large') || status === 413) {
    hint = 'File exceeds Cloudinary size limits.';
  }

  const message = [
    `Cloudinary HTTP ${status}${cloudinaryMessage ? `: ${cloudinaryMessage}` : ''}`,
    hint,
  ]
    .filter(Boolean)
    .join(' — ');

  return new CloudinaryUploadError({
    message,
    status,
    cloudinaryMessage,
    responseBody: responseText,
    endpoint,
  });
}

export interface UploadResult {
  secureUrl: string;
  resourceType: 'image' | 'video';
  publicId: string;
  bytes: number;
}

function sendUnsignedXhr(params: {
  endpoint: string;
  file: File;
  uploadPreset: string;
  apiKey?: string;
  onProgress?: (pct: number) => void;
}): Promise<UploadResult> {
  const { endpoint, file, uploadPreset, apiKey, onProgress } = params;

  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', uploadPreset);
  formData.append('folder', 'hearthline');
  if (apiKey) {
    // Only passed as account identifier fallback; NO signature and NO API secret are ever sent.
    formData.append('api_key', apiKey);
  }

  return new Promise<UploadResult>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', endpoint);
    xhr.timeout = 120000;

    xhr.upload.onprogress = (ev) => {
      if (ev.lengthComputable && onProgress) {
        onProgress(Math.round((ev.loaded / ev.total) * 100));
      }
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const data = JSON.parse(xhr.responseText) as {
            secure_url?: string;
            resource_type?: string;
            public_id?: string;
            bytes?: number;
          };
          if (!data.secure_url) {
            reject(
              new CloudinaryUploadError({
                message: 'Cloudinary HTTP 200 but secure_url was missing from the response body.',
                status: xhr.status,
                cloudinaryMessage: 'Missing secure_url',
                responseBody: xhr.responseText,
                endpoint,
              })
            );
            return;
          }
          resolve({
            secureUrl: data.secure_url,
            resourceType: data.resource_type === 'video' ? 'video' : 'image',
            publicId: data.public_id || '',
            bytes: data.bytes || file.size,
          });
        } catch {
          reject(
            new CloudinaryUploadError({
              message: `Invalid JSON response from Cloudinary (HTTP ${xhr.status}).`,
              status: xhr.status,
              cloudinaryMessage: 'Invalid JSON response',
              responseBody: xhr.responseText,
              endpoint,
            })
          );
        }
      } else {
        reject(buildCloudinaryUploadError(xhr.status, xhr.responseText, uploadPreset, endpoint));
      }
    };

    xhr.ontimeout = () =>
      reject(new Error('Cloudinary upload timed out. Please check your connection and try again.'));
    xhr.onerror = () =>
      reject(new Error('Network error while uploading media to Cloudinary.'));
    xhr.send(formData);
  });
}

export async function uploadToCloudinary(
  file: File,
  expectedType: 'image' | 'video' | 'auto' = 'auto',
  onProgress?: (pct: number) => void
): Promise<UploadResult> {
  const { cloudName, uploadPreset, apiKey } = getCloudinaryConfig();
  if (!cloudName || !uploadPreset) {
    throw new Error(
      'Cloudinary unsigned upload is not configured. Set VITE_CLOUDINARY_CLOUD_NAME and VITE_CLOUDINARY_UPLOAD_PRESET or configure them in Settings.'
    );
  }

  if (!file || file.size <= 0) {
    throw new Error('The selected file is empty.');
  }

  const resolvedType = resolveMediaTypeForUpload(file, expectedType);
  const maxBytes = resolvedType === 'video' ? 100 * 1024 * 1024 : 15 * 1024 * 1024;
  if (file.size > maxBytes) {
    throw new Error(
      `File exceeds the ${resolvedType === 'video' ? '100MB' : '15MB'} ${resolvedType} upload limit.`
    );
  }

  const endpoints = getCloudinaryUploadEndpoints(cloudName);
  const endpoint = resolvedType === 'video' ? endpoints.video : endpoints.image;

  try {
    // Primary attempt: pure unsigned upload (file + upload_preset + folder), API Key unused.
    return await sendUnsignedXhr({
      endpoint,
      file,
      uploadPreset,
      onProgress,
    });
  } catch (err) {
    // If Cloudinary returns HTTP 401 "Unknown API key" (e.g. cloudName typo vs account slug),
    // retry unsigned upload with VITE_CLOUDINARY_API_KEY as account identifier (still unsigned, no signature/secret).
    if (
      err instanceof CloudinaryUploadError &&
      err.status === 401 &&
      err.cloudinaryMessage.toLowerCase().includes('unknown api key') &&
      apiKey
    ) {
      return await sendUnsignedXhr({
        endpoint,
        file,
        uploadPreset,
        apiKey,
        onProgress,
      });
    }
    throw err;
  }
}
