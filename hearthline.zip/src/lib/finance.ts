/**
 * Integer Poisha Accounting Utilities (1 BDT = 100 Poisha)
 * Guarantees exact integer math with zero floating-point drift.
 */

export const DEFAULT_PAGE_OWNER_BPS = 4000; // 40.00%
export const DEFAULT_PLATFORM_BPS = 6000;   // 60.00%
export const DEFAULT_MIN_WITHDRAWAL_POISHA = 50000; // ৳500.00

export function bdtToPoisha(bdt: number): number {
  if (!Number.isFinite(bdt) || bdt < 0) return 0;
  return Math.round(bdt * 100);
}

export function formatBDT(poisha: number): string {
  const safe = Number.isFinite(poisha) ? Math.trunc(poisha) : 0;
  const taka = safe / 100;
  return `৳${taka.toLocaleString('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function formatCompactNumber(num: number): string {
  if (!Number.isFinite(num)) return '0';
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(1)}M`;
  if (num >= 1_000) return `${(num / 1_000).toFixed(1)}K`;
  return String(num);
}

export interface RevenueSplitResult {
  grossPoisha: number;
  deductionsPoisha: number;
  eligibleNetPoisha: number;
  ownerSharePoisha: number;
  platformSharePoisha: number;
  ownerPercentBps: number;
  platformPercentBps: number;
}

/**
 * Computes the mandatory 40/60 Page Monetization split (or Super Admin configured bps)
 * exclusively from verified, collected revenue AFTER documented deductions.
 */
export function calculatePageRevenueSplit(
  grossPoisha: number,
  deductionsPoisha: number,
  ownerPercentBps = DEFAULT_PAGE_OWNER_BPS,
  platformPercentBps = DEFAULT_PLATFORM_BPS
): RevenueSplitResult {
  const safeGross = Math.max(0, Math.trunc(grossPoisha));
  const safeDeductions = Math.max(0, Math.min(safeGross, Math.trunc(deductionsPoisha)));
  const eligibleNetPoisha = safeGross - safeDeductions;

  if (ownerPercentBps + platformPercentBps !== 10000) {
    throw new Error('Revenue split basis points must sum to 10000 (100%).');
  }

  const ownerSharePoisha = Math.floor((eligibleNetPoisha * ownerPercentBps) / 10000);
  const platformSharePoisha = eligibleNetPoisha - ownerSharePoisha;

  return {
    grossPoisha: safeGross,
    deductionsPoisha: safeDeductions,
    eligibleNetPoisha,
    ownerSharePoisha,
    platformSharePoisha,
    ownerPercentBps,
    platformPercentBps,
  };
}
