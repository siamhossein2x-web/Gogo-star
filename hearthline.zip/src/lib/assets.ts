export const BRAND_ASSETS = {
  welcomeCover: '/src/assets/images/hearthline_welcome_cover_1795619500166.jpg',
  defaultProfileCover: '/src/assets/images/default_profile_cover_1795619500153.jpg',
  defaultPageCover: '/src/assets/images/default_page_cover_1795619500773.jpg',
};
