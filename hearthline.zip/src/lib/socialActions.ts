import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  increment,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  db,
  handleFirestoreError,
  makeFriendshipId,
  makeSafeId,
  OperationType,
} from './firebase';
import { createNotification } from '../context/AuthContext';
import { calculatePageRevenueSplit } from './finance';

export async function sendFriendRequest(fromUid: string, toUid: string, actorName: string) {
  if (fromUid === toUid) throw new Error('Cannot send friend request to yourself.');
  const friendshipId = makeFriendshipId(fromUid, toUid);
  const friendSnap = await getDoc(doc(db, 'friendships', friendshipId));
  if (friendSnap.exists()) throw new Error('You are already friends.');

  const existingQ = query(
    collection(db, 'friendRequests'),
    where('fromUid', '==', fromUid),
    where('toUid', '==', toUid)
  );
  const existingSnaps = await getDocs(existingQ);
  const pending = existingSnaps.docs.find((d) => d.data().status === 'pending');
  if (pending) throw new Error('Friend request already sent.');

  const reqId = `fr_${fromUid}_${toUid}_${Date.now().toString(36)}`.slice(0, 120);
  try {
    await setDoc(doc(db, 'friendRequests', reqId), {
      fromUid,
      toUid,
      status: 'pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    await createNotification({
      recipientUid: toUid,
      actorUid: fromUid,
      type: 'friend_request',
      title: 'New Friend Request',
      body: `${actorName} sent you a friend request.`,
      targetTab: 'friends',
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `friendRequests/${reqId}`);
  }
}

export async function acceptFriendRequest(
  requestId: string,
  fromUid: string,
  toUid: string,
  accepterName: string
) {
  const friendshipId = makeFriendshipId(fromUid, toUid);
  const [userA, userB] = fromUid < toUid ? [fromUid, toUid] : [toUid, fromUid];

  try {
    await runTransaction(db, async (tx) => {
      const reqRef = doc(db, 'friendRequests', requestId);
      const reqSnap = await tx.get(reqRef);
      if (!reqSnap.exists() || reqSnap.data().status !== 'pending') {
        throw new Error('Request is no longer pending.');
      }

      const fRef = doc(db, 'friendships', friendshipId);
      const fSnap = await tx.get(fRef);

      tx.update(reqRef, {
        status: 'accepted',
        updatedAt: serverTimestamp(),
      });

      if (!fSnap.exists()) {
        tx.set(fRef, {
          userA,
          userB,
          createdAt: serverTimestamp(),
        });
        tx.update(doc(db, 'users', userA), {
          friendsCount: increment(1),
          updatedAt: serverTimestamp(),
        });
        tx.update(doc(db, 'users', userB), {
          friendsCount: increment(1),
          updatedAt: serverTimestamp(),
        });
      }
    });

    await createNotification({
      recipientUid: fromUid,
      actorUid: toUid,
      type: 'friend_accepted',
      title: 'Friend Request Accepted',
      body: `${accepterName} accepted your friend request. You can now message each other.`,
      targetTab: 'messages',
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `friendships/${friendshipId}`);
  }
}

export async function updateFriendRequestStatus(
  requestId: string,
  status: 'rejected' | 'cancelled'
) {
  try {
    await updateDoc(doc(db, 'friendRequests', requestId), {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `friendRequests/${requestId}`);
  }
}

export async function removeFriend(uid1: string, uid2: string) {
  const friendshipId = makeFriendshipId(uid1, uid2);
  try {
    await runTransaction(db, async (tx) => {
      const fRef = doc(db, 'friendships', friendshipId);
      const fSnap = await tx.get(fRef);
      if (!fSnap.exists()) return;
      tx.delete(fRef);
      tx.update(doc(db, 'users', uid1), {
        friendsCount: increment(-1),
        updatedAt: serverTimestamp(),
      });
      tx.update(doc(db, 'users', uid2), {
        friendsCount: increment(-1),
        updatedAt: serverTimestamp(),
      });
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `friendships/${friendshipId}`);
  }
}

export async function toggleFollow(
  followerUid: string,
  targetId: string,
  targetType: 'user' | 'page',
  currentlyFollowing: boolean,
  followerName: string
): Promise<boolean> {
  if (targetType === 'user' && followerUid === targetId) {
    throw new Error('Cannot follow yourself.');
  }
  const followId = `${followerUid}_${targetId}`;
  try {
    const batch = writeBatch(db);
    const fRef = doc(db, 'follows', followId);
    if (currentlyFollowing) {
      batch.delete(fRef);
      if (targetType === 'user') {
        batch.update(doc(db, 'users', targetId), {
          followersCount: increment(-1),
          updatedAt: serverTimestamp(),
        });
        batch.update(doc(db, 'users', followerUid), {
          followingCount: increment(-1),
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.update(doc(db, 'pages', targetId), {
          followersCount: increment(-1),
          updatedAt: serverTimestamp(),
        });
      }
    } else {
      batch.set(fRef, {
        followerUid,
        targetId,
        targetType,
        createdAt: serverTimestamp(),
      });
      if (targetType === 'user') {
        batch.update(doc(db, 'users', targetId), {
          followersCount: increment(1),
          updatedAt: serverTimestamp(),
        });
        batch.update(doc(db, 'users', followerUid), {
          followingCount: increment(1),
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.update(doc(db, 'pages', targetId), {
          followersCount: increment(1),
          updatedAt: serverTimestamp(),
        });
      }
    }
    await batch.commit();

    if (!currentlyFollowing && targetType === 'user') {
      await createNotification({
        recipientUid: targetId,
        actorUid: followerUid,
        type: 'new_follower',
        title: 'New Follower',
        body: `${followerName} started following you.`,
        targetTab: 'profile',
      });
    }
    return !currentlyFollowing;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `follows/${followId}`);
  }
}

export async function blockUser(blockerUid: string, blockedUid: string) {
  const blockId = `${blockerUid}_${blockedUid}`;
  try {
    await setDoc(doc(db, 'blockedUsers', blockId), {
      blockerUid,
      blockedUid,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `blockedUsers/${blockId}`);
  }
}

export async function unblockUser(blockerUid: string, blockedUid: string) {
  const blockId = `${blockerUid}_${blockedUid}`;
  try {
    await deleteDoc(doc(db, 'blockedUsers', blockId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `blockedUsers/${blockId}`);
  }
}

export async function submitReport(params: {
  reporterUid: string;
  targetType: 'user' | 'post' | 'page' | 'video' | 'comment' | 'community' | 'ad';
  targetId: string;
  reason: string;
  details?: string;
}) {
  const id = makeSafeId('rep');
  try {
    await setDoc(doc(db, 'reports', id), {
      reporterUid: params.reporterUid,
      targetType: params.targetType,
      targetId: params.targetId,
      reason: params.reason.trim().slice(0, 120),
      details: (params.details || '').trim().slice(0, 1000),
      status: 'open',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `reports/${id}`);
  }
}

export async function openOrCreateDirectConversation(currentUid: string, friendUid: string): Promise<string> {
  const blockSnap = await getDoc(doc(db, 'blockedUsers', `${currentUid}_${friendUid}`));
  if (blockSnap.exists()) {
    throw new Error('You blocked this user. Unblock them in Settings to send messages.');
  }
  const friendshipId = makeFriendshipId(currentUid, friendUid);
  const fSnap = await getDoc(doc(db, 'friendships', friendshipId));
  if (!fSnap.exists()) {
    throw new Error('One-to-one messaging is available only between confirmed friends.');
  }
  const convId = `dm_${friendshipId}`.slice(0, 128);
  const convRef = doc(db, 'conversations', convId);
  const convSnap = await getDoc(convRef);
  if (convSnap.exists()) return convId;

  const [u1, u2] = currentUid < friendUid ? [currentUid, friendUid] : [friendUid, currentUid];
  try {
    const batch = writeBatch(db);
    batch.set(convRef, {
      type: 'direct',
      friendshipId,
      participantUids: [u1, u2],
      lastMessageText: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'conversations', convId, 'members', u1), {
      uid: u1,
      role: 'member',
      unreadCount: 0,
      joinedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'conversations', convId, 'members', u2), {
      uid: u2,
      role: 'member',
      unreadCount: 0,
      joinedAt: serverTimestamp(),
    });
    await batch.commit();
    return convId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `conversations/${convId}`);
  }
}

/**
 * Verified Ad Delivery Event Tracker (deduplicated per viewer + campaign + eventType + day)
 */
export async function recordVerifiedAdEvent(
  campaignId: string,
  viewerUid: string,
  eventType: 'impression' | 'click' | 'video_view'
) {
  if (!campaignId || !viewerUid) return;
  const dayKey = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const cleanCamp = campaignId.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 48);
  const cleanUid = viewerUid.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 48);
  const eventId = `adevt_${cleanCamp}_${cleanUid}_${eventType}_${dayKey}`;
  try {
    await runTransaction(db, async (tx) => {
      const evtRef = doc(db, 'adEvents', eventId);
      const evtSnap = await tx.get(evtRef);
      if (evtSnap.exists()) return; // Deduplicate event

      const campRef = doc(db, 'adCampaigns', campaignId);
      const campSnap = await tx.get(campRef);
      if (!campSnap.exists()) return;
      const camp = campSnap.data();
      if (
        camp.status !== 'active' ||
        camp.paymentStatus !== 'verified' ||
        (camp.spentPoisha || 0) >= camp.lifetimeBudgetPoisha
      ) {
        return;
      }

      const costPoisha = eventType === 'click' ? 150 : eventType === 'video_view' ? 50 : 20;
      const nextSpent = Math.min(camp.lifetimeBudgetPoisha, (camp.spentPoisha || 0) + costPoisha);
      const nextStatus = nextSpent >= camp.lifetimeBudgetPoisha ? 'completed' : 'active';

      tx.set(evtRef, {
        campaignId,
        viewerUid,
        eventType,
        createdAt: serverTimestamp(),
      });

      tx.update(campRef, {
        paidImpressions: increment(eventType === 'impression' ? 1 : 0),
        paidReach: increment(eventType === 'impression' ? 1 : 0),
        clicks: increment(eventType === 'click' ? 1 : 0),
        videoViews: increment(eventType === 'video_view' ? 1 : 0),
        spentPoisha: nextSpent,
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
    });
  } catch {
    // non-fatal delivery metric tracking
  }
}

/**
 * Admin-only: Settle verified collected Page advertising revenue strictly under the 40/60 rule
 * Crediting ONLY the verified Page Owner's Page Wallet.
 */
export async function settlePageRevenue4060(params: {
  adminUid: string;
  pageId: string;
  grossPoisha: number;
  deductionsPoisha: number;
  ownerPercentBps: number;
  platformPercentBps: number;
  referenceNote: string;
}) {
  const split = calculatePageRevenueSplit(
    params.grossPoisha,
    params.deductionsPoisha,
    params.ownerPercentBps,
    params.platformPercentBps
  );
  if (split.eligibleNetPoisha <= 0) {
    throw new Error('Eligible net revenue must be greater than ৳0.00.');
  }

  const settlementId = makeSafeId('settle');
  try {
    await runTransaction(db, async (tx) => {
      const pageRef = doc(db, 'pages', params.pageId);
      const pageSnap = await tx.get(pageRef);
      if (!pageSnap.exists()) throw new Error('Page not found.');
      const pageData = pageSnap.data();
      if (pageData.monetizationStatus !== 'approved') {
        throw new Error('Page monetization is not approved yet.');
      }

      const ownerUid = pageData.ownerUid as string;
      const walletRef = doc(db, 'pageWallets', params.pageId);
      const walletSnap = await tx.get(walletRef);

      if (!walletSnap.exists()) {
        tx.set(walletRef, {
          pageId: params.pageId,
          ownerUid,
          pendingPoisha: 0,
          availablePoisha: split.ownerSharePoisha,
          processingPoisha: 0,
          paidPoisha: 0,
          reversedPoisha: 0,
          totalVerifiedGrossPoisha: split.grossPoisha,
          totalDeductionsPoisha: split.deductionsPoisha,
          totalEligibleNetPoisha: split.eligibleNetPoisha,
          totalOwner40Poisha: split.ownerSharePoisha,
          totalPlatform60Poisha: split.platformSharePoisha,
          updatedAt: serverTimestamp(),
        });
      } else {
        tx.update(walletRef, {
          ownerUid,
          availablePoisha: increment(split.ownerSharePoisha),
          totalVerifiedGrossPoisha: increment(split.grossPoisha),
          totalDeductionsPoisha: increment(split.deductionsPoisha),
          totalEligibleNetPoisha: increment(split.eligibleNetPoisha),
          totalOwner40Poisha: increment(split.ownerSharePoisha),
          totalPlatform60Poisha: increment(split.platformSharePoisha),
          updatedAt: serverTimestamp(),
        });
      }

      tx.set(doc(db, 'pageLedgerEntries', settlementId), {
        pageId: params.pageId,
        ownerUid,
        eventType: 'ad_revenue_settlement',
        grossPoisha: split.grossPoisha,
        deductionsPoisha: split.deductionsPoisha,
        eligibleNetPoisha: split.eligibleNetPoisha,
        ownerShare40Poisha: split.ownerSharePoisha,
        platformShare60Poisha: split.platformSharePoisha,
        ownerPercentBps: split.ownerPercentBps,
        platformPercentBps: split.platformPercentBps,
        referenceId: settlementId,
        createdAt: serverTimestamp(),
      });

      tx.set(doc(db, 'adminLogs', makeSafeId('alog')), {
        adminUid: params.adminUid,
        action: 'page_revenue_4060_settlement',
        targetCollection: 'pageWallets',
        targetId: params.pageId,
        details: `Net ${split.eligibleNetPoisha}p -> Owner(${ownerUid}) ${split.ownerSharePoisha}p / Platform ${split.platformSharePoisha}p. ${params.referenceNote}`,
        createdAt: serverTimestamp(),
      });
    });

    const pageSnap = await getDoc(doc(db, 'pages', params.pageId));
    const ownerUid = pageSnap.data()?.ownerUid;
    if (ownerUid) {
      await createNotification({
        recipientUid: ownerUid,
        actorUid: params.adminUid,
        type: 'page_monetization_credit',
        title: 'Page 40% Revenue Settled',
        body: `Your Page Wallet was credited ৳${(split.ownerSharePoisha / 100).toFixed(2)} (40% owner share).`,
        targetTab: 'wallet',
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `pageWallets/${params.pageId}`);
  }
}

export function isStoryActive(expiresAt?: Timestamp): boolean {
  if (!expiresAt) return false;
  return expiresAt.toMillis() > Date.now();
}
