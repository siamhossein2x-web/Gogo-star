import React, { Suspense, lazy, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { AuthProvider } from './context/AuthContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ToastProvider } from './components/Toast';
import { AuthGate } from './components/AuthGate';
import { LayoutShell } from './components/LayoutShell';
import { HomeFeedView } from './components/HomeFeedView';
import { UploadHubModal } from './components/UploadHubModal';
import { AppTab, PublicPage } from './types/hearthline';

const SparkView = lazy(() =>
  import('./components/SparkView').then((m) => ({ default: m.SparkView }))
);
const MessagesView = lazy(() =>
  import('./components/MessagesView').then((m) => ({ default: m.MessagesView }))
);
const ProfileView = lazy(() =>
  import('./components/ProfileView').then((m) => ({ default: m.ProfileView }))
);
const FriendsAndDiscoveryView = lazy(() =>
  import('./components/FriendsAndDiscoveryView').then((m) => ({
    default: m.FriendsAndDiscoveryView,
  }))
);
const NotificationsView = lazy(() =>
  import('./components/NotificationsView').then((m) => ({ default: m.NotificationsView }))
);
const PagesAndMonetizationView = lazy(() =>
  import('./components/PagesAndMonetizationView').then((m) => ({
    default: m.PagesAndMonetizationView,
  }))
);
const CommunitiesView = lazy(() =>
  import('./components/CommunitiesView').then((m) => ({ default: m.CommunitiesView }))
);
const AdsManagerView = lazy(() =>
  import('./components/AdsManagerView').then((m) => ({ default: m.AdsManagerView }))
);
const WalletView = lazy(() =>
  import('./components/WalletView').then((m) => ({ default: m.WalletView }))
);
const AdminDashboardView = lazy(() =>
  import('./components/AdminDashboardView').then((m) => ({ default: m.AdminDashboardView }))
);
const SettingsView = lazy(() =>
  import('./components/SettingsView').then((m) => ({ default: m.SettingsView }))
);

const TabLoadingFallback: React.FC = () => (
  <div className="flex items-center justify-center py-20 text-slate-500">
    <Loader2 className="w-6 h-6 animate-spin text-[#D4AF37]" />
  </div>
);

const HearthlineAppShell: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [viewedProfileUid, setViewedProfileUid] = useState<string | undefined>(undefined);
  const [activeConvId, setActiveConvId] = useState<string | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState('');
  const [uploadOpen, setUploadOpen] = useState(false);
  const [uploadMode, setUploadMode] = useState<'post' | 'story' | 'spark'>('post');
  const [promotePageTarget, setPromotePageTarget] = useState<PublicPage | null>(null);

  const handleSelectTab = (tab: AppTab, extra?: { targetUid?: string; convId?: string }) => {
    setActiveTab(tab);
    if (tab === 'profile') {
      setViewedProfileUid(extra?.targetUid);
    }
    if (tab === 'messages' && extra?.convId) {
      setActiveConvId(extra.convId);
    }
  };

  const handleOpenProfile = (uid: string) => {
    setViewedProfileUid(uid);
    setActiveTab('profile');
  };

  const handleOpenUpload = (mode: 'post' | 'story' | 'spark' = 'post') => {
    setUploadMode(mode);
    setUploadOpen(true);
  };

  return (
    <AuthGate>
      <LayoutShell
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onOpenUpload={handleOpenUpload}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      >
        <Suspense fallback={<TabLoadingFallback />}>
          {activeTab === 'home' && (
            <HomeFeedView
              onOpenProfile={handleOpenProfile}
              onOpenUpload={(mode) => handleOpenUpload(mode)}
              onOpenPages={() => setActiveTab('pages')}
            />
          )}
          {activeTab === 'spark' && (
            <SparkView
              onOpenProfile={handleOpenProfile}
              onOpenUpload={(mode) => handleOpenUpload(mode)}
            />
          )}
          {activeTab === 'messages' && (
            <MessagesView initialConvId={activeConvId} onOpenProfile={handleOpenProfile} />
          )}
          {activeTab === 'profile' && (
            <ProfileView
              targetUid={viewedProfileUid}
              onOpenProfile={handleOpenProfile}
              onOpenChat={(convId) => {
                setActiveConvId(convId);
                setActiveTab('messages');
              }}
              onOpenWallet={() => setActiveTab('wallet')}
            />
          )}
          {activeTab === 'friends' && (
            <FriendsAndDiscoveryView
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onOpenProfile={handleOpenProfile}
              onOpenChat={(convId) => {
                setActiveConvId(convId);
                setActiveTab('messages');
              }}
              onNavigateTab={(t) => setActiveTab(t)}
            />
          )}
          {activeTab === 'notifications' && (
            <NotificationsView onNavigate={handleSelectTab} />
          )}
          {activeTab === 'pages' && (
            <PagesAndMonetizationView
              onOpenProfile={handleOpenProfile}
              onPromotePage={(page) => {
                setPromotePageTarget(page);
                setActiveTab('ads');
              }}
              onOpenWallet={() => setActiveTab('wallet')}
            />
          )}
          {activeTab === 'communities' && (
            <CommunitiesView onOpenProfile={handleOpenProfile} />
          )}
          {activeTab === 'ads' && (
            <AdsManagerView
              promotePage={promotePageTarget}
              onClearPromotePage={() => setPromotePageTarget(null)}
            />
          )}
          {activeTab === 'wallet' && (
            <WalletView
              onOpenPages={() => setActiveTab('pages')}
              onOpenProfile={() => {
                setViewedProfileUid(undefined);
                setActiveTab('profile');
              }}
            />
          )}
          {activeTab === 'admin' && <AdminDashboardView />}
          {activeTab === 'settings' && <SettingsView />}
        </Suspense>
      </LayoutShell>

      <UploadHubModal
        open={uploadOpen}
        initialMode={uploadMode}
        onClose={() => setUploadOpen(false)}
      />
    </AuthGate>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <ToastProvider>
        <AuthProvider>
          <HearthlineAppShell />
        </AuthProvider>
      </ToastProvider>
    </ErrorBoundary>
  );
}
