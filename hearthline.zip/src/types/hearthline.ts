import { Timestamp } from 'firebase/firestore';

export type LanguageCode = 'en' | 'bn';
export type ThemeMode = 'dark' | 'light';
export type UserRole = 'user' | 'moderator' | 'admin' | 'super_admin';
export type PageRoleType = 'owner' | 'admin' | 'editor' | 'moderator';

export interface UserProfile {
  uid: string;
  username: string;
  displayName: string;
  bio?: string;
  photoUrl?: string;
  coverUrl?: string;
  locationCity?: string;
  locationCountry?: string;
  role: UserRole;
  privacyLevel: 'public' | 'friends' | 'private';
  friendsCount: number;
  followersCount: number;
  followingCount: number;
  creatorMonetizationStatus: 'not_eligible' | 'eligible' | 'pending_review' | 'approved' | 'suspended';
  accountStatus: 'active' | 'deactivated' | 'suspended' | 'pending_deletion';
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface UserPrivate {
  uid: string;
  email: string;
  phone?: string;
  locationConsent: boolean;
  preferredLanguage: LanguageCode;
  theme: ThemeMode;
  deactivationRequestedAt?: Timestamp;
  deletionRequestedAt?: Timestamp;
  updatedAt: Timestamp;
}

export interface FriendRequest {
  id: string;
  fromUid: string;
  toUid: string;
  status: 'pending' | 'accepted' | 'rejected' | 'cancelled';
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface Friendship {
  id: string;
  userA: string;
  userB: string;
  createdAt: Timestamp;
}

export interface FollowRecord {
  id: string;
  followerUid: string;
  targetId: string;
  targetType: 'user' | 'page';
  createdAt: Timestamp;
}

export interface Post {
  id: string;
  authorUid: string;
  authorType: 'user' | 'page';
  pageId?: string;
  communityId?: string;
  postType: 'text' | 'image' | 'video' | 'carousel' | 'link' | 'shared';
  content: string;
  mediaUrls?: string[];
  linkUrl?: string;
  linkTitle?: string;
  sharedPostId?: string;
  visibility: 'public' | 'friends' | 'only_me' | 'community';
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  organicImpressions?: number;
  isBoosted: boolean;
  boostCampaignId?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export type ReactionType = 'like' | 'love' | 'care' | 'haha' | 'wow' | 'sad' | 'angry';

export interface LikeRecord {
  uid: string;
  reaction?: ReactionType;
  createdAt: Timestamp;
}

export interface CommentItem {
  id: string;
  authorUid: string;
  parentCommentId?: string;
  text: string;
  createdAt: Timestamp;
}

export interface Story {
  id: string;
  authorUid: string;
  storyType: 'image' | 'video' | 'text';
  mediaUrl?: string;
  text?: string;
  bgColor?: string;
  privacy: 'public' | 'friends';
  isHighlight: boolean;
  highlightTitle?: string;
  viewsCount: number;
  expiresAt: Timestamp;
  createdAt: Timestamp;
}

export interface StoryViewRecord {
  viewerUid: string;
  reaction?: string;
  viewedAt: Timestamp;
}

export interface SparkVideo {
  id: string;
  authorUid: string;
  videoUrl: string;
  thumbnailUrl?: string;
  description: string;
  hashtags?: string[];
  soundTitle: string;
  likesCount: number;
  commentsCount: number;
  sharesCount: number;
  viewsCount: number;
  createdAt: Timestamp;
}

export interface Conversation {
  id: string;
  type: 'direct' | 'group';
  friendshipId?: string;
  participantUids: string[];
  adminUids?: string[];
  groupName?: string;
  groupPhoto?: string;
  lastMessageText?: string;
  lastMessageSenderUid?: string;
  lastMessageAt?: Timestamp;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface ConversationMember {
  uid: string;
  role: 'admin' | 'member';
  unreadCount: number;
  lastReadAt?: Timestamp;
  joinedAt: Timestamp;
}

export interface ChatMessage {
  id: string;
  senderUid: string;
  text: string;
  mediaUrl?: string;
  mediaType: 'none' | 'image' | 'video' | 'file';
  replyToId?: string;
  replyPreview?: string;
  deleted: boolean;
  createdAt: Timestamp;
}

export interface PublicPage {
  id: string;
  ownerUid: string;
  name: string;
  username: string;
  category: string;
  description?: string;
  avatarUrl?: string;
  coverUrl?: string;
  country?: string;
  followersCount: number;
  monetizationStatus: 'not_eligible' | 'eligible' | 'pending_review' | 'approved' | 'suspended';
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface PageRole {
  uid: string;
  pageId: string;
  role: PageRoleType;
  assignedBy: string;
  createdAt: Timestamp;
}

export interface PageWallet {
  id: string;
  pageId: string;
  ownerUid: string;
  pendingPoisha: number;
  availablePoisha: number;
  processingPoisha: number;
  paidPoisha: number;
  reversedPoisha: number;
  totalVerifiedGrossPoisha: number;
  totalDeductionsPoisha: number;
  totalEligibleNetPoisha: number;
  totalOwner40Poisha: number;
  totalPlatform60Poisha: number;
  updatedAt: Timestamp;
}

export interface PageLedgerEntry {
  id: string;
  pageId: string;
  ownerUid: string;
  eventType: 'ad_revenue_settlement' | 'withdrawal_hold' | 'withdrawal_paid' | 'withdrawal_reversed' | 'refund_adjustment';
  grossPoisha: number;
  deductionsPoisha: number;
  eligibleNetPoisha: number;
  ownerShare40Poisha: number;
  platformShare60Poisha: number;
  ownerPercentBps: number;
  platformPercentBps: number;
  referenceId: string;
  createdAt: Timestamp;
}

export interface PersonalWallet {
  uid: string;
  pendingPoisha: number;
  availablePoisha: number;
  processingPoisha: number;
  paidPoisha: number;
  reversedPoisha: number;
  updatedAt: Timestamp;
}

export interface LedgerEntry {
  id: string;
  uid: string;
  source: 'creator_reward' | 'withdrawal' | 'ad_deposit' | 'ad_spend' | 'ad_refund';
  direction: 'credit' | 'debit';
  amountPoisha: number;
  referenceId: string;
  note?: string;
  createdAt: Timestamp;
}

export interface WithdrawalRequest {
  id: string;
  uid: string;
  walletType: 'personal' | 'page';
  pageId?: string;
  amountPoisha: number;
  method: 'bkash' | 'nagad' | 'bank';
  accountNumberMasked: string;
  accountTitle: string;
  status: 'pending' | 'processing' | 'paid' | 'rejected' | 'reversed';
  adminNote?: string;
  reviewedBy?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export type CampaignObjective =
  | 'brand_awareness'
  | 'reach'
  | 'post_engagement'
  | 'page_followers'
  | 'video_views'
  | 'profile_visits'
  | 'website_traffic';

export interface AdCampaign {
  id: string;
  advertiserUid: string;
  sourceType: 'user_boost' | 'page_promotion' | 'ads_manager';
  postId?: string;
  pageId?: string;
  title: string;
  objective: CampaignObjective;
  creativeText?: string;
  creativeMediaUrl?: string;
  targetUrl?: string;
  targetCountry?: string;
  targetCity?: string;
  targetLanguage?: string;
  targetAgeRange?: string;
  targetInterest?: string;
  dailyBudgetPoisha: number;
  lifetimeBudgetPoisha: number;
  spentPoisha: number;
  startDate?: string;
  endDate?: string;
  status: 'draft' | 'pending_review' | 'approved' | 'active' | 'paused' | 'completed' | 'rejected';
  paymentStatus: 'unpaid' | 'pending_verification' | 'verified' | 'refunded';
  paidImpressions: number;
  paidReach: number;
  clicks: number;
  videoViews: number;
  reviewNote?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface AdPayment {
  id: string;
  campaignId: string;
  advertiserUid: string;
  amountPoisha: number;
  method: 'bkash' | 'nagad' | 'bank';
  transactionRef: string;
  status: 'pending_verification' | 'verified' | 'rejected' | 'refunded';
  verifiedBy?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface Community {
  id: string;
  creatorUid: string;
  name: string;
  description?: string;
  coverUrl?: string;
  privacy: 'public' | 'private';
  rules?: string;
  membersCount: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface CommunityMember {
  uid: string;
  role: 'admin' | 'moderator' | 'member';
  status: 'pending' | 'approved' | 'rejected';
  joinedAt: Timestamp;
}

export interface NotificationItem {
  id: string;
  recipientUid: string;
  actorUid: string;
  type: string;
  title: string;
  body: string;
  targetTab?: string;
  read: boolean;
  createdAt: Timestamp;
}

export interface ReportItem {
  id: string;
  reporterUid: string;
  targetType: 'user' | 'post' | 'page' | 'video' | 'comment' | 'community' | 'ad';
  targetId: string;
  reason: string;
  details?: string;
  status: 'open' | 'reviewing' | 'resolved' | 'dismissed';
  resolvedBy?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface PlatformSettings {
  minWithdrawalPoisha: number;
  pageMinFollowers: number;
  pageMinAgeDays: number;
  creatorMinFollowers: number;
  creatorMinAgeDays: number;
  pageOwnerShareBps: number; // default 4000 (40%)
  platformShareBps: number;  // default 6000 (60%)
  creatorPoolBps: number;    // default 4000 (40%)
  creatorVideoAllocPct: number;
  creatorPostAllocPct: number;
  creatorQualityAllocPct: number;
  updatedBy?: string;
  updatedAt: Timestamp;
}

export interface FeatureFlags {
  liveStreamingEnabled: boolean;
  marketplaceEnabled: boolean;
  voiceCallsEnabled: boolean;
  videoCallsEnabled: boolean;
  creatorGiftsEnabled: boolean;
  creatorCoinsEnabled: boolean;
  aiAssistantEnabled: boolean;
  updatedBy?: string;
  updatedAt: Timestamp;
}

export interface AdminLog {
  id: string;
  adminUid: string;
  action: string;
  targetCollection: string;
  targetId: string;
  details?: string;
  createdAt: Timestamp;
}

export type AppTab =
  | 'home'
  | 'spark'
  | 'messages'
  | 'profile'
  | 'friends'
  | 'notifications'
  | 'pages'
  | 'communities'
  | 'ads'
  | 'wallet'
  | 'admin'
  | 'settings';
