import React, { useState } from 'react';
import { doc, serverTimestamp, writeBatch } from 'firebase/firestore';
import { Loader2, Megaphone, ShieldAlert, X } from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import { bdtToPoisha, formatBDT } from '../lib/finance';
import { CampaignObjective, Post } from '../types/hearthline';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';

interface Props {
  post: Post | null;
  onClose: () => void;
}

export const BoostPostModal: React.FC<Props> = ({ post, onClose }) => {
  const { firebaseUser } = useAuth();
  const { pushToast } = useToast();

  const [objective, setObjective] = useState<CampaignObjective>('reach');
  const [dailyBdt, setDailyBdt] = useState(200);
  const [days, setDays] = useState(5);
  const [country, setCountry] = useState('Bangladesh');
  const [city, setCity] = useState('Dhaka');
  const [ageRange, setAgeRange] = useState('18-45');
  const [interest, setInterest] = useState('Culture & Creators');
  const [method, setMethod] = useState<'bkash' | 'nagad' | 'bank'>('bkash');
  const [txRef, setTxRef] = useState('');
  const [busy, setBusy] = useState(false);

  if (!post || !firebaseUser) return null;

  const safeDailyBdt = Math.max(100, Number.isFinite(dailyBdt) ? Math.round(dailyBdt) : 100);
  const safeDays = Math.min(60, Math.max(1, Number.isFinite(days) ? Math.round(days) : 1));
  const totalBdt = safeDailyBdt * safeDays;
  const dailyPoisha = bdtToPoisha(safeDailyBdt);
  const lifetimePoisha = bdtToPoisha(totalBdt);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (post.authorUid !== firebaseUser.uid) {
      pushToast('Only the post owner can boost this post.', 'error');
      return;
    }
    if (!firebaseUser.emailVerified) {
      pushToast('Verify your email first before submitting a boost campaign.', 'error');
      return;
    }
    if (!txRef.trim() || txRef.trim().length < 3) {
      pushToast('Enter your bKash, Nagad, or Bank payment transaction reference for Admin verification.', 'error');
      return;
    }

    setBusy(true);
    const campaignId = makeSafeId('camp');
    const paymentId = makeSafeId('adpay');
    const startDate = new Date().toISOString().slice(0, 10);
    const endDate = new Date(Date.now() + safeDays * 86400000).toISOString().slice(0, 10);

    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'adCampaigns', campaignId), {
        advertiserUid: firebaseUser.uid,
        sourceType: 'user_boost',
        postId: post.id,
        title: `Boost: ${(post.content || 'Media Post').slice(0, 48)}`,
        objective,
        creativeText: (post.content || '').slice(0, 1500),
        creativeMediaUrl: post.mediaUrls?.[0] || '',
        targetCountry: country.trim().slice(0, 60),
        targetCity: city.trim().slice(0, 80),
        targetLanguage: 'en_bn',
        targetAgeRange: ageRange,
        targetInterest: interest.trim().slice(0, 80),
        dailyBudgetPoisha: dailyPoisha,
        lifetimeBudgetPoisha: lifetimePoisha,
        spentPoisha: 0,
        startDate,
        endDate,
        status: 'pending_review',
        paymentStatus: 'pending_verification',
        paidImpressions: 0,
        paidReach: 0,
        clicks: 0,
        videoViews: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      batch.set(doc(db, 'adPayments', paymentId), {
        campaignId,
        advertiserUid: firebaseUser.uid,
        amountPoisha: lifetimePoisha,
        method,
        transactionRef: txRef.trim().slice(0, 80),
        status: 'pending_verification',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      batch.update(doc(db, 'posts', post.id), {
        isBoosted: true,
        boostCampaignId: campaignId,
        updatedAt: serverTimestamp(),
      });

      await batch.commit();

      pushToast('Boost campaign & payment reference submitted for Admin review.', 'success');
      onClose();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `adCampaigns/${campaignId}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[75] bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full sm:max-w-xl rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] shadow-2xl max-h-[92vh] flex flex-col overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/10">
          <div className="flex items-center gap-2.5">
            <Megaphone className="w-5 h-5 text-[#D4AF37]" />
            <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
              Boost Post Campaign
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 overflow-y-auto text-sm">
          <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-3.5 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <span>Sponsored Preview</span>
              <span className="font-semibold text-[#D4AF37]">Sponsored</span>
            </div>
            {post.mediaUrls?.[0] && (
              /\.(mp4|webm|mov|m4v)(\?|$)|\/video\/upload\//i.test(post.mediaUrls[0]) ? (
                <video
                  src={post.mediaUrls[0]}
                  muted
                  playsInline
                  className="w-full h-32 rounded-lg object-cover bg-black"
                />
              ) : (
                <img
                  src={post.mediaUrls[0]}
                  alt="Post preview"
                  referrerPolicy="no-referrer"
                  className="w-full h-32 rounded-lg object-cover bg-black/20"
                />
              )
            )}
            <p className="text-xs text-slate-700 dark:text-slate-300 line-clamp-2">
              {post.content || 'Media post promotion'}
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1.5">
              Promotion Objective
            </label>
            <select
              value={objective}
              onChange={(e) => setObjective(e.target.value as CampaignObjective)}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
            >
              <option value="reach">More Reach</option>
              <option value="post_engagement">More Engagement</option>
              <option value="video_views">More Video Views</option>
              <option value="profile_visits">More Profile Visits</option>
              <option value="page_followers">More Followers (where measurable)</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                Daily Budget (BDT ৳, min 100)
              </label>
              <input
                type="number"
                min={100}
                step={50}
                value={dailyBdt}
                onChange={(e) => setDailyBdt(Number(e.target.value))}
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm font-mono tabular-nums text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">
                Duration (Days)
              </label>
              <input
                type="number"
                min={1}
                max={60}
                value={days}
                onChange={(e) => setDays(Number(e.target.value))}
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm font-mono tabular-nums text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <input
              type="text"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              placeholder="Country"
              className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
            />
            <input
              type="text"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              placeholder="City / Region"
              className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
            />
            <select
              value={ageRange}
              onChange={(e) => setAgeRange(e.target.value)}
              className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
            >
              <option value="18-24">18–24</option>
              <option value="18-45">18–45</option>
              <option value="25-54">25–54</option>
              <option value="18-65+">All Adults (18+)</option>
            </select>
            <input
              type="text"
              value={interest}
              onChange={(e) => setInterest(e.target.value)}
              placeholder="Permitted interest category"
              className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
            />
          </div>

          <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-3.5 text-xs space-y-1.5">
            <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-white">
              <span>Maximum Spending Cap</span>
              <span className="font-mono tabular-nums text-[#D4AF37]">{formatBDT(lifetimePoisha)}</span>
            </div>
            <p className="text-slate-500 dark:text-slate-400">
              Delivery depends on real audience activity; HEARTHLINE does not guarantee specific view or follower counts and automatically stops delivery at your spending limit.
            </p>
          </div>

          <div className="space-y-2.5 pt-1 border-t border-slate-200 dark:border-white/10">
            <p className="text-xs font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-[#D4AF37]" />
              Manual Payment Verification (V1)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value as 'bkash' | 'nagad' | 'bank')}
                className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
              >
                <option value="bkash">bKash</option>
                <option value="nagad">Nagad</option>
                <option value="bank">Bank Transfer</option>
              </select>
              <input
                type="text"
                required
                value={txRef}
                onChange={(e) => setTxRef(e.target.value)}
                placeholder="Transaction ID / Ref (e.g., BKH89A21)"
                className="sm:col-span-2 h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs font-mono text-slate-900 dark:text-white"
              />
            </div>
            <p className="text-[11px] text-slate-500">
              Payment gateways are pending official merchant credentials; Admin verifies this reference before activating the campaign.
            </p>
          </div>

          <button
            type="submit"
            disabled={busy}
            className="w-full h-11 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#E5C158] cursor-pointer disabled:opacity-50"
          >
            {busy && <Loader2 className="w-4 h-4 animate-spin" />}
            Submit Boost Campaign for Admin Review
          </button>
        </form>
      </div>
    </div>
  );
};
