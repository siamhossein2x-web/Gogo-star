import React, { useEffect, useState } from 'react';
import {
  collection,
  doc,
  getDoc,
  limit,
  onSnapshot,
  orderBy,
  query,
  where,
} from 'firebase/firestore';
import {
  Check,
  MessageCircle,
  Search,
  UserMinus,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { db } from '../lib/firebase';
import {
  Community,
  FriendRequest,
  Post,
  PublicPage,
  SparkVideo,
  UserProfile,
} from '../types/hearthline';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { Avatar } from './Avatar';
import {
  acceptFriendRequest,
  openOrCreateDirectConversation,
  removeFriend,
  sendFriendRequest,
  toggleFollow,
  updateFriendRequestStatus,
} from '../lib/socialActions';

interface Props {
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onOpenProfile: (uid: string) => void;
  onOpenChat: (convId: string) => void;
  onNavigateTab: (tab: 'pages' | 'communities' | 'spark') => void;
}

export const FriendsAndDiscoveryView: React.FC<Props> = ({
  searchQuery,
  onSearchChange,
  onOpenProfile,
  onOpenChat,
  onNavigateTab,
}) => {
  const { firebaseUser, profile } = useAuth();
  const { pushToast } = useToast();

  const [tab, setTab] = useState<'requests' | 'friends' | 'discover'>('discover');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [pages, setPages] = useState<PublicPage[]>([]);
  const [communities, setCommunities] = useState<Community[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [sparks, setSparks] = useState<SparkVideo[]>([]);

  const [receivedReqs, setReceivedReqs] = useState<FriendRequest[]>([]);
  const [sentReqs, setSentReqs] = useState<FriendRequest[]>([]);
  const [friendUids, setFriendUids] = useState<Set<string>>(new Set());
  const [followingIds, setFollowingIds] = useState<Set<string>>(new Set());
  const [usersMap, setUsersMap] = useState<Record<string, UserProfile>>({});

  useEffect(() => {
    if (!firebaseUser) return;

    const u1 = onSnapshot(
      query(collection(db, 'users'), where('accountStatus', '==', 'active'), limit(50)),
      (s) => {
        const list = s.docs.map((d) => d.data() as UserProfile);
        setUsers(list);
        const map: Record<string, UserProfile> = {};
        list.forEach((u) => (map[u.uid] = u));
        setUsersMap((prev) => ({ ...prev, ...map }));
      }
    );

    const u2 = onSnapshot(query(collection(db, 'pages'), limit(30)), (s) => {
      setPages(s.docs.map((d) => ({ id: d.id, ...d.data() } as PublicPage)));
    });

    const u3 = onSnapshot(query(collection(db, 'communities'), limit(30)), (s) => {
      setCommunities(s.docs.map((d) => ({ id: d.id, ...d.data() } as Community)));
    });

    const u4 = onSnapshot(
      query(collection(db, 'posts'), where('visibility', '==', 'public'), limit(40)),
      (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as Post));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setPosts(list);
      }
    );

    const u5 = onSnapshot(query(collection(db, 'sparkVideos'), orderBy('viewsCount', 'desc'), limit(12)), (s) => {
      setSparks(s.docs.map((d) => ({ id: d.id, ...d.data() } as SparkVideo)));
    });

    const uRec = onSnapshot(
      query(collection(db, 'friendRequests'), where('toUid', '==', firebaseUser.uid)),
      async (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as FriendRequest)).filter((r) => r.status === 'pending');
        setReceivedReqs(list);
        for (const r of list) {
          const us = await getDoc(doc(db, 'users', r.fromUid));
          if (us.exists()) setUsersMap((p) => ({ ...p, [r.fromUid]: us.data() as UserProfile }));
        }
      }
    );

    const uSent = onSnapshot(
      query(collection(db, 'friendRequests'), where('fromUid', '==', firebaseUser.uid)),
      (s) => {
        setSentReqs(s.docs.map((d) => ({ id: d.id, ...d.data() } as FriendRequest)).filter((r) => r.status === 'pending'));
      }
    );

    const uFA = onSnapshot(query(collection(db, 'friendships'), where('userA', '==', firebaseUser.uid)), (s) => {
      setFriendUids((prev) => {
        const next = new Set(prev);
        s.docs.forEach((d) => next.add(d.data().userB as string));
        return next;
      });
    });

    const uFB = onSnapshot(query(collection(db, 'friendships'), where('userB', '==', firebaseUser.uid)), (s) => {
      setFriendUids((prev) => {
        const next = new Set(prev);
        s.docs.forEach((d) => next.add(d.data().userA as string));
        return next;
      });
    });

    const uFol = onSnapshot(query(collection(db, 'follows'), where('followerUid', '==', firebaseUser.uid)), (s) => {
      setFollowingIds(new Set(s.docs.map((d) => d.data().targetId as string)));
    });

    return () => {
      u1(); u2(); u3(); u4(); u5(); uRec(); uSent(); uFA(); uFB(); uFol();
    };
  }, [firebaseUser?.uid]);

  const q = searchQuery.trim().toLowerCase();
  const filteredUsers = users.filter(
    (u) =>
      u.uid !== firebaseUser?.uid &&
      (!q || u.displayName.toLowerCase().includes(q) || u.username.toLowerCase().includes(q))
  );
  const filteredPages = pages.filter(
    (p) => !q || p.name.toLowerCase().includes(q) || p.username.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
  );
  const filteredCommunities = communities.filter(
    (c) => !q || c.name.toLowerCase().includes(q) || (c.description || '').toLowerCase().includes(q)
  );
  const filteredPosts = q
    ? posts.filter((p) => p.visibility === 'public' && p.content.toLowerCase().includes(q))
    : [];
  const filteredSparks = q
    ? sparks.filter(
        (v) =>
          v.description.toLowerCase().includes(q) ||
          (v.hashtags || []).some((h) => h.toLowerCase().includes(q.replace(/^#/, '')))
      )
    : sparks.slice(0, 4);

  const friendsList = users.filter((u) => friendUids.has(u.uid));

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search people, @usernames, Pages, #hashtags, communities, posts..."
            className="w-full h-10 pl-10 pr-4 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
          />
        </div>

        <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#0A0B0E]">
          {[
            { id: 'discover', label: 'Search & Discover' },
            { id: 'requests', label: `Requests (${receivedReqs.length})` },
            { id: 'friends', label: `Friends (${friendsList.length})` },
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setTab(item.id as typeof tab)}
              className={`py-2 rounded-lg text-xs font-semibold cursor-pointer ${
                tab === item.id
                  ? 'bg-[#D4AF37] text-[#0A0B0E]'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {tab === 'requests' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">Received Friend Requests</h3>
            {receivedReqs.length === 0 ? (
              <p className="text-xs text-slate-500">No pending friend requests.</p>
            ) : (
              receivedReqs.map((r) => {
                const sender = usersMap[r.fromUid];
                return (
                  <div key={r.id} className="flex items-center justify-between gap-3 py-2 border-b last:border-0 border-slate-100 dark:border-white/5">
                    <button
                      onClick={() => onOpenProfile(r.fromUid)}
                      className="flex items-center gap-3 text-left cursor-pointer"
                    >
                      <Avatar src={sender?.photoUrl} name={sender?.displayName || 'User'} size="md" />
                      <div>
                        <p className="text-sm font-semibold">{sender?.displayName || 'HEARTHLINE User'}</p>
                        <p className="text-xs text-slate-500">@{sender?.username || 'user'}</p>
                      </div>
                    </button>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={async () => {
                          if (!firebaseUser) return;
                          await acceptFriendRequest(r.id, r.fromUid, firebaseUser.uid, profile?.displayName || 'Someone');
                          pushToast('Friend request accepted! Chat unlocked.', 'success');
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" /> Accept
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await updateFriendRequestStatus(r.id, 'rejected');
                          pushToast('Request declined.', 'info');
                        }}
                        className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 text-xs cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" /> Decline
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">Sent Requests</h3>
            {sentReqs.length === 0 ? (
              <p className="text-xs text-slate-500">No outgoing requests.</p>
            ) : (
              sentReqs.map((r) => {
                const target = usersMap[r.toUid];
                return (
                  <div key={r.id} className="flex items-center justify-between gap-3 py-2">
                    <div className="flex items-center gap-3">
                      <Avatar src={target?.photoUrl} name={target?.displayName || 'User'} size="sm" />
                      <div>
                        <p className="text-xs font-semibold">{target?.displayName || r.toUid}</p>
                        <p className="text-[11px] text-slate-500">Pending acceptance</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => updateFriendRequestStatus(r.id, 'cancelled')}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 text-xs text-rose-500 cursor-pointer"
                    >
                      Cancel Request
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {tab === 'friends' && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
          <h3 className="font-display font-semibold text-sm">Confirmed Friends</h3>
          {friendsList.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500 space-y-2">
              <Users className="w-8 h-8 mx-auto text-slate-400" />
              <p>You have no confirmed friends yet. Send a friend request from Discover.</p>
            </div>
          ) : (
            friendsList.map((fr) => (
              <div key={fr.uid} className="flex items-center justify-between gap-3 py-2 border-b last:border-0 border-slate-100 dark:border-white/5">
                <button
                  onClick={() => onOpenProfile(fr.uid)}
                  className="flex items-center gap-3 text-left cursor-pointer"
                >
                  <Avatar src={fr.photoUrl} name={fr.displayName} size="md" />
                  <div>
                    <p className="text-sm font-semibold">{fr.displayName}</p>
                    <p className="text-xs text-slate-500">@{fr.username}</p>
                  </div>
                </button>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={async () => {
                      if (!firebaseUser) return;
                      const cid = await openOrCreateDirectConversation(firebaseUser.uid, fr.uid);
                      onOpenChat(cid);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#3B82F6] text-white text-xs font-semibold cursor-pointer"
                  >
                    <MessageCircle className="w-3.5 h-3.5" /> Message
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (!firebaseUser) return;
                      await removeFriend(firebaseUser.uid, fr.uid);
                      setFriendUids((prev) => {
                        const n = new Set(prev);
                        n.delete(fr.uid);
                        return n;
                      });
                      pushToast('Friend removed.', 'info');
                    }}
                    className="p-2 rounded-xl border border-slate-200 dark:border-white/10 text-slate-400 hover:text-rose-500 cursor-pointer"
                    title="Remove friend"
                  >
                    <UserMinus className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'discover' && (
        <div className="space-y-5">
          {/* People */}
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">People on HEARTHLINE</h3>
            {filteredUsers.length === 0 ? (
              <p className="text-xs text-slate-500">No matching users found.</p>
            ) : (
              <div className="space-y-3">
                {filteredUsers.map((u) => {
                  const isFriend = friendUids.has(u.uid);
                  const isFollowing = followingIds.has(u.uid);
                  const hasPendingSent = sentReqs.some((r) => r.toUid === u.uid);

                  return (
                    <div key={u.uid} className="flex flex-wrap items-center justify-between gap-3 py-2 border-b last:border-0 border-slate-100 dark:border-white/5">
                      <button
                        onClick={() => onOpenProfile(u.uid)}
                        className="flex items-center gap-3 text-left cursor-pointer"
                      >
                        <Avatar src={u.photoUrl} name={u.displayName} size="md" />
                        <div>
                          <p className="text-sm font-semibold">{u.displayName}</p>
                          <p className="text-xs text-slate-500">
                            @{u.username} · {u.friendsCount} friends · {u.followersCount} followers
                          </p>
                        </div>
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={async () => {
                            if (!firebaseUser) return;
                            await toggleFollow(firebaseUser.uid, u.uid, 'user', isFollowing, profile?.displayName || 'Someone');
                          }}
                          className={`px-3 py-1.5 rounded-xl text-xs font-medium border cursor-pointer ${
                            isFollowing
                              ? 'border-[#3B82F6] text-[#3B82F6]'
                              : 'border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          {isFollowing ? 'Following' : 'Follow'}
                        </button>

                        {isFriend ? (
                          <button
                            type="button"
                            onClick={async () => {
                              if (!firebaseUser) return;
                              const cid = await openOrCreateDirectConversation(firebaseUser.uid, u.uid);
                              onOpenChat(cid);
                            }}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#3B82F6] text-white text-xs font-semibold cursor-pointer"
                          >
                            <MessageCircle className="w-3.5 h-3.5" /> Message
                          </button>
                        ) : (
                          <button
                            type="button"
                            disabled={hasPendingSent}
                            onClick={async () => {
                              if (!firebaseUser) return;
                              try {
                                await sendFriendRequest(firebaseUser.uid, u.uid, profile?.displayName || 'Someone');
                                pushToast('Friend request sent!', 'success');
                              } catch (err) {
                                pushToast(err instanceof Error ? err.message : 'Failed.', 'error');
                              }
                            }}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold disabled:opacity-50 cursor-pointer"
                          >
                            <UserPlus className="w-3.5 h-3.5" />
                            {hasPendingSent ? 'Requested' : 'Add Friend'}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Pages & Communities Discovery */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display font-semibold text-sm">Public Pages</h3>
                <button onClick={() => onNavigateTab('pages')} className="text-xs text-[#D4AF37] cursor-pointer">
                  Open Pages
                </button>
              </div>
              {filteredPages.slice(0, 4).map((p) => (
                <div key={p.id} className="text-xs py-1.5 border-b last:border-0 border-slate-100 dark:border-white/5">
                  <p className="font-semibold text-slate-900 dark:text-white">{p.name}</p>
                  <p className="text-slate-500">@{p.username} · {p.category} · {p.followersCount} followers</p>
                </div>
              ))}
              {filteredPages.length === 0 && <p className="text-xs text-slate-500">No Pages match.</p>}
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display font-semibold text-sm">Recommended Communities</h3>
                <button onClick={() => onNavigateTab('communities')} className="text-xs text-[#D4AF37] cursor-pointer">
                  Browse All
                </button>
              </div>
              {filteredCommunities.slice(0, 4).map((c) => (
                <div key={c.id} className="text-xs py-1.5 border-b last:border-0 border-slate-100 dark:border-white/5">
                  <p className="font-semibold text-slate-900 dark:text-white">{c.name}</p>
                  <p className="text-slate-500 capitalize">{c.privacy} · {c.membersCount} members</p>
                </div>
              ))}
              {filteredCommunities.length === 0 && <p className="text-xs text-slate-500">No Communities match.</p>}
            </div>
          </div>

          {/* Trending Spark & Matching Posts */}
          {filteredSparks.length > 0 && (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display font-semibold text-sm">Trending Spark Videos</h3>
                <button onClick={() => onNavigateTab('spark')} className="text-xs text-[#D4AF37] cursor-pointer">
                  Watch Spark
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {filteredSparks.map((sp) => (
                  <button
                    key={sp.id}
                    onClick={() => onNavigateTab('spark')}
                    className="text-left p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] hover:border-[#D4AF37] cursor-pointer"
                  >
                    <p className="text-xs font-medium line-clamp-2">{sp.description || sp.soundTitle}</p>
                    <p className="text-[11px] text-slate-500 mt-1 font-mono tabular-nums">
                      {sp.viewsCount} views · {sp.likesCount} likes
                    </p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {q && filteredPosts.length > 0 && (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-2.5">
              <h3 className="font-display font-semibold text-sm">Matching Posts</h3>
              {filteredPosts.map((p) => (
                <div key={p.id} className="text-xs py-2 border-b last:border-0 border-slate-100 dark:border-white/5">
                  <p className="line-clamp-2 text-slate-800 dark:text-slate-200">{p.content}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
