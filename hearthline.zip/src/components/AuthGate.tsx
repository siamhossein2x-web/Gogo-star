import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPopup,
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import {
  ArrowRight,
  CheckCircle2,
  Globe,
  Loader2,
  Lock,
  Mail,
  MapPin,
  RefreshCw,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { auth, db, googleProvider } from '../lib/firebase';
import { BRAND_ASSETS } from '../lib/assets';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { MediaUploadInput } from './MediaUploadInput';

export const AuthGate: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const {
    firebaseUser,
    profile,
    authReady,
    needsOnboarding,
    language,
    setLanguage,
    completeOnboarding,
    refreshVerification,
    resendVerificationEmail,
    signOut,
  } = useAuth();
  const { pushToast } = useToast();

  const [mode, setMode] = useState<'signin' | 'signup' | 'reset'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [authNotice, setAuthNotice] = useState<string | null>(null);

  // Onboarding state
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [locationConsent, setLocationConsent] = useState(false);
  const [locationCity, setLocationCity] = useState('');
  const [locationCountry, setLocationCountry] = useState('Bangladesh');
  const [usernameStatus, setUsernameStatus] = useState<'idle' | 'checking' | 'available' | 'taken'>('idle');

  if (!authReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0A0B0E] text-slate-200">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl border border-[#D4AF37]/40 bg-[#12141A] flex items-center justify-center text-xl font-display font-bold text-[#D4AF37]">
            H
          </div>
          <div className="flex items-center gap-2 text-sm text-slate-400">
            <Loader2 className="w-4 h-4 animate-spin text-[#D4AF37]" />
            <span>Initializing HEARTHLINE...</span>
          </div>
        </div>
      </div>
    );
  }

  const handleGoogleSignIn = async () => {
    setBusy(true);
    setAuthNotice(null);
    try {
      await signInWithPopup(auth, googleProvider);
      pushToast('Signed in with Google.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed.';
      setAuthNotice(msg);
      pushToast(msg, 'error');
    } finally {
      setBusy(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setAuthNotice(null);
    try {
      if (mode === 'reset') {
        await sendPasswordResetEmail(auth, email.trim());
        pushToast('Password reset email sent. Check your inbox.', 'success');
        setMode('signin');
      } else if (mode === 'signup') {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await sendEmailVerification(cred.user);
        pushToast('Account created! Please check your inbox to verify your email.', 'success');
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
        pushToast('Welcome back to HEARTHLINE.', 'success');
      }
    } catch (err: unknown) {
      const code = (err as { code?: string })?.code || '';
      if (code === 'auth/operation-not-allowed') {
        setAuthNotice(
          'Email/Password sign-in is not yet enabled in Firebase Console -> Authentication -> Sign-in method. Enable Email/Password there, or sign in immediately with Google.'
        );
      } else {
        setAuthNotice(err instanceof Error ? err.message : 'Authentication error.');
      }
    } finally {
      setBusy(false);
    }
  };

  const checkUsername = async (raw: string) => {
    const clean = raw.toLowerCase().replace(/[^a-z0-9_]/g, '');
    setUsername(clean);
    if (clean.length < 3) {
      setUsernameStatus('idle');
      return;
    }
    setUsernameStatus('checking');
    try {
      const snap = await getDoc(doc(db, 'usernames', clean));
      setUsernameStatus(snap.exists() ? 'taken' : 'available');
    } catch {
      setUsernameStatus('idle');
    }
  };

  const handleCompleteOnboarding = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!displayName.trim() || username.length < 3) {
      pushToast('Please provide a display name and a username (min 3 chars).', 'error');
      return;
    }
    setBusy(true);
    try {
      await completeOnboarding({
        username,
        displayName,
        bio,
        photoUrl: photoUrl || firebaseUser?.photoURL || '',
        locationCity,
        locationCountry,
        locationConsent,
      });
      pushToast('HEARTHLINE profile created!', 'success');
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Could not complete profile.', 'error');
    } finally {
      setBusy(false);
    }
  };

  // Unauthenticated Landing / Login Screen
  if (!firebaseUser) {
    return (
      <div className="min-h-screen bg-[#0A0B0E] text-[#F3F4F6] grid lg:grid-cols-2">
        {/* Left Editorial Hero */}
        <div className="relative hidden lg:flex flex-col justify-between p-12 overflow-hidden border-r border-white/10">
          <img
            src={BRAND_ASSETS.welcomeCover}
            alt="HEARTHLINE community rooftop gathering"
            className="absolute inset-0 w-full h-full object-cover opacity-55"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0B0E] via-[#0A0B0E]/60 to-[#0A0B0E]/75" />

          <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] flex items-center justify-center font-display font-extrabold text-xl">
                H
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-white">
                HEARTHLINE
              </span>
            </div>
            <button
              onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/15 bg-black/40 text-xs font-medium text-slate-200 hover:border-[#D4AF37] cursor-pointer"
            >
              <Globe className="w-3.5 h-3.5 text-[#D4AF37]" />
              {language === 'en' ? 'বাংলা' : 'English'}
            </button>
          </div>

          <div className="relative z-10 max-w-lg space-y-5">
            <h1 className="font-display text-4xl xl:text-5xl font-bold tracking-tight text-white leading-[1.12]">
              Your World, Your People, Your Stories.
            </h1>
            <p className="text-base text-slate-300 leading-relaxed">
              Connect with real friends, publish stories and vertical Spark videos, build monetized Public Pages with transparent 40/60 owner revenue sharing, and launch BDT ad campaigns.
            </p>
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-white/15 text-xs text-slate-300">
              <div>
                <p className="font-semibold text-[#D4AF37]">40 / 60 Split</p>
                <p className="text-slate-400 mt-0.5">Owner-only Page Wallet</p>
              </div>
              <div>
                <p className="font-semibold text-[#3B82F6]">Real-Time Chat</p>
                <p className="text-slate-400 mt-0.5">1-on-1 & Group Threads</p>
              </div>
              <div>
                <p className="font-semibold text-white">BDT (৳) Native</p>
                <p className="text-slate-400 mt-0.5">Ads & Payout Ledger</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Auth Panel */}
        <div className="flex items-center justify-center p-6 sm:p-10">
          <div className="w-full max-w-md space-y-6">
            <div className="flex items-center justify-between lg:hidden">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#D4AF37] text-[#0A0B0E] flex items-center justify-center font-display font-extrabold text-lg">
                  H
                </div>
                <span className="font-display font-bold text-lg text-white">HEARTHLINE</span>
              </div>
              <button
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                className="px-2.5 py-1.5 rounded-lg border border-white/15 text-xs text-slate-300 cursor-pointer"
              >
                {language === 'en' ? 'বাংলা' : 'EN'}
              </button>
            </div>

            <div className="space-y-1.5">
              <h2 className="font-display text-2xl font-bold text-white">
                {mode === 'signin'
                  ? 'Sign in to HEARTHLINE'
                  : mode === 'signup'
                  ? 'Create your account'
                  : 'Reset your password'}
              </h2>
              <p className="text-sm text-slate-400">
                {mode === 'signin'
                  ? 'Continue with Google or your verified email.'
                  : mode === 'signup'
                  ? 'Join HEARTHLINE with a verified account.'
                  : 'Enter your account email to receive a reset link.'}
              </p>
            </div>

            {authNotice && (
              <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-xs text-amber-200 leading-relaxed">
                {authNotice}
              </div>
            )}

            <button
              type="button"
              disabled={busy}
              onClick={handleGoogleSignIn}
              className="w-full h-11 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold text-sm flex items-center justify-center gap-2.5 hover:bg-[#E5C158] transition-colors cursor-pointer disabled:opacity-50"
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
              Continue with Google
            </button>

            <div className="flex items-center gap-3 text-xs text-slate-500">
              <div className="h-px flex-1 bg-white/10" />
              <span>or use email</span>
              <div className="h-px flex-1 bg-white/10" />
            </div>

            <form onSubmit={handleEmailSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full h-10 pl-10 pr-3.5 rounded-xl border border-white/10 bg-[#13151B] text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {mode !== 'reset' && (
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full h-10 pl-10 pr-3.5 rounded-xl border border-white/10 bg-[#13151B] text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={busy}
                className="w-full h-11 rounded-xl border border-white/15 bg-[#161922] text-white font-medium text-sm flex items-center justify-center gap-2 hover:border-[#D4AF37]/60 transition-colors cursor-pointer disabled:opacity-50"
              >
                {busy && <Loader2 className="w-4 h-4 animate-spin" />}
                <span>
                  {mode === 'signin'
                    ? 'Sign In with Email'
                    : mode === 'signup'
                    ? 'Register Account'
                    : 'Send Reset Link'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
              {mode === 'signin' ? (
                <>
                  <button onClick={() => setMode('signup')} className="hover:text-[#D4AF37] cursor-pointer">
                    Need an account? Register
                  </button>
                  <button onClick={() => setMode('reset')} className="hover:text-white cursor-pointer">
                    Forgot password?
                  </button>
                </>
              ) : (
                <button onClick={() => setMode('signin')} className="hover:text-[#D4AF37] cursor-pointer">
                  Back to Sign In
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Onboarding Screen: Username Selection + Profile Setup
  if (needsOnboarding) {
    return (
      <div className="min-h-screen bg-[#0A0B0E] text-white flex items-center justify-center p-6">
        <div className="max-w-lg w-full rounded-2xl border border-white/10 bg-[#12141A] p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-display text-2xl font-bold text-white">Complete Your Profile</h1>
              <p className="text-sm text-slate-400 mt-1">
                Choose a unique username to join HEARTHLINE.
              </p>
            </div>
            <button onClick={signOut} className="text-xs text-slate-400 hover:text-white cursor-pointer">
              Sign out
            </button>
          </div>

          <form onSubmit={handleCompleteOnboarding} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Unique Username (lowercase letters, numbers, underscores)
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-slate-500 text-sm">@</span>
                <input
                  type="text"
                  required
                  minLength={3}
                  maxLength={30}
                  value={username}
                  onChange={(e) => checkUsername(e.target.value)}
                  placeholder="arian_rahman"
                  className="w-full h-10 pl-8 pr-24 rounded-xl border border-white/10 bg-[#0A0B0E] text-sm text-white focus:outline-none focus:border-[#D4AF37]"
                />
                <span className="absolute right-3 top-2.5 text-xs">
                  {usernameStatus === 'checking' && <span className="text-slate-400">Checking...</span>}
                  {usernameStatus === 'available' && <span className="text-emerald-400">Available</span>}
                  {usernameStatus === 'taken' && <span className="text-rose-400">Taken</span>}
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Display Name</label>
              <input
                type="text"
                required
                maxLength={80}
                value={displayName || firebaseUser.displayName || ''}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="Arian Rahman"
                className="w-full h-10 px-3.5 rounded-xl border border-white/10 bg-[#0A0B0E] text-sm text-white focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">Bio</label>
              <textarea
                rows={2}
                maxLength={500}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Creator, builder, storyteller..."
                className="w-full p-3 rounded-xl border border-white/10 bg-[#0A0B0E] text-sm text-white focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <MediaUploadInput
              accept="image/*"
              mediaKind="image"
              label="Upload Profile Photo"
              value={photoUrl}
              onUploaded={(url) => setPhotoUrl(url)}
            />

            <div className="rounded-xl border border-white/10 bg-[#0A0B0E] p-3.5 space-y-3">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={locationConsent}
                  onChange={(e) => setLocationConsent(e.target.checked)}
                  className="mt-1 accent-[#D4AF37]"
                />
                <span className="text-xs text-slate-300">
                  <strong className="text-white inline-flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" /> Location Consent (Optional)
                  </strong>
                  <span className="block text-slate-400 mt-0.5">
                    Allow displaying my city/country on my profile and receiving localized content.
                  </span>
                </span>
              </label>
              {locationConsent && (
                <div className="grid grid-cols-2 gap-2.5">
                  <input
                    type="text"
                    value={locationCity}
                    onChange={(e) => setLocationCity(e.target.value)}
                    placeholder="City (e.g., Dhaka)"
                    className="h-9 px-3 rounded-lg border border-white/10 bg-[#12141A] text-xs text-white"
                  />
                  <input
                    type="text"
                    value={locationCountry}
                    onChange={(e) => setLocationCountry(e.target.value)}
                    placeholder="Country (e.g., Bangladesh)"
                    className="h-9 px-3 rounded-lg border border-white/10 bg-[#12141A] text-xs text-white"
                  />
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={busy || usernameStatus === 'taken'}
              className="w-full h-11 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#E5C158] transition-colors cursor-pointer disabled:opacity-50"
            >
              {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserCheck className="w-4 h-4" />}
              Launch HEARTHLINE Profile
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Account Deactivated Notice
  if (profile?.accountStatus === 'suspended') {
    return (
      <div className="min-h-screen bg-[#0A0B0E] text-white flex items-center justify-center p-6">
        <div className="max-w-md w-full rounded-2xl border border-rose-500/30 bg-[#12141A] p-6 space-y-4">
          <h2 className="font-display text-xl font-bold text-rose-400">Account Suspended</h2>
          <p className="text-sm text-slate-300">
            This account has been suspended by HEARTHLINE moderation for policy violations.
          </p>
          <button
            onClick={signOut}
            className="px-4 py-2 rounded-xl bg-white/10 text-sm font-medium hover:bg-white/20 cursor-pointer"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      {!firebaseUser.emailVerified && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-2.5 text-xs text-amber-200 flex flex-wrap items-center justify-between gap-3">
          <span>
            Your email ({firebaseUser.email}) is unverified. Verify your email to publish posts, send friend requests, and access wallets.
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={async () => {
                await resendVerificationEmail();
                pushToast('Verification email resent.', 'success');
              }}
              className="px-3 py-1 rounded-lg bg-amber-500/20 border border-amber-500/40 hover:bg-amber-500/30 font-medium cursor-pointer"
            >
              Resend Email
            </button>
            <button
              onClick={async () => {
                const ok = await refreshVerification();
                pushToast(ok ? 'Email verified!' : 'Not verified yet — check your inbox.', ok ? 'success' : 'info');
              }}
              className="inline-flex items-center gap-1 px-3 py-1 rounded-lg bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              I&apos;ve Verified
            </button>
          </div>
        </div>
      )}
      {profile?.accountStatus === 'deactivated' && (
        <div className="bg-blue-500/15 border-b border-blue-500/30 px-4 py-2.5 text-xs text-blue-200 flex items-center justify-between">
          <span>Your account is currently deactivated and hidden from public search. Reactivate in Settings anytime.</span>
          <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
        </div>
      )}
      {children}
    </>
  );
};
