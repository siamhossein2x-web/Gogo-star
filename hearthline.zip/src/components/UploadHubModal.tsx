import React, { useEffect, useState } from 'react';
import { doc, serverTimestamp, setDoc, Timestamp } from 'firebase/firestore';
import { Film, Image as ImageIcon, Loader2, Sparkles, Type, X } from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { MediaUploadInput } from './MediaUploadInput';

interface Props {
  open: boolean;
  initialMode?: 'post' | 'story' | 'spark';
  onClose: () => void;
}

interface MediaAttachment {
  url: string;
  kind: 'image' | 'video';
}

export const UploadHubModal: React.FC<Props> = ({ open, initialMode = 'post', onClose }) => {
  const { firebaseUser } = useAuth();
  const { pushToast } = useToast();
  const [mode, setMode] = useState<'post' | 'story' | 'spark'>(initialMode);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) setMode(initialMode);
  }, [open, initialMode]);

  // Post fields
  const [postText, setPostText] = useState('');
  const [postMediaItems, setPostMediaItems] = useState<MediaAttachment[]>([]);
  const [postVisibility, setPostVisibility] = useState<'public' | 'friends' | 'only_me'>('public');
  const [linkUrl, setLinkUrl] = useState('');
  const [linkTitle, setLinkTitle] = useState('');

  // Story fields
  const [storyType, setStoryType] = useState<'image' | 'video' | 'text'>('image');
  const [storyMediaUrl, setStoryMediaUrl] = useState('');
  const [storyText, setStoryText] = useState('');
  const [storyBg, setStoryBg] = useState('#141824');
  const [storyPrivacy, setStoryPrivacy] = useState<'public' | 'friends'>('friends');

  // Spark fields
  const [sparkVideoUrl, setSparkVideoUrl] = useState('');
  const [sparkDesc, setSparkDesc] = useState('');
  const [sparkTags, setSparkTags] = useState('');
  const [sparkSound, setSparkSound] = useState('Original Audio — HEARTHLINE');

  if (!open || !firebaseUser) return null;

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser.emailVerified) {
      pushToast('Please verify your email address before publishing.', 'error');
      return;
    }
    setBusy(true);
    try {
      if (mode === 'post') {
        const cleanLink = linkUrl.trim();
        if (!postText.trim() && postMediaItems.length === 0 && !cleanLink) {
          throw new Error('Add text, media, or a link preview before publishing.');
        }
        if (cleanLink && !/^https?:\/\//i.test(cleanLink)) {
          throw new Error('Link URL must begin with https:// or http://.');
        }
        const postId = makeSafeId('post');
        const postType =
          postMediaItems.length > 1
            ? 'carousel'
            : postMediaItems.length === 1
            ? postMediaItems[0].kind
            : cleanLink
            ? 'link'
            : 'text';
        await setDoc(doc(db, 'posts', postId), {
          authorUid: firebaseUser.uid,
          authorType: 'user',
          postType,
          content: postText.trim().slice(0, 5000),
          mediaUrls: postMediaItems.map((m) => m.url),
          linkUrl: cleanLink.slice(0, 1024),
          linkTitle: linkTitle.trim().slice(0, 200),
          visibility: postVisibility,
          likesCount: 0,
          commentsCount: 0,
          sharesCount: 0,
          organicImpressions: 0,
          isBoosted: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        pushToast('Post published to your feed!', 'success');
        setPostText('');
        setPostMediaItems([]);
        setLinkUrl('');
        setLinkTitle('');
        onClose();
      } else if (mode === 'story') {
        if (storyType !== 'text' && !storyMediaUrl) {
          throw new Error('Please upload or attach media for your story.');
        }
        if (storyType === 'text' && !storyText.trim()) {
          throw new Error('Please enter story text.');
        }
        const storyId = makeSafeId('story');
        const expiresAt = Timestamp.fromMillis(Date.now() + 24 * 60 * 60 * 1000);
        await setDoc(doc(db, 'stories', storyId), {
          authorUid: firebaseUser.uid,
          storyType,
          mediaUrl: storyType === 'text' ? '' : storyMediaUrl,
          text: storyText.trim().slice(0, 500),
          bgColor: storyBg,
          privacy: storyPrivacy,
          isHighlight: false,
          viewsCount: 0,
          expiresAt,
          createdAt: serverTimestamp(),
        });
        pushToast('Story live for 24 hours!', 'success');
        setStoryMediaUrl('');
        setStoryText('');
        onClose();
      } else {
        if (!sparkVideoUrl) {
          throw new Error('Please upload or attach a Cloudinary video URL for Spark.');
        }
        const videoId = makeSafeId('spark');
        const hashtags = sparkTags
          .split(/[\s,]+/)
          .map((t) => t.replace(/^#/, '').trim().toLowerCase())
          .filter(Boolean)
          .slice(0, 10);
        await setDoc(doc(db, 'sparkVideos', videoId), {
          authorUid: firebaseUser.uid,
          videoUrl: sparkVideoUrl,
          description: sparkDesc.trim().slice(0, 1000),
          hashtags,
          soundTitle: sparkSound.trim().slice(0, 140) || 'Original Audio',
          likesCount: 0,
          commentsCount: 0,
          sharesCount: 0,
          viewsCount: 0,
          createdAt: serverTimestamp(),
        });
        pushToast('Spark short video published!', 'success');
        setSparkVideoUrl('');
        setSparkDesc('');
        setSparkTags('');
        onClose();
      }
    } catch (err) {
      if (err instanceof Error && !err.message.includes('Firebase')) {
        pushToast(err.message, 'error');
      } else {
        handleFirestoreError(
          err,
          OperationType.CREATE,
          mode === 'post' ? 'posts' : mode === 'story' ? 'stories' : 'sparkVideos'
        );
      }
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/10">
          <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
            Create on HEARTHLINE
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="px-5 pt-4">
          <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#0A0B0E]">
            {[
              { id: 'post', label: 'Feed Post', icon: ImageIcon },
              { id: 'story', label: '24h Story', icon: Sparkles },
              { id: 'spark', label: 'Spark Video', icon: Film },
            ].map((item) => {
              const Icon = item.icon;
              const active = mode === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setMode(item.id as 'post' | 'story' | 'spark')}
                  className={`flex items-center justify-center gap-1.5 min-h-[40px] py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                    active
                      ? 'bg-[#D4AF37] text-[#0A0B0E]'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>

        <form onSubmit={handlePublish} className="p-5 space-y-4 overflow-y-auto">
          {mode === 'post' && (
            <>
              <textarea
                rows={4}
                value={postText}
                onChange={(e) => setPostText(e.target.value)}
                placeholder="What's on your mind? Share a story, thought, or update..."
                className="w-full p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#D4AF37]"
              />
              <MediaUploadInput
                accept="image/*,video/*"
                mediaKind="auto"
                label={`Add Photo / Video (${postMediaItems.length}/10)`}
                onUploaded={(url, kind) => {
                  setPostMediaItems((prev) => [...prev.slice(0, 9), { url, kind }]);
                }}
              />
              {postMediaItems.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {postMediaItems.map((item, i) => (
                    <div
                      key={`${item.url}_${i}`}
                      className="relative w-20 h-20 rounded-xl overflow-hidden border border-slate-200 dark:border-white/10 bg-black"
                    >
                      {item.kind === 'video' ? (
                        <video src={item.url} className="w-full h-full object-cover" muted />
                      ) : (
                        <img
                          src={item.url}
                          alt={`Attachment ${i + 1}`}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      )}
                      <button
                        type="button"
                        aria-label="Remove attachment"
                        onClick={() => setPostMediaItems((prev) => prev.filter((_, idx) => idx !== i))}
                        className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/75 text-white flex items-center justify-center text-xs cursor-pointer"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <input
                  type="url"
                  value={linkUrl}
                  onChange={(e) => setLinkUrl(e.target.value)}
                  placeholder="Optional Link URL (https://...)"
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
                />
                <input
                  type="text"
                  value={linkTitle}
                  onChange={(e) => setLinkTitle(e.target.value)}
                  placeholder="Link Preview Title"
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
                />
              </div>
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Visibility</label>
                <select
                  value={postVisibility}
                  onChange={(e) => setPostVisibility(e.target.value as 'public' | 'friends' | 'only_me')}
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
                >
                  <option value="public">Public</option>
                  <option value="friends">Friends Only</option>
                  <option value="only_me">Only Me</option>
                </select>
              </div>
            </>
          )}

          {mode === 'story' && (
            <>
              <div className="flex items-center gap-2">
                {(['image', 'video', 'text'] as const).map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => {
                      setStoryType(t);
                      setStoryMediaUrl('');
                    }}
                    className={`px-3 py-2 rounded-lg text-xs font-medium border cursor-pointer capitalize whitespace-nowrap ${
                      storyType === t
                        ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#D4AF37]'
                        : 'border-slate-200 dark:border-white/10 text-slate-500'
                    }`}
                  >
                    {t === 'text' && <Type className="w-3 h-3 inline mr-1" />}
                    {t} Story
                  </button>
                ))}
              </div>
              {storyType === 'text' ? (
                <div className="space-y-3">
                  <textarea
                    rows={4}
                    value={storyText}
                    onChange={(e) => setStoryText(e.target.value)}
                    placeholder="Write a 24-hour text story..."
                    style={{ backgroundColor: storyBg }}
                    className="w-full p-4 rounded-2xl text-white text-center font-display text-lg focus:outline-none border border-white/15"
                  />
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">Backdrop:</span>
                    {['#141824', '#1F170B', '#0E2433', '#241222'].map((c) => (
                      <button
                        key={c}
                        type="button"
                        aria-label={`Select backdrop ${c}`}
                        onClick={() => setStoryBg(c)}
                        style={{ backgroundColor: c }}
                        className={`w-7 h-7 rounded-full border-2 cursor-pointer ${
                          storyBg === c ? 'border-[#D4AF37]' : 'border-white/20'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              ) : (
                <>
                  <MediaUploadInput
                    accept={storyType === 'video' ? 'video/*' : 'image/*'}
                    mediaKind={storyType}
                    label={`Upload ${storyType === 'video' ? 'Video' : 'Photo'} Story`}
                    value={storyMediaUrl}
                    onUploaded={(url) => setStoryMediaUrl(url)}
                  />
                  {storyMediaUrl && (
                    <div className="rounded-xl overflow-hidden border border-slate-200 dark:border-white/10 bg-black max-h-48">
                      {storyType === 'video' ? (
                        <video src={storyMediaUrl} controls muted className="w-full max-h-48 object-contain" />
                      ) : (
                        <img
                          src={storyMediaUrl}
                          alt="Story preview"
                          referrerPolicy="no-referrer"
                          className="w-full max-h-48 object-cover"
                        />
                      )}
                    </div>
                  )}
                  <input
                    type="text"
                    value={storyText}
                    onChange={(e) => setStoryText(e.target.value)}
                    placeholder="Optional caption overlay..."
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
                  />
                </>
              )}
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Story Privacy</label>
                <select
                  value={storyPrivacy}
                  onChange={(e) => setStoryPrivacy(e.target.value as 'public' | 'friends')}
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
                >
                  <option value="friends">Friends Only</option>
                  <option value="public">Public</option>
                </select>
              </div>
            </>
          )}

          {mode === 'spark' && (
            <>
              <MediaUploadInput
                accept="video/*"
                mediaKind="video"
                label="Upload Spark Vertical Video"
                value={sparkVideoUrl}
                onUploaded={(url) => setSparkVideoUrl(url)}
              />
              {sparkVideoUrl && (
                <video
                  src={sparkVideoUrl}
                  controls
                  muted
                  className="w-full max-h-48 rounded-xl bg-black object-contain"
                />
              )}
              <textarea
                rows={3}
                value={sparkDesc}
                onChange={(e) => setSparkDesc(e.target.value)}
                placeholder="Describe your Spark short video..."
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm text-slate-900 dark:text-white"
              />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <input
                  type="text"
                  value={sparkTags}
                  onChange={(e) => setSparkTags(e.target.value)}
                  placeholder="Hashtags (e.g. dhaka, music, tech)"
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
                />
                <input
                  type="text"
                  value={sparkSound}
                  onChange={(e) => setSparkSound(e.target.value)}
                  placeholder="Sound Title"
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white"
                />
              </div>
            </>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full h-11 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold text-sm flex items-center justify-center gap-2 hover:bg-[#E5C158] transition-colors cursor-pointer disabled:opacity-50"
          >
            {busy && <Loader2 className="w-4 h-4 animate-spin" />}
            Publish {mode === 'post' ? 'Post' : mode === 'story' ? '24h Story' : 'Spark Video'}
          </button>
        </form>
      </div>
    </div>
  );
};
