import React, { useEffect, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  increment,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  Check,
  Compass,
  Flag,
  Lock,
  LogOut,
  Plus,
  Search,
  Settings,
  Shield,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import { Community, CommunityMember, Post, UserProfile } from '../types/hearthline';
import { createNotification, useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { PostCard } from './PostCard';
import { Avatar } from './Avatar';
import { MediaUploadInput } from './MediaUploadInput';
import { submitReport } from '../lib/socialActions';

interface Props {
  onOpenProfile: (uid: string) => void;
}

export const CommunitiesView: React.FC<Props> = ({ onOpenProfile }) => {
  const { firebaseUser } = useAuth();
  const { pushToast } = useToast();

  const [communities, setCommunities] = useState<Community[]>([]);
  const [myMembershipByComm, setMyMembershipByComm] = useState<Record<string, CommunityMember>>({});
  const [directoryFilter, setDirectoryFilter] = useState<'all' | 'mine' | 'public' | 'private'>('all');
  const [searchText, setSearchText] = useState('');

  const [selected, setSelected] = useState<Community | null>(null);
  const [members, setMembers] = useState<CommunityMember[]>([]);
  const [communityPosts, setCommunityPosts] = useState<Post[]>([]);
  const [usersMap, setUsersMap] = useState<Record<string, UserProfile>>({});

  // Community post composer
  const [newPostText, setNewPostText] = useState('');
  const [newPostMedia, setNewPostMedia] = useState('');
  const [newPostKind, setNewPostKind] = useState<'image' | 'video'>('image');
  const [busyPost, setBusyPost] = useState(false);

  // Create community modal
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [rules, setRules] = useState('Be respectful, publish original posts, no spam.');
  const [privacy, setPrivacy] = useState<'public' | 'private'>('public');
  const [coverUrl, setCoverUrl] = useState('');
  const [busyCreate, setBusyCreate] = useState(false);

  // Edit community settings
  const [showSettings, setShowSettings] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editRules, setEditRules] = useState('');
  const [editPrivacy, setEditPrivacy] = useState<'public' | 'private'>('public');
  const [editCoverUrl, setEditCoverUrl] = useState('');
  const [busySettings, setBusySettings] = useState(false);

  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      query(collection(db, 'communities'), orderBy('createdAt', 'desc')),
      async (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as Community));
        setCommunities(list);
        setSelected((prev) => {
          if (!prev) return null;
          return list.find((c) => c.id === prev.id) || prev;
        });

        const memMap: Record<string, CommunityMember> = {};
        await Promise.all(
          list.map(async (c) => {
            try {
              const mSnap = await getDoc(doc(db, 'communities', c.id, 'members', firebaseUser.uid));
              if (mSnap.exists()) {
                memMap[c.id] = mSnap.data() as CommunityMember;
              }
            } catch {
              // ignore
            }
          })
        );
        setMyMembershipByComm(memMap);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'communities')
    );
    return () => unsub();
  }, [firebaseUser?.uid]);

  useEffect(() => {
    if (!selected || !firebaseUser) return;
    setEditName(selected.name);
    setEditDesc(selected.description || '');
    setEditRules(selected.rules || '');
    setEditPrivacy(selected.privacy);
    setEditCoverUrl(selected.coverUrl || '');
    setShowSettings(false);

    const unsubMem = onSnapshot(
      collection(db, 'communities', selected.id, 'members'),
      async (s) => {
        const list = s.docs.map((d) => d.data() as CommunityMember);
        setMembers(list);
        const me = list.find((m) => m.uid === firebaseUser.uid);
        setMyMembershipByComm((prev) => {
          const copy = { ...prev };
          if (me) copy[selected.id] = me;
          else delete copy[selected.id];
          return copy;
        });

        const uids = list.map((m) => m.uid).filter((u) => !usersMap[u]);
        if (uids.length > 0) {
          const loaded: Record<string, UserProfile> = {};
          await Promise.all(
            uids.map(async (u) => {
              try {
                const us = await getDoc(doc(db, 'users', u));
                if (us.exists()) loaded[u] = us.data() as UserProfile;
              } catch {
                // ignore
              }
            })
          );
          if (Object.keys(loaded).length > 0) {
            setUsersMap((p) => ({ ...p, ...loaded }));
          }
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `communities/${selected.id}/members`)
    );

    const unsubPosts = onSnapshot(
      query(
        collection(db, 'posts'),
        where('communityId', '==', selected.id),
        where('visibility', '==', 'community')
      ),
      async (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as Post));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setCommunityPosts(list);
        const authorUids = list.map((p) => p.authorUid).filter((u) => !usersMap[u]);
        if (authorUids.length > 0) {
          const loaded: Record<string, UserProfile> = {};
          await Promise.all(
            Array.from(new Set(authorUids)).map(async (u) => {
              try {
                const us = await getDoc(doc(db, 'users', u));
                if (us.exists()) loaded[u] = us.data() as UserProfile;
              } catch {
                // ignore
              }
            })
          );
          if (Object.keys(loaded).length > 0) {
            setUsersMap((p) => ({ ...p, ...loaded }));
          }
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'posts')
    );

    return () => {
      unsubMem();
      unsubPosts();
    };
  }, [selected?.id, firebaseUser?.uid]);

  const handleCreateCommunity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to create a community.', 'error');
      return;
    }
    if (name.trim().length < 2) {
      pushToast('Community name must be at least 2 characters.', 'error');
      return;
    }
    setBusyCreate(true);
    const cid = makeSafeId('comm');
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'communities', cid), {
        creatorUid: firebaseUser.uid,
        name: name.trim().slice(0, 100),
        description: desc.trim().slice(0, 1000),
        ...(coverUrl ? { coverUrl } : {}),
        privacy,
        rules: rules.trim().slice(0, 2000),
        membersCount: 1,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'communities', cid, 'members', firebaseUser.uid), {
        uid: firebaseUser.uid,
        role: 'admin',
        status: 'approved',
        joinedAt: serverTimestamp(),
      });
      await batch.commit();
      setShowCreate(false);
      setName('');
      setDesc('');
      setCoverUrl('');
      pushToast('Community created!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `communities/${cid}`);
    } finally {
      setBusyCreate(false);
    }
  };

  const myMembership = selected ? members.find((m) => m.uid === firebaseUser?.uid) : undefined;
  const isCommAdmin =
    myMembership?.status === 'approved' &&
    (myMembership.role === 'admin' || myMembership.role === 'moderator');

  const handleJoin = async (c: Community) => {
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to join communities.', 'error');
      return;
    }
    const existing = members.find((m) => m.uid === firebaseUser.uid);
    const memRef = doc(db, 'communities', c.id, 'members', firebaseUser.uid);
    try {
      if (existing?.status === 'rejected') {
        await updateDoc(memRef, {
          status: 'pending',
          role: 'member',
          joinedAt: serverTimestamp(),
        });
        pushToast('Join request re-submitted to community admins.', 'info');
        return;
      }

      const batch = writeBatch(db);
      batch.set(memRef, {
        uid: firebaseUser.uid,
        role: 'member',
        status: c.privacy === 'public' ? 'approved' : 'pending',
        joinedAt: serverTimestamp(),
      });
      if (c.privacy === 'public') {
        batch.update(doc(db, 'communities', c.id), {
          membersCount: increment(1),
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();

      if (c.privacy === 'public') {
        pushToast(`Joined ${c.name}!`, 'success');
      } else {
        pushToast('Join request sent to community admins.', 'info');
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `communities/${c.id}/members`);
    }
  };

  const handleLeaveOrCancel = async (c: Community) => {
    if (!firebaseUser || !myMembership) return;
    if (c.creatorUid === firebaseUser.uid) {
      pushToast('Community creators cannot leave their own community.', 'error');
      return;
    }
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'communities', c.id, 'members', firebaseUser.uid));
      if (myMembership.status === 'approved') {
        batch.update(doc(db, 'communities', c.id), {
          membersCount: increment(-1),
          updatedAt: serverTimestamp(),
        });
      }
      await batch.commit();
      pushToast(
        myMembership.status === 'pending' ? 'Join request cancelled.' : `Left ${c.name}.`,
        'info'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `communities/${c.id}/members/${firebaseUser.uid}`);
    }
  };

  const handlePublishCommunityPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser?.emailVerified || !selected || (!newPostText.trim() && !newPostMedia)) return;
    setBusyPost(true);
    const pid = makeSafeId('post');
    try {
      await setDoc(doc(db, 'posts', pid), {
        authorUid: firebaseUser.uid,
        authorType: 'user',
        communityId: selected.id,
        postType: newPostMedia ? newPostKind : 'text',
        content: newPostText.trim().slice(0, 5000),
        mediaUrls: newPostMedia ? [newPostMedia] : [],
        visibility: 'community',
        likesCount: 0,
        commentsCount: 0,
        sharesCount: 0,
        isBoosted: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setNewPostText('');
      setNewPostMedia('');
      pushToast('Posted to community.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `posts/${pid}`);
    } finally {
      setBusyPost(false);
    }
  };

  if (selected) {
    const pendingMembers = members.filter((m) => m.status === 'pending');
    const approvedMembers = members.filter((m) => m.status === 'approved');

    return (
      <div className="max-w-3xl mx-auto space-y-5">
        <button
          type="button"
          onClick={() => setSelected(null)}
          className="text-xs font-medium text-[#D4AF37] hover:underline cursor-pointer"
        >
          ← All Communities
        </button>

        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] overflow-hidden">
          {selected.coverUrl && (
            <div className="h-40 bg-[#0A0B0E]">
              <img
                src={selected.coverUrl}
                alt={selected.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <div className="p-6 space-y-4">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="font-display text-xl font-bold">{selected.name}</h1>
                  {selected.privacy === 'private' && <Lock className="w-4 h-4 text-[#D4AF37]" />}
                </div>
                <p className="text-xs text-slate-500 mt-1 capitalize">
                  {selected.privacy} Community ·{' '}
                  <span className="font-mono tabular-nums">{selected.membersCount}</span> members
                </p>
                {selected.description && (
                  <p className="text-sm text-slate-600 dark:text-slate-300 mt-2">
                    {selected.description}
                  </p>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {!myMembership ? (
                  <button
                    type="button"
                    onClick={() => handleJoin(selected)}
                    className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
                  >
                    {selected.privacy === 'public' ? 'Join Community' : 'Request to Join'}
                  </button>
                ) : myMembership.status === 'pending' ? (
                  <button
                    type="button"
                    onClick={() => handleLeaveOrCancel(selected)}
                    className="h-10 px-3.5 rounded-xl border border-amber-500/40 text-amber-500 text-xs font-semibold cursor-pointer"
                  >
                    Pending · Cancel Request
                  </button>
                ) : myMembership.status === 'rejected' ? (
                  <button
                    type="button"
                    onClick={() => handleJoin(selected)}
                    className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
                  >
                    Request Again
                  </button>
                ) : (
                  <>
                    <span className="text-xs font-semibold text-[#D4AF37] capitalize px-2">
                      {myMembership.role}
                    </span>
                    {selected.creatorUid !== firebaseUser?.uid && (
                      <button
                        type="button"
                        onClick={() => handleLeaveOrCancel(selected)}
                        className="h-10 inline-flex items-center gap-1.5 px-3 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-medium text-slate-500 hover:text-rose-500 cursor-pointer"
                      >
                        <LogOut className="w-3.5 h-3.5" /> Leave
                      </button>
                    )}
                  </>
                )}

                {isCommAdmin && (
                  <button
                    type="button"
                    onClick={() => setShowSettings((v) => !v)}
                    className={`h-10 inline-flex items-center gap-1.5 px-3 rounded-xl border text-xs font-semibold cursor-pointer ${
                      showSettings
                        ? 'border-[#D4AF37] text-[#D4AF37]'
                        : 'border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <Settings className="w-3.5 h-3.5" /> Settings
                  </button>
                )}

                <button
                  type="button"
                  onClick={async () => {
                    if (!firebaseUser) return;
                    await submitReport({
                      reporterUid: firebaseUser.uid,
                      targetType: 'community',
                      targetId: selected.id,
                      reason: 'Community safety report',
                    });
                    pushToast('Community reported to moderation.', 'info');
                  }}
                  className="h-10 w-10 inline-flex items-center justify-center rounded-xl border border-slate-200 dark:border-white/10 text-slate-400 hover:text-amber-500 cursor-pointer"
                  title="Report Community"
                >
                  <Flag className="w-4 h-4" />
                </button>
              </div>
            </div>

            {selected.rules && (
              <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-3.5 text-xs">
                <p className="font-semibold text-slate-900 dark:text-white mb-1 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5 text-[#D4AF37]" /> Community Rules
                </p>
                <p className="text-slate-500 whitespace-pre-wrap">{selected.rules}</p>
              </div>
            )}
          </div>
        </div>

        {/* Admin Community Settings */}
        {isCommAdmin && showSettings && (
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              if (editName.trim().length < 2) {
                pushToast('Community name must be at least 2 characters.', 'error');
                return;
              }
              setBusySettings(true);
              try {
                await updateDoc(doc(db, 'communities', selected.id), {
                  name: editName.trim().slice(0, 100),
                  description: editDesc.trim().slice(0, 1000),
                  coverUrl: editCoverUrl,
                  privacy: editPrivacy,
                  rules: editRules.trim().slice(0, 2000),
                  updatedAt: serverTimestamp(),
                });
                setShowSettings(false);
                pushToast('Community settings saved.', 'success');
              } catch (err) {
                handleFirestoreError(err, OperationType.UPDATE, `communities/${selected.id}`);
              } finally {
                setBusySettings(false);
              }
            }}
            className="rounded-2xl border border-[#D4AF37]/30 bg-white dark:bg-[#13151B] p-5 space-y-3 text-xs"
          >
            <h3 className="font-display font-bold text-sm">Edit Community Settings</h3>
            <input
              type="text"
              required
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              placeholder="Community Name"
              className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
            />
            <textarea
              rows={2}
              value={editDesc}
              onChange={(e) => setEditDesc(e.target.value)}
              placeholder="Description..."
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
            />
            <textarea
              rows={2}
              value={editRules}
              onChange={(e) => setEditRules(e.target.value)}
              placeholder="Rules..."
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
            />
            <select
              value={editPrivacy}
              onChange={(e) => setEditPrivacy(e.target.value as 'public' | 'private')}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
            >
              <option value="public">Public (Anyone can join)</option>
              <option value="private">Private (Requires Admin approval)</option>
            </select>
            <MediaUploadInput
              accept="image/*"
              mediaKind="image"
              label="Update Cover Photo"
              value={editCoverUrl}
              onUploaded={(url) => setEditCoverUrl(url)}
            />
            <button
              type="submit"
              disabled={busySettings}
              className="h-10 px-5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
            >
              {busySettings ? 'Saving...' : 'Save Settings'}
            </button>
          </form>
        )}

        {/* Admin Join Requests & Moderation */}
        {isCommAdmin && pendingMembers.length > 0 && (
          <div className="rounded-2xl border border-[#D4AF37]/30 bg-white dark:bg-[#13151B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">
              Pending Member Requests ({pendingMembers.length})
            </h3>
            {pendingMembers.map((pm) => {
              const u = usersMap[pm.uid];
              return (
                <div key={pm.uid} className="flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Avatar src={u?.photoUrl} name={u?.displayName || pm.uid} size="sm" />
                    <span className="font-medium truncate">{u?.displayName || pm.uid}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const batch = writeBatch(db);
                          batch.update(doc(db, 'communities', selected.id, 'members', pm.uid), {
                            status: 'approved',
                          });
                          batch.update(doc(db, 'communities', selected.id), {
                            membersCount: increment(1),
                            updatedAt: serverTimestamp(),
                          });
                          await batch.commit();
                          if (firebaseUser) {
                            await createNotification({
                              recipientUid: pm.uid,
                              actorUid: firebaseUser.uid,
                              type: 'community_approved',
                              title: 'Community Request Approved',
                              body: `Your request to join ${selected.name} was approved.`,
                              targetTab: 'communities',
                            });
                          }
                          pushToast('Member approved.', 'success');
                        } catch (err) {
                          handleFirestoreError(
                            err,
                            OperationType.WRITE,
                            `communities/${selected.id}/members/${pm.uid}`
                          );
                        }
                      }}
                      className="h-9 px-3 rounded-lg bg-[#D4AF37] text-[#0A0B0E] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" /> Approve
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await updateDoc(doc(db, 'communities', selected.id, 'members', pm.uid), {
                            status: 'rejected',
                          });
                          pushToast('Request declined.', 'info');
                        } catch (err) {
                          handleFirestoreError(
                            err,
                            OperationType.UPDATE,
                            `communities/${selected.id}/members/${pm.uid}`
                          );
                        }
                      }}
                      className="h-9 px-3 rounded-lg border border-slate-200 dark:border-white/10 text-rose-500 cursor-pointer"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Member List & Roles for Admins */}
        {isCommAdmin && (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">
              Community Members ({approvedMembers.length})
            </h3>
            <div className="divide-y divide-slate-100 dark:divide-white/5">
              {approvedMembers.map((m) => {
                const u = usersMap[m.uid];
                const isCreator = m.uid === selected.creatorUid;
                return (
                  <div
                    key={m.uid}
                    className="py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs"
                  >
                    <button
                      type="button"
                      onClick={() => onOpenProfile(m.uid)}
                      className="flex items-center gap-2.5 text-left cursor-pointer"
                    >
                      <Avatar src={u?.photoUrl} name={u?.displayName || m.uid} size="sm" />
                      <div>
                        <p className="font-semibold hover:text-[#D4AF37]">
                          {u?.displayName || m.uid.slice(0, 8)}
                        </p>
                        <p className="text-slate-500">
                          @{u?.username || 'member'}
                          {isCreator ? ' · Creator' : ''}
                        </p>
                      </div>
                    </button>
                    <div className="flex items-center gap-2">
                      {!isCreator && m.uid !== firebaseUser?.uid ? (
                        <>
                          <select
                            value={m.role}
                            onChange={async (e) => {
                              const nextRole = e.target.value as CommunityMember['role'];
                              try {
                                await updateDoc(
                                  doc(db, 'communities', selected.id, 'members', m.uid),
                                  { role: nextRole }
                                );
                                pushToast(`Updated member role to ${nextRole}.`, 'success');
                              } catch (err) {
                                handleFirestoreError(
                                  err,
                                  OperationType.UPDATE,
                                  `communities/${selected.id}/members/${m.uid}`
                                );
                              }
                            }}
                            className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] capitalize"
                          >
                            <option value="member">Member</option>
                            <option value="moderator">Moderator</option>
                            <option value="admin">Admin</option>
                          </select>
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                const batch = writeBatch(db);
                                batch.delete(doc(db, 'communities', selected.id, 'members', m.uid));
                                batch.update(doc(db, 'communities', selected.id), {
                                  membersCount: increment(-1),
                                  updatedAt: serverTimestamp(),
                                });
                                await batch.commit();
                                pushToast('Member removed.', 'info');
                              } catch (err) {
                                handleFirestoreError(
                                  err,
                                  OperationType.DELETE,
                                  `communities/${selected.id}/members/${m.uid}`
                                );
                              }
                            }}
                            className="w-9 h-9 inline-flex items-center justify-center rounded-lg text-rose-500 hover:bg-rose-500/10 cursor-pointer"
                            title="Remove member"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        <span className="capitalize font-semibold text-[#D4AF37]">{m.role}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Community Feed */}
        {selected.privacy === 'public' || myMembership?.status === 'approved' ? (
          <div className="space-y-4">
            {myMembership?.status === 'approved' && (
              <form
                onSubmit={handlePublishCommunityPost}
                className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-3"
              >
                <textarea
                  rows={2}
                  value={newPostText}
                  onChange={(e) => setNewPostText(e.target.value)}
                  placeholder={`Share something in ${selected.name}...`}
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
                />
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <MediaUploadInput
                    accept="image/*,video/*"
                    mediaKind="auto"
                    label="Add Photo / Video"
                    value={newPostMedia}
                    onUploaded={(url, kind) => {
                      setNewPostMedia(url);
                      setNewPostKind(kind);
                    }}
                  />
                  <button
                    type="submit"
                    disabled={busyPost || (!newPostText.trim() && !newPostMedia)}
                    className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold disabled:opacity-45 cursor-pointer"
                  >
                    {busyPost ? 'Posting...' : 'Post to Community'}
                  </button>
                </div>
              </form>
            )}

            {communityPosts.map((p) => (
              <PostCard
                key={p.id}
                post={p}
                author={usersMap[p.authorUid]}
                canModerate={isCommAdmin}
                onOpenProfile={onOpenProfile}
              />
            ))}
            {communityPosts.length === 0 && (
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-8 text-center text-xs text-slate-500">
                No community posts yet.
              </div>
            )}
          </div>
        ) : (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-8 text-center text-xs text-slate-500">
            This is a Private Community. Join approval is required to view discussions.
          </div>
        )}
      </div>
    );
  }

  const filteredCommunities = communities.filter((c) => {
    const m = myMembershipByComm[c.id];
    if (directoryFilter === 'mine' && m?.status !== 'approved' && c.creatorUid !== firebaseUser?.uid) {
      return false;
    }
    if (directoryFilter === 'public' && c.privacy !== 'public') return false;
    if (directoryFilter === 'private' && c.privacy !== 'private') return false;
    const q = searchText.trim().toLowerCase();
    if (!q) return true;
    return (
      c.name.toLowerCase().includes(q) || (c.description || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-bold">Communities &amp; Groups</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Public and private interest spaces moderated by community admins.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowCreate(true)}
          className="h-10 inline-flex items-center gap-1.5 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Create Community
        </button>
      </div>

      {/* Directory Filter & Search */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-white dark:bg-[#13151B] border border-slate-200 dark:border-white/10 p-1 rounded-xl text-xs font-semibold">
          {(
            [
              ['all', 'All'],
              ['mine', 'Joined'],
              ['public', 'Public'],
              ['private', 'Private'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setDirectoryFilter(id)}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                directoryFilter === id
                  ? 'bg-[#D4AF37] text-[#0A0B0E]'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            placeholder="Search communities..."
            className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-xs"
          />
        </div>
      </div>

      {filteredCommunities.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-10 text-center space-y-3">
          <Compass className="w-8 h-8 text-[#D4AF37] mx-auto" />
          <p className="text-sm font-semibold">No matching communities</p>
          <p className="text-xs text-slate-500">
            Create a Public or Private community to bring members together.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredCommunities.map((c) => {
            const mem = myMembershipByComm[c.id];
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => setSelected(c)}
                className="text-left rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] overflow-hidden hover:border-[#D4AF37]/60 transition-colors cursor-pointer"
              >
                {c.coverUrl && (
                  <div className="h-24 bg-[#0A0B0E]">
                    <img
                      src={c.coverUrl}
                      alt={c.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <div className="p-5 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="font-display font-bold text-base truncate">{c.name}</h3>
                    {c.privacy === 'private' ? (
                      <Lock className="w-4 h-4 text-[#D4AF37] shrink-0" />
                    ) : (
                      <Users className="w-4 h-4 text-[#3B82F6] shrink-0" />
                    )}
                  </div>
                  <p className="text-xs text-slate-500 line-clamp-2">
                    {c.description || 'Community space'}
                  </p>
                  <p className="text-[11px] text-slate-400 capitalize pt-1">
                    {c.privacy} · <span className="font-mono tabular-nums">{c.membersCount}</span> members
                    {mem?.status === 'approved'
                      ? ` · ${mem.role}`
                      : mem?.status === 'pending'
                      ? ' · Request pending'
                      : ''}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="max-w-md w-full rounded-2xl border border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base">Create Community</h3>
              <button type="button" onClick={() => setShowCreate(false)} className="cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateCommunity} className="space-y-3">
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Community Name"
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
              />
              <textarea
                rows={3}
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                placeholder="Description..."
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
              />
              <textarea
                rows={2}
                value={rules}
                onChange={(e) => setRules(e.target.value)}
                placeholder="Community Rules..."
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
              />
              <select
                value={privacy}
                onChange={(e) => setPrivacy(e.target.value as 'public' | 'private')}
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
              >
                <option value="public">Public (Anyone can join)</option>
                <option value="private">Private (Requires Admin approval)</option>
              </select>
              <MediaUploadInput
                accept="image/*"
                mediaKind="image"
                label="Upload Cover Photo (Optional)"
                value={coverUrl}
                onUploaded={(url) => setCoverUrl(url)}
              />
              <button
                type="submit"
                disabled={busyCreate}
                className="w-full h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
              >
                {busyCreate ? 'Creating...' : 'Create Community'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
