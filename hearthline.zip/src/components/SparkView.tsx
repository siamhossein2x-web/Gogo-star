import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  increment,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  Bookmark,
  Eye,
  Film,
  Flag,
  Heart,
  MessageSquare,
  Music2,
  Plus,
  Share2,
  Trash2,
  UserPlus,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import { CommentItem, SparkVideo, UserProfile } from '../types/hearthline';
import { useAuth, createNotification } from '../context/AuthContext';
import { useToast } from './Toast';
import { Avatar } from './Avatar';
import { submitReport, toggleFollow } from '../lib/socialActions';

interface SparkViewProps {
  onOpenProfile: (uid: string) => void;
  onOpenUpload: (mode: 'spark') => void;
}

export const SparkView: React.FC<SparkViewProps> = ({ onOpenProfile, onOpenUpload }) => {
  const { firebaseUser, profile, isModerator } = useAuth();
  const { pushToast } = useToast();

  const [videos, setVideos] = useState<SparkVideo[]>([]);
  const [feedTab, setFeedTab] = useState<'for_you' | 'following'>('for_you');
  const [tagFilter, setTagFilter] = useState<string | null>(null);
  const [usersMap, setUsersMap] = useState<Record<string, UserProfile>>({});
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());
  const [followingUids, setFollowingUids] = useState<Set<string>>(new Set());
  const [muted, setMuted] = useState(true); // Never autoplay with sound unexpectedly
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);

  const [commentVideoId, setCommentVideoId] = useState<string | null>(null);
  const [comments, setComments] = useState<CommentItem[]>([]);
  const [commentText, setCommentText] = useState('');

  const containerRef = useRef<HTMLDivElement>(null);
  const videoElsRef = useRef<Record<string, HTMLVideoElement | null>>({});
  const viewedSessionRef = useRef<Set<string>>(new Set());
  const loadedUsersRef = useRef<Set<string>>(new Set());
  const checkedLikesRef = useRef<Set<string>>(new Set());

  const hydrateUserProfiles = async (uids: string[]) => {
    const missing = uids.filter((u) => u && !loadedUsersRef.current.has(u));
    if (missing.length === 0) return;
    missing.forEach((u) => loadedUsersRef.current.add(u));
    const loaded: Record<string, UserProfile> = {};
    await Promise.all(
      missing.map(async (u) => {
        try {
          const s = await getDoc(doc(db, 'users', u));
          if (s.exists()) loaded[u] = s.data() as UserProfile;
        } catch {}
      })
    );
    if (Object.keys(loaded).length > 0) {
      setUsersMap((prev) => ({ ...prev, ...loaded }));
    }
  };

  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      query(collection(db, 'sparkVideos'), orderBy('createdAt', 'desc'), limit(30)),
      async (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as SparkVideo));
        setVideos(list);
        await hydrateUserProfiles(Array.from(new Set(list.map((v) => v.authorUid))));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'sparkVideos')
    );

    const unsubFollows = onSnapshot(
      query(collection(db, 'follows'), where('followerUid', '==', firebaseUser.uid)),
      (snap) => {
        setFollowingUids(new Set(snap.docs.map((d) => d.data().targetId as string)));
      },
      () => {}
    );

    const unsubSaved = onSnapshot(
      query(
        collection(db, 'savedPosts'),
        where('uid', '==', firebaseUser.uid),
        where('targetType', '==', 'spark')
      ),
      (snap) => {
        setSavedIds(new Set(snap.docs.map((d) => d.data().targetId as string)));
      },
      () => {}
    );

    return () => {
      unsub();
      unsubFollows();
      unsubSaved();
    };
  }, [firebaseUser?.uid]);

  useEffect(() => {
    if (!firebaseUser || videos.length === 0) return;
    const unchecked = videos.filter((v) => !checkedLikesRef.current.has(v.id));
    if (unchecked.length === 0) return;
    unchecked.forEach((v) => checkedLikesRef.current.add(v.id));

    Promise.all(
      unchecked.map(async (v) => {
        try {
          const lSnap = await getDoc(doc(db, 'sparkVideos', v.id, 'likes', firebaseUser.uid));
          return lSnap.exists() ? v.id : null;
        } catch {
          return null;
        }
      })
    ).then((hits) => {
      const valid = hits.filter((id): id is string => Boolean(id));
      if (valid.length > 0) {
        setLikedIds((prev) => {
          const next = new Set(prev);
          valid.forEach((id) => next.add(id));
          return next;
        });
      }
    });
  }, [firebaseUser?.uid, videos]);

  const filteredVideos = useMemo(() => {
    return videos.filter((v) => {
      if (feedTab === 'following' && v.authorUid !== firebaseUser?.uid && !followingUids.has(v.authorUid)) {
        return false;
      }
      if (tagFilter && !(v.hashtags || []).includes(tagFilter)) {
        return false;
      }
      return true;
    });
  }, [videos, feedTab, tagFilter, firebaseUser?.uid, followingUids]);

  // IntersectionObserver for auto-play active snap video and pause offscreen ones
  useEffect(() => {
    const root = containerRef.current;
    if (!root || filteredVideos.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const vidId = entry.target.getAttribute('data-spark-id');
          if (!vidId) return;
          const el = videoElsRef.current[vidId];
          if (entry.isIntersecting && entry.intersectionRatio >= 0.6) {
            setActiveVideoId(vidId);
            if (el) {
              el.play().catch(() => {});
            }
          } else if (el && !el.paused) {
            el.pause();
          }
        });
      },
      { root, threshold: 0.65 }
    );

    const sections = root.querySelectorAll('[data-spark-id]');
    sections.forEach((sec) => observer.observe(sec));

    return () => observer.disconnect();
  }, [filteredVideos.length, feedTab, tagFilter]);

  useEffect(() => {
    if (!commentVideoId) return;
    const unsub = onSnapshot(
      query(collection(db, 'sparkVideos', commentVideoId, 'comments'), orderBy('createdAt', 'asc')),
      async (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as CommentItem));
        setComments(list);
        await hydrateUserProfiles(Array.from(new Set(list.map((c) => c.authorUid))));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `sparkVideos/${commentVideoId}/comments`)
    );
    return () => unsub();
  }, [commentVideoId]);

  const recordSparkView = async (videoId: string) => {
    if (viewedSessionRef.current.has(videoId)) return;
    viewedSessionRef.current.add(videoId);
    try {
      await updateDoc(doc(db, 'sparkVideos', videoId), { viewsCount: increment(1) });
    } catch {}
  };

  const toggleLike = async (v: SparkVideo) => {
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to react to Spark videos.', 'error');
      return;
    }
    const isLiked = likedIds.has(v.id);
    const batch = writeBatch(db);
    const likeRef = doc(db, 'sparkVideos', v.id, 'likes', firebaseUser.uid);
    const vidRef = doc(db, 'sparkVideos', v.id);
    try {
      if (isLiked) {
        batch.delete(likeRef);
        batch.update(vidRef, { likesCount: increment(-1) });
        setLikedIds((prev) => {
          const next = new Set(prev);
          next.delete(v.id);
          return next;
        });
      } else {
        batch.set(likeRef, { uid: firebaseUser.uid, reaction: 'love', createdAt: serverTimestamp() });
        batch.update(vidRef, { likesCount: increment(1) });
        setLikedIds((prev) => new Set(prev).add(v.id));
      }
      await batch.commit();
      if (!isLiked && v.authorUid !== firebaseUser.uid) {
        await createNotification({
          recipientUid: v.authorUid,
          actorUid: firebaseUser.uid,
          type: 'spark_like',
          title: 'Spark Liked',
          body: `${profile?.displayName || 'Someone'} liked your Spark video.`,
          targetTab: 'spark',
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `sparkVideos/${v.id}/likes`);
    }
  };

  const toggleSave = async (v: SparkVideo) => {
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to save Spark videos.', 'error');
      return;
    }
    const saveId = `${firebaseUser.uid}_${v.id}`;
    try {
      if (savedIds.has(v.id)) {
        await deleteDoc(doc(db, 'savedPosts', saveId));
        setSavedIds((prev) => {
          const next = new Set(prev);
          next.delete(v.id);
          return next;
        });
        pushToast('Removed from saved Spark videos.', 'info');
      } else {
        await setDoc(doc(db, 'savedPosts', saveId), {
          uid: firebaseUser.uid,
          targetId: v.id,
          targetType: 'spark',
          createdAt: serverTimestamp(),
        });
        setSavedIds((prev) => new Set(prev).add(v.id));
        pushToast('Saved Spark video!', 'success');
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `savedPosts/${saveId}`);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentVideoId || !firebaseUser?.emailVerified || !commentText.trim()) return;
    const cid = makeSafeId('scmt');
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'sparkVideos', commentVideoId, 'comments', cid), {
        authorUid: firebaseUser.uid,
        text: commentText.trim().slice(0, 1500),
        createdAt: serverTimestamp(),
      });
      batch.update(doc(db, 'sparkVideos', commentVideoId), {
        commentsCount: increment(1),
      });
      await batch.commit();
      setCommentText('');
      const targetVid = videos.find((x) => x.id === commentVideoId);
      if (targetVid && targetVid.authorUid !== firebaseUser.uid) {
        await createNotification({
          recipientUid: targetVid.authorUid,
          actorUid: firebaseUser.uid,
          type: 'spark_comment',
          title: 'New Spark Comment',
          body: `${profile?.displayName || 'Someone'} commented on your Spark video.`,
          targetTab: 'spark',
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `sparkVideos/${commentVideoId}/comments/${cid}`);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!commentVideoId) return;
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'sparkVideos', commentVideoId, 'comments', commentId));
      batch.update(doc(db, 'sparkVideos', commentVideoId), {
        commentsCount: increment(-1),
      });
      await batch.commit();
      pushToast('Comment deleted.', 'info');
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.DELETE,
        `sparkVideos/${commentVideoId}/comments/${commentId}`
      );
    }
  };

  const handleDeleteSpark = async (v: SparkVideo) => {
    try {
      await deleteDoc(doc(db, 'sparkVideos', v.id));
      pushToast('Spark video deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `sparkVideos/${v.id}`);
    }
  };

  if (videos.length === 0) {
    return (
      <div className="h-[calc(100vh-7.5rem)] lg:h-[calc(100vh-3.5rem)] flex items-center justify-center p-6">
        <div className="max-w-sm w-full rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-8 text-center space-y-4">
          <Film className="w-10 h-10 text-[#D4AF37] mx-auto" />
          <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white">
            Spark Short Videos
          </h2>
          <p className="text-xs text-slate-500">
            Upload vertical short videos with Cloudinary or HTTPS video links to launch the Spark feed.
          </p>
          <button
            type="button"
            onClick={() => onOpenUpload('spark')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Upload First Spark
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative h-[calc(100vh-7.5rem)] lg:h-[calc(100vh-3.5rem)] bg-black overflow-y-scroll snap-y snap-mandatory"
    >
      {/* Floating Top Spark Bar */}
      <div className="sticky top-3 z-30 px-4 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-1 p-1 rounded-xl bg-black/65 border border-white/15 backdrop-blur-md text-xs">
          <button
            type="button"
            onClick={() => setFeedTab('for_you')}
            className={`px-3 py-1.5 rounded-lg font-semibold cursor-pointer whitespace-nowrap ${
              feedTab === 'for_you' ? 'bg-[#D4AF37] text-[#0A0B0E]' : 'text-white/80 hover:text-white'
            }`}
          >
            For You
          </button>
          <button
            type="button"
            onClick={() => setFeedTab('following')}
            className={`px-3 py-1.5 rounded-lg font-semibold cursor-pointer whitespace-nowrap ${
              feedTab === 'following' ? 'bg-[#D4AF37] text-[#0A0B0E]' : 'text-white/80 hover:text-white'
            }`}
          >
            Following
          </button>
          {tagFilter && (
            <button
              type="button"
              onClick={() => setTagFilter(null)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#3B82F6]/20 text-[#3B82F6] font-medium cursor-pointer whitespace-nowrap"
            >
              #{tagFilter} <X className="w-3 h-3" />
            </button>
          )}
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={() => setMuted((m) => !m)}
            className="h-9 px-3 rounded-xl bg-black/65 border border-white/15 text-white text-xs flex items-center gap-1.5 backdrop-blur-md cursor-pointer whitespace-nowrap"
          >
            {muted ? (
              <VolumeX className="w-4 h-4 text-[#D4AF37]" />
            ) : (
              <Volume2 className="w-4 h-4 text-[#D4AF37]" />
            )}
            {muted ? 'Muted' : 'Sound On'}
          </button>
          <button
            type="button"
            onClick={() => onOpenUpload('spark')}
            className="h-9 px-3 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold flex items-center gap-1 cursor-pointer whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Upload
          </button>
        </div>
      </div>

      {filteredVideos.length === 0 ? (
        <div className="h-[calc(100%-3.5rem)] flex items-center justify-center p-6 text-center text-white space-y-3">
          <div className="space-y-3">
            <p className="text-sm text-slate-300">No Spark videos match this filter yet.</p>
            <button
              type="button"
              onClick={() => {
                setFeedTab('for_you');
                setTagFilter(null);
              }}
              className="px-4 py-2 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
            >
              Show All Spark Videos
            </button>
          </div>
        </div>
      ) : (
        filteredVideos.map((v) => {
          const creator = usersMap[v.authorUid];
          const isLiked = likedIds.has(v.id);
          const isSaved = savedIds.has(v.id);
          const isFollowing = followingUids.has(v.authorUid);
          const canDelete = v.authorUid === firebaseUser?.uid || isModerator;

          return (
            <section
              key={v.id}
              data-spark-id={v.id}
              className="relative h-full w-full snap-start flex items-center justify-center bg-black -mt-12 pt-12"
            >
              <video
                ref={(el) => {
                  videoElsRef.current[v.id] = el;
                }}
                src={v.videoUrl}
                loop
                playsInline
                muted={muted}
                controls
                onPlay={() => recordSparkView(v.id)}
                className={`h-full w-full max-w-md object-contain bg-black ${
                  activeVideoId === v.id ? 'opacity-100' : 'opacity-95'
                }`}
              />

              {/* Bottom Creator Overlay */}
              <div className="absolute bottom-4 left-4 right-16 max-w-md mx-auto pointer-events-none">
                <div className="pointer-events-auto rounded-2xl bg-gradient-to-t from-black/85 via-black/55 to-transparent p-4 space-y-2 text-white">
                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={() => onOpenProfile(v.authorUid)}
                      className="flex items-center gap-2 cursor-pointer"
                    >
                      <Avatar src={creator?.photoUrl} name={creator?.displayName || 'Creator'} size="sm" />
                      <span className="text-sm font-semibold">@{creator?.username || 'creator'}</span>
                    </button>
                    {v.authorUid !== firebaseUser?.uid && (
                      <button
                        type="button"
                        onClick={async () => {
                          if (!firebaseUser) return;
                          const next = await toggleFollow(
                            firebaseUser.uid,
                            v.authorUid,
                            'user',
                            isFollowing,
                            profile?.displayName || 'Someone'
                          );
                          setFollowingUids((prev) => {
                            const s = new Set(prev);
                            if (next) s.add(v.authorUid);
                            else s.delete(v.authorUid);
                            return s;
                          });
                        }}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#D4AF37] text-[#0A0B0E] text-[11px] font-semibold cursor-pointer whitespace-nowrap"
                      >
                        {!isFollowing && <UserPlus className="w-3 h-3" />}
                        {isFollowing ? 'Following' : 'Follow'}
                      </button>
                    )}
                  </div>

                  {v.description && <p className="text-xs text-slate-200 line-clamp-2">{v.description}</p>}

                  {v.hashtags && v.hashtags.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-[#3B82F6] font-medium">
                      {v.hashtags.map((h) => (
                        <button
                          key={h}
                          type="button"
                          onClick={() => setTagFilter(tagFilter === h ? null : h)}
                          className="hover:underline cursor-pointer"
                        >
                          #{h}
                        </button>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center gap-3 text-[11px] text-slate-300">
                    <span className="inline-flex items-center gap-1 truncate">
                      <Music2 className="w-3 h-3 text-[#D4AF37]" /> {v.soundTitle}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="inline-flex items-center gap-1 font-mono tabular-nums">
                      <Eye className="w-3 h-3" /> {v.viewsCount}
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Action Rail */}
              <div className="absolute bottom-10 right-3 sm:right-6 flex flex-col items-center gap-3.5 text-white">
                <button
                  type="button"
                  onClick={() => toggleLike(v)}
                  className="flex flex-col items-center gap-1 cursor-pointer"
                >
                  <span
                    className={`w-11 h-11 rounded-full flex items-center justify-center bg-black/60 border border-white/15 ${
                      isLiked ? 'text-rose-500' : 'text-white'
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                  </span>
                  <span className="text-[11px] font-mono tabular-nums">{v.likesCount}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCommentVideoId(v.id)}
                  className="flex flex-col items-center gap-1 cursor-pointer"
                >
                  <span className="w-11 h-11 rounded-full flex items-center justify-center bg-black/60 border border-white/15">
                    <MessageSquare className="w-5 h-5" />
                  </span>
                  <span className="text-[11px] font-mono tabular-nums">{v.commentsCount}</span>
                </button>

                <button
                  type="button"
                  onClick={() => toggleSave(v)}
                  className="flex flex-col items-center gap-1 cursor-pointer"
                >
                  <span
                    className={`w-11 h-11 rounded-full flex items-center justify-center bg-black/60 border border-white/15 ${
                      isSaved ? 'text-[#D4AF37]' : 'text-white'
                    }`}
                  >
                    <Bookmark className={`w-5 h-5 ${isSaved ? 'fill-current' : ''}`} />
                  </span>
                  <span className="text-[11px]">Save</span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    await navigator.clipboard.writeText(window.location.href);
                    try {
                      await updateDoc(doc(db, 'sparkVideos', v.id), { sharesCount: increment(1) });
                    } catch {}
                    pushToast('Spark link copied!', 'info');
                  }}
                  className="flex flex-col items-center gap-1 cursor-pointer"
                >
                  <span className="w-11 h-11 rounded-full flex items-center justify-center bg-black/60 border border-white/15">
                    <Share2 className="w-5 h-5" />
                  </span>
                  <span className="text-[11px] font-mono tabular-nums">{v.sharesCount}</span>
                </button>

                {canDelete && (
                  <button
                    type="button"
                    onClick={() => handleDeleteSpark(v)}
                    className="w-10 h-10 rounded-full flex items-center justify-center bg-black/60 border border-white/15 text-rose-400 cursor-pointer"
                    title="Delete Spark video"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={async () => {
                    if (!firebaseUser) return;
                    await submitReport({
                      reporterUid: firebaseUser.uid,
                      targetType: 'video',
                      targetId: v.id,
                      reason: 'Spark video report',
                    });
                    pushToast('Video reported to moderation.', 'info');
                  }}
                  className="w-10 h-10 rounded-full flex items-center justify-center bg-black/60 border border-white/15 text-amber-400 cursor-pointer"
                  title="Report video"
                >
                  <Flag className="w-4 h-4" />
                </button>
              </div>
            </section>
          );
        })
      )}

      {/* Comments Sheet */}
      {commentVideoId && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl bg-[#13151B] border border-white/10 p-5 space-y-4 max-h-[75vh] flex flex-col">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-sm text-white">
                Spark Comments ({comments.length})
              </h3>
              <button
                type="button"
                aria-label="Close comments"
                onClick={() => setCommentVideoId(null)}
                className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto space-y-2.5">
              {comments.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-6">No comments yet.</p>
              ) : (
                comments.map((c) => {
                  const cUser = usersMap[c.authorUid];
                  const canDel = c.authorUid === firebaseUser?.uid || isModerator;
                  return (
                    <div
                      key={c.id}
                      className="rounded-xl bg-[#0A0B0E] p-3 text-xs text-slate-200 flex items-start gap-2.5"
                    >
                      <button
                        type="button"
                        onClick={() => {
                          setCommentVideoId(null);
                          onOpenProfile(c.authorUid);
                        }}
                        className="cursor-pointer shrink-0"
                      >
                        <Avatar src={cUser?.photoUrl} name={cUser?.displayName || 'U'} size="xs" />
                      </button>
                      <div className="flex-1 min-w-0 space-y-0.5">
                        <div className="flex items-center justify-between gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              setCommentVideoId(null);
                              onOpenProfile(c.authorUid);
                            }}
                            className="font-semibold text-white hover:text-[#D4AF37] truncate cursor-pointer"
                          >
                            {cUser?.displayName || 'Creator'}
                          </button>
                          {canDel && (
                            <button
                              type="button"
                              onClick={() => handleDeleteComment(c.id)}
                              className="text-[11px] text-rose-400 hover:underline cursor-pointer shrink-0"
                            >
                              Delete
                            </button>
                          )}
                        </div>
                        <p className="text-slate-300 break-words">{c.text}</p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
            <form onSubmit={handleAddComment} className="flex items-center gap-2">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Add a comment..."
                className="flex-1 h-10 px-3 rounded-xl border border-white/10 bg-[#0A0B0E] text-xs text-white focus:outline-none focus:border-[#D4AF37]"
              />
              <button
                type="submit"
                className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer whitespace-nowrap"
              >
                Post
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
