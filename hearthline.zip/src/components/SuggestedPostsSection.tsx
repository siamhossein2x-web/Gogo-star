import React, { useRef, useState } from 'react';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  EyeOff,
  Film,
  Image as ImageIcon,
  TrendingUp,
  UserCheck,
  UserPlus,
} from 'lucide-react';
import { Post, PublicPage, UserProfile } from '../types/hearthline';
import { SuggestedPostEntry } from '../lib/feedRanking';
import { Avatar } from './Avatar';
import { formatCompactNumber } from '../lib/finance';
import { toggleFollow } from '../lib/socialActions';
import { useAuth } from '../context/AuthContext';
import { useT } from '../i18n/translations';
import { useToast } from './Toast';

interface SuggestedPostsSectionProps {
  entries: SuggestedPostEntry[];
  usersMap: Record<string, UserProfile>;
  pagesMap: Record<string, PublicPage>;
  followingUids: Set<string>;
  onOpenProfile: (uid: string) => void;
  onSelectPost: (post: Post) => void;
  onDismissPost: (postId: string) => void;
}

function isVideoUrl(url: string, postType: Post['postType']): boolean {
  return (
    postType === 'video' ||
    /\/video\/upload\//i.test(url) ||
    /\.(mp4|webm|mov|m4v)(\?|$)/i.test(url)
  );
}

export const SuggestedPostsSection: React.FC<SuggestedPostsSectionProps> = ({
  entries,
  usersMap,
  pagesMap,
  followingUids,
  onOpenProfile,
  onSelectPost,
  onDismissPost,
}) => {
  const { firebaseUser, profile, language } = useAuth();
  const t = useT(language);
  const { pushToast } = useToast();

  const railRef = useRef<HTMLDivElement | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  const [busyFollowId, setBusyFollowId] = useState<string | null>(null);
  const [brokenMediaIds, setBrokenMediaIds] = useState<Set<string>>(new Set());

  if (entries.length === 0) {
    return null;
  }

  const scrollRail = (direction: 'prev' | 'next') => {
    const el = railRef.current;
    if (!el) return;
    const offset = direction === 'next' ? 316 : -316;
    el.scrollBy({ left: offset, behavior: 'smooth' });
  };

  const handleToggleFollow = async (post: Post, targetId: string, targetType: 'user' | 'page') => {
    if (!firebaseUser) return;
    if (!firebaseUser.emailVerified) {
      pushToast('Verify your email to follow creators and Pages.', 'error');
      return;
    }
    const currentlyFollowing = followingUids.has(targetId);
    setBusyFollowId(post.id);
    try {
      const nextState = await toggleFollow(
        firebaseUser.uid,
        targetId,
        targetType,
        currentlyFollowing,
        profile?.displayName || 'Someone'
      );
      pushToast(nextState ? 'Following updated.' : 'Unfollowed.', 'info');
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Unable to update follow status.', 'error');
    } finally {
      setBusyFollowId(null);
    }
  };

  return (
    <section
      aria-labelledby="suggested-for-you-heading"
      className="space-y-3"
      data-testid="suggested-for-you-section"
    >
      {/* Clean canvas header (no outer wrapper card to avoid cards-within-cards) */}
      <div className="flex items-center justify-between gap-3 px-0.5">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <h2
              id="suggested-for-you-heading"
              className="font-display font-bold text-sm sm:text-base text-slate-900 dark:text-white truncate"
            >
              {t('suggestedForYou')}
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
            Prioritized by reactions, discussions, and shares across HEARTHLINE
          </p>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {!collapsed && entries.length > 1 && (
            <div className="hidden sm:flex items-center gap-1">
              <button
                type="button"
                onClick={() => scrollRail('prev')}
                aria-label="Scroll suggested posts left"
                className="w-9 h-9 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-slate-600 dark:text-slate-300 hover:border-[#D4AF37] flex items-center justify-center transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => scrollRail('next')}
                aria-label="Scroll suggested posts right"
                className="w-9 h-9 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-slate-600 dark:text-slate-300 hover:border-[#D4AF37] flex items-center justify-center transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
          <button
            type="button"
            onClick={() => setCollapsed((v) => !v)}
            className="min-h-[36px] px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-xs font-medium text-slate-600 dark:text-slate-300 hover:border-[#D4AF37] whitespace-nowrap shrink-0 transition-colors cursor-pointer"
          >
            {collapsed ? 'Show' : 'Hide'}
          </button>
        </div>
      </div>

      {!collapsed && (
        <div
          ref={railRef}
          className="flex items-stretch gap-3 overflow-x-auto pb-1 snap-x snap-mandatory"
        >
          {entries.map((entry) => {
            const { post, reason } = entry;
            const author = usersMap[post.authorUid];
            const page = post.pageId ? pagesMap[post.pageId] : undefined;
            const isPagePost = post.authorType === 'page' && Boolean(page);
            const targetId = isPagePost && page ? page.id : post.authorUid;
            const targetType: 'user' | 'page' = isPagePost ? 'page' : 'user';
            const isFollowing = followingUids.has(targetId);
            const displayName = isPagePost && page
              ? page.name
              : author?.displayName || 'HEARTHLINE Creator';
            const avatarSrc = isPagePost && page ? page.avatarUrl : author?.photoUrl;
            const firstMedia = post.mediaUrls?.[0];
            const hasVideo = firstMedia ? isVideoUrl(firstMedia, post.postType) : false;
            const mediaFailed = brokenMediaIds.has(post.id);

            return (
              <article
                key={post.id}
                className="w-[282px] sm:w-[304px] shrink-0 snap-start rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 flex flex-col justify-between gap-3"
              >
                <div className="space-y-3">
                  {/* Author Header + Dismiss */}
                  <div className="flex items-start justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenProfile(post.authorUid)}
                      className="flex items-center gap-2.5 min-w-0 text-left cursor-pointer group"
                    >
                      <Avatar src={avatarSrc} name={displayName} size="sm" />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold text-slate-900 dark:text-white truncate group-hover:text-[#D4AF37] transition-colors">
                          {displayName}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                          {reason}
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onDismissPost(post.id)}
                      aria-label={`Hide suggested post from ${displayName}`}
                      title="Hide suggestion"
                      className="w-8 h-8 -mt-1 -mr-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/5 flex items-center justify-center shrink-0 cursor-pointer transition-colors"
                    >
                      <EyeOff className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Clickable Content & Media Preview */}
                  <button
                    type="button"
                    onClick={() => onSelectPost(post)}
                    className="w-full text-left space-y-2.5 cursor-pointer group focus:outline-none"
                  >
                    {firstMedia && (
                      <div className="relative w-full h-32 rounded-xl overflow-hidden bg-slate-100 dark:bg-[#0A0B0E] border border-slate-200/70 dark:border-white/5">
                        {mediaFailed ? (
                          <div className="w-full h-full flex flex-col items-center justify-center gap-1.5 px-3 text-center bg-gradient-to-br from-slate-100 to-slate-200 dark:from-[#161922] dark:to-[#0D0F14]">
                            <ImageIcon className="w-5 h-5 text-slate-400" />
                            <span className="text-[11px] text-slate-500 truncate max-w-full">
                              Media preview unavailable
                            </span>
                          </div>
                        ) : hasVideo ? (
                          <div className="relative w-full h-full">
                            <video
                              src={firstMedia}
                              muted
                              playsInline
                              preload="metadata"
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent flex items-end p-2.5">
                              <span className="inline-flex items-center gap-1 text-[11px] font-medium text-white">
                                <Film className="w-3.5 h-3.5 text-[#D4AF37]" />
                                Video post
                              </span>
                            </div>
                          </div>
                        ) : (
                          <img
                            src={firstMedia}
                            alt={post.content?.slice(0, 60) || `${displayName} post preview`}
                            loading="lazy"
                            referrerPolicy="no-referrer"
                            onError={() =>
                              setBrokenMediaIds((prev) => new Set(prev).add(post.id))
                            }
                            className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-200"
                          />
                        )}
                      </div>
                    )}

                    <p
                      className={`text-xs sm:text-[13px] text-slate-700 dark:text-slate-200 leading-relaxed ${
                        firstMedia ? 'line-clamp-2' : 'line-clamp-4'
                      }`}
                    >
                      {post.content?.trim() || post.linkTitle || 'Shared an update on HEARTHLINE.'}
                    </p>
                  </button>
                </div>

                {/* Unboxed Tabular Engagement Metrics + Functional Actions */}
                <div className="pt-2.5 border-t border-slate-100 dark:border-white/5 space-y-2.5">
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 tabular-nums truncate">
                    <span>{formatCompactNumber(post.likesCount || 0)} likes</span>
                    <span aria-hidden="true">·</span>
                    <span>{formatCompactNumber(post.commentsCount || 0)} comments</span>
                    <span aria-hidden="true">·</span>
                    <span>{formatCompactNumber(post.sharesCount || 0)} shares</span>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    {firebaseUser && post.authorUid !== firebaseUser.uid && (
                      <button
                        type="button"
                        disabled={busyFollowId === post.id}
                        onClick={() => handleToggleFollow(post, targetId, targetType)}
                        className={`min-h-[36px] px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors cursor-pointer disabled:opacity-50 ${
                          isFollowing
                            ? 'border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300 hover:border-rose-400/50'
                            : 'bg-[#D4AF37]/15 text-[#9A7B16] dark:text-[#D4AF37] hover:bg-[#D4AF37]/25'
                        }`}
                      >
                        {isFollowing ? (
                          <>
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>{t('unfollow')}</span>
                          </>
                        ) : (
                          <>
                            <UserPlus className="w-3.5 h-3.5" />
                            <span>{t('follow')}</span>
                          </>
                        )}
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => onSelectPost(post)}
                      className="min-h-[36px] ml-auto px-3 rounded-xl border border-slate-200 dark:border-white/10 hover:border-[#D4AF37] text-xs font-semibold text-slate-800 dark:text-slate-200 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors cursor-pointer"
                    >
                      <span>{t('viewPost')}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-[#D4AF37]" />
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </section>
  );
};
