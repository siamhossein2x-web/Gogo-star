import React, { useEffect, useMemo, useState } from 'react';
import {
  collection,
  doc,
  getDoc,
  limit,
  onSnapshot,
  query,
  serverTimestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  BarChart3,
  CheckCircle2,
  CreditCard,
  ExternalLink,
  Loader2,
  Megaphone,
  Pause,
  Play,
  Plus,
  RefreshCw,
  ShieldAlert,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import { bdtToPoisha, formatBDT } from '../lib/finance';
import { isValidHttpUrl, sanitizeExternalUrl } from '../lib/url';
import { AdCampaign, AdPayment, CampaignObjective, Post, PublicPage } from '../types/hearthline';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { MediaUploadInput } from './MediaUploadInput';
import { AdsManagerAnalyticsTab } from './AdsManagerAnalyticsTab';

interface Props {
  promotePage?: PublicPage | null;
  onClearPromotePage?: () => void;
}

export const AdsManagerView: React.FC<Props> = ({ promotePage, onClearPromotePage }) => {
  const { firebaseUser } = useAuth();
  const { pushToast } = useToast();

  const [subTab, setSubTab] = useState<'campaigns' | 'analytics' | 'payments'>('campaigns');
  const [posts, setPosts] = useState<Post[]>([]);
  const [analyticsEntityId, setAnalyticsEntityId] = useState<string>('profile');

  const [campaigns, setCampaigns] = useState<AdCampaign[]>([]);
  const [payments, setPayments] = useState<AdPayment[]>([]);
  const [manageablePages, setManageablePages] = useState<Array<PublicPage & { roleLabel: 'Owner' | 'Admin' }>>([]);
  const [statusFilter, setStatusFilter] = useState<'all' | AdCampaign['status']>('all');
  const [showCreate, setShowCreate] = useState(Boolean(promotePage));
  const [resubmitTarget, setResubmitTarget] = useState<AdCampaign | null>(null);
  const [resubmitMethod, setResubmitMethod] = useState<'bkash' | 'nagad' | 'bank'>('bkash');
  const [resubmitTxRef, setResubmitTxRef] = useState('');

  // Campaign Builder Form
  const [sourceType, setSourceType] = useState<'ads_manager' | 'page_promotion'>(
    promotePage ? 'page_promotion' : 'ads_manager'
  );
  const [selectedPageId, setSelectedPageId] = useState(promotePage?.id || '');
  const [title, setTitle] = useState(promotePage ? `Promote ${promotePage.name}` : '');
  const [objective, setObjective] = useState<CampaignObjective>(
    promotePage ? 'page_followers' : 'reach'
  );
  const [creativeText, setCreativeText] = useState('');
  const [creativeMediaUrl, setCreativeMediaUrl] = useState('');
  const [targetUrl, setTargetUrl] = useState('');
  const [targetCountry, setTargetCountry] = useState('Bangladesh');
  const [targetCity, setTargetCity] = useState('Dhaka');
  const [targetLanguage, setTargetLanguage] = useState('en_bn');
  const [targetAgeRange, setTargetAgeRange] = useState('18-45');
  const [targetInterest, setTargetInterest] = useState('Technology & Creators');
  const [dailyBdt, setDailyBdt] = useState(250);
  const [days, setDays] = useState(7);
  const [method, setMethod] = useState<'bkash' | 'nagad' | 'bank'>('bkash');
  const [txRef, setTxRef] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (promotePage) {
      setShowCreate(true);
      setSourceType('page_promotion');
      setSelectedPageId(promotePage.id);
      setTitle(`Promote ${promotePage.name}`);
      setObjective('page_followers');
      setCreativeText(promotePage.description || `Discover ${promotePage.name} on HEARTHLINE.`);
      setCreativeMediaUrl(promotePage.coverUrl || promotePage.avatarUrl || '');
    }
  }, [promotePage]);

  useEffect(() => {
    if (!firebaseUser) return;

    const uCamp = onSnapshot(
      query(collection(db, 'adCampaigns'), where('advertiserUid', '==', firebaseUser.uid)),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as AdCampaign));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setCampaigns(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'adCampaigns')
    );

    const uPay = onSnapshot(
      query(collection(db, 'adPayments'), where('advertiserUid', '==', firebaseUser.uid)),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as AdPayment));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setPayments(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'adPayments')
    );

    // Load both Pages owned by the user and Pages where user holds Owner or Page Admin role
    const uPages = onSnapshot(
      query(collection(db, 'pages'), limit(60)),
      async (snap) => {
        const allPages = snap.docs.map((d) => ({ id: d.id, ...d.data() } as PublicPage));
        const checks = await Promise.all(
          allPages.map(async (pg) => {
            if (pg.ownerUid === firebaseUser.uid) {
              return { ...pg, roleLabel: 'Owner' as const };
            }
            try {
              const adminSnap = await getDoc(doc(db, 'pages', pg.id, 'admins', firebaseUser.uid));
              if (adminSnap.exists()) {
                const role = adminSnap.data().role as string;
                if (role === 'owner' || role === 'admin') {
                  return { ...pg, roleLabel: role === 'owner' ? ('Owner' as const) : ('Admin' as const) };
                }
              }
            } catch {
              // ignore non-accessible roles
            }
            return null;
          })
        );
        const list = checks.filter((v): v is PublicPage & { roleLabel: 'Owner' | 'Admin' } => v !== null);
        setManageablePages(list);
        if (!selectedPageId && list.length > 0) {
          setSelectedPageId(list[0].id);
        }
      },
      () => {}
    );

    const uPosts = onSnapshot(
      query(collection(db, 'posts'), where('authorUid', '==', firebaseUser.uid), limit(100)),
      (snap) => {
        setPosts(snap.docs.map((d) => ({ id: d.id, ...d.data() } as Post)));
      },
      () => {}
    );

    return () => {
      uCamp();
      uPay();
      uPages();
      uPosts();
    };
  }, [firebaseUser?.uid]);

  const safeDailyBdt = Math.max(100, Number.isFinite(dailyBdt) ? Math.round(dailyBdt) : 100);
  const safeDays = Math.min(90, Math.max(1, Number.isFinite(days) ? Math.round(days) : 1));
  const lifetimeBdt = safeDailyBdt * safeDays;
  const dailyPoisha = bdtToPoisha(safeDailyBdt);
  const lifetimePoisha = bdtToPoisha(lifetimeBdt);

  const totalSpendPoisha = campaigns.reduce((sum, c) => sum + (c.spentPoisha || 0), 0);
  const totalImpressions = campaigns.reduce((sum, c) => sum + (c.paidImpressions || 0), 0);
  const totalClicks = campaigns.reduce((sum, c) => sum + (c.clicks || 0), 0);
  const overallCtr = totalImpressions > 0 ? ((totalClicks / totalImpressions) * 100).toFixed(2) : '0.00';

  const filteredCampaigns = useMemo(
    () => (statusFilter === 'all' ? campaigns : campaigns.filter((c) => c.status === statusFilter)),
    [campaigns, statusFilter]
  );

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email first to launch ad campaigns.', 'error');
      return;
    }
    if (title.trim().length < 2) {
      pushToast('Enter a valid campaign title.', 'error');
      return;
    }
    if (targetUrl.trim() && !isValidHttpUrl(targetUrl)) {
      pushToast('Destination URL must start with http:// or https://', 'error');
      return;
    }
    if (sourceType === 'page_promotion' && !selectedPageId) {
      pushToast('Select a Public Page you own or manage as Page Admin.', 'error');
      return;
    }
    if (txRef.trim().length < 3) {
      pushToast('Enter a valid bKash, Nagad, or Bank payment reference.', 'error');
      return;
    }

    setBusy(true);
    const campaignId = makeSafeId('camp');
    const paymentId = makeSafeId('adpay');
    const startDate = new Date().toISOString().slice(0, 10);
    const endDate = new Date(Date.now() + safeDays * 86400000).toISOString().slice(0, 10);

    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'adCampaigns', campaignId), {
        advertiserUid: firebaseUser.uid,
        sourceType,
        ...(sourceType === 'page_promotion' && selectedPageId ? { pageId: selectedPageId } : {}),
        title: title.trim().slice(0, 120),
        objective,
        creativeText: creativeText.trim().slice(0, 1500),
        creativeMediaUrl: creativeMediaUrl.trim().slice(0, 1024),
        targetUrl: targetUrl.trim().slice(0, 1024),
        targetCountry: targetCountry.trim().slice(0, 60),
        targetCity: targetCity.trim().slice(0, 80),
        targetLanguage,
        targetAgeRange,
        targetInterest: targetInterest.trim().slice(0, 80),
        dailyBudgetPoisha: dailyPoisha,
        lifetimeBudgetPoisha: lifetimePoisha,
        spentPoisha: 0,
        startDate,
        endDate,
        status: 'pending_review',
        paymentStatus: 'pending_verification',
        paidImpressions: 0,
        paidReach: 0,
        clicks: 0,
        videoViews: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      batch.set(doc(db, 'adPayments', paymentId), {
        campaignId,
        advertiserUid: firebaseUser.uid,
        amountPoisha: lifetimePoisha,
        method,
        transactionRef: txRef.trim().slice(0, 80),
        status: 'pending_verification',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      await batch.commit();
      setShowCreate(false);
      setTitle('');
      setCreativeText('');
      setCreativeMediaUrl('');
      setTargetUrl('');
      setTxRef('');
      onClearPromotePage?.();
      pushToast('Ad campaign and payment reference submitted for Admin review.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `adCampaigns/${campaignId}`);
    } finally {
      setBusy(false);
    }
  };

  const handleTogglePause = async (c: AdCampaign) => {
    if (c.status !== 'active' && c.status !== 'paused') return;
    if (c.status === 'paused' && c.paymentStatus !== 'verified') {
      pushToast('Verified payment is required before resuming this campaign.', 'error');
      return;
    }
    const nextStatus = c.status === 'active' ? 'paused' : 'active';
    try {
      await updateDoc(doc(db, 'adCampaigns', c.id), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
      pushToast(`Campaign ${nextStatus === 'paused' ? 'paused' : 'resumed'}.`, 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `adCampaigns/${c.id}`);
    }
  };

  const handleResubmitPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser?.emailVerified || !resubmitTarget) return;
    if (resubmitTxRef.trim().length < 3) {
      pushToast('Enter a valid transaction reference (min 3 characters).', 'error');
      return;
    }
    setBusy(true);
    const paymentId = makeSafeId('adpay');
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'adPayments', paymentId), {
        campaignId: resubmitTarget.id,
        advertiserUid: firebaseUser.uid,
        amountPoisha: resubmitTarget.lifetimeBudgetPoisha,
        method: resubmitMethod,
        transactionRef: resubmitTxRef.trim().slice(0, 80),
        status: 'pending_verification',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.update(doc(db, 'adCampaigns', resubmitTarget.id), {
        status: 'pending_review',
        paymentStatus: 'pending_verification',
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
      setResubmitTarget(null);
      setResubmitTxRef('');
      pushToast('Payment reference re-submitted for Admin verification.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `adCampaigns/${resubmitTarget.id}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-bold flex items-center gap-2">
            <Megaphone className="w-5 h-5 text-[#D4AF37]" />
            HEARTHLINE Ads Manager
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Transparent BDT (৳) advertising. Paid delivery is capped at your lifetime budget and requires verified payment &amp; Admin review.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowCreate(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold hover:bg-[#E5C158] cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Create Ad Campaign
        </button>
      </div>

      {/* Advertiser Summary KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
          <p className="text-xs text-slate-500">Total Campaigns</p>
          <p className="font-mono tabular-nums font-bold text-xl mt-1">{campaigns.length}</p>
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
          <p className="text-xs text-slate-500">Paid Spend</p>
          <p className="font-mono tabular-nums font-bold text-xl text-[#D4AF37] mt-1">
            {formatBDT(totalSpendPoisha)}
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
          <p className="text-xs text-slate-500">Paid Impressions</p>
          <p className="font-mono tabular-nums font-bold text-xl mt-1">
            {totalImpressions.toLocaleString()}
          </p>
        </div>
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
          <p className="text-xs text-slate-500">Verified Clicks · CTR</p>
          <p className="font-mono tabular-nums font-bold text-xl text-[#3B82F6] mt-1">
            {totalClicks.toLocaleString()} <span className="text-xs text-slate-400">({overallCtr}%)</span>
          </p>
        </div>
      </div>

      {/* SubTab Navigation */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#13151B] border border-slate-200 dark:border-white/10">
        {[
          { id: 'campaigns', label: 'Campaigns & Ads' },
          { id: 'analytics', label: 'Analytics & Recharts' },
          { id: 'payments', label: 'Payment History' },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setSubTab(tab.id as typeof subTab)}
            className={`flex-1 min-h-[38px] py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === tab.id
                ? 'bg-white dark:bg-[#D4AF37] text-slate-900 dark:text-[#0A0B0E] shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {subTab === 'analytics' && (
        <AdsManagerAnalyticsTab
          campaigns={campaigns}
          posts={posts}
          manageablePages={manageablePages}
          selectedEntityId={analyticsEntityId}
          onSelectEntityId={setAnalyticsEntityId}
        />
      )}

      {subTab === 'payments' && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
          <h2 className="font-display font-bold text-sm flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-[#3B82F6]" /> Ad Payment Submissions
          </h2>
          {payments.length === 0 ? (
            <p className="text-xs text-slate-500">No payment references submitted yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-white/5 text-xs">
              {payments.map((p) => (
                <div key={p.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <p className="font-semibold uppercase">
                      {p.method} · Ref: <span className="font-mono">{p.transactionRef}</span>
                    </p>
                    <p className="text-slate-500">Campaign ID: {p.campaignId}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-white/5 capitalize">
                      {p.status.replace('_', ' ')}
                    </span>
                    <span className="font-mono tabular-nums font-bold">{formatBDT(p.amountPoisha)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {subTab === 'campaigns' && (
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display font-bold text-sm flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#D4AF37]" /> Your Campaigns (Paid Metrics &amp; Analytics)
          </h2>
          <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
            {(
              [
                ['all', 'All'],
                ['active', 'Active'],
                ['pending_review', 'Pending'],
                ['paused', 'Paused'],
                ['completed', 'Completed'],
                ['rejected', 'Rejected'],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setStatusFilter(id)}
                className={`px-2.5 py-1 rounded-lg font-semibold cursor-pointer ${
                  statusFilter === id
                    ? 'bg-[#D4AF37] text-[#0A0B0E]'
                    : 'bg-slate-100 dark:bg-white/5 text-slate-500'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {filteredCampaigns.length === 0 ? (
          <div className="py-10 text-center space-y-2">
            <p className="text-sm font-semibold">No ad campaigns match this filter</p>
            <p className="text-xs text-slate-500">
              Create a campaign from Ads Manager, boost a post from the Home Feed, or promote a Public Page.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredCampaigns.map((c) => {
              const pct = Math.min(100, Math.round(((c.spentPoisha || 0) / Math.max(1, c.lifetimeBudgetPoisha)) * 100));
              const remaining = Math.max(0, c.lifetimeBudgetPoisha - (c.spentPoisha || 0));
              const ctr = c.paidImpressions > 0 ? ((c.clicks / c.paidImpressions) * 100).toFixed(2) : '0.00';
              const avgCpcPoisha = c.clicks > 0 ? Math.round((c.spentPoisha || 0) / c.clicks) : 0;
              const cpmPoisha = c.paidImpressions > 0 ? Math.round(((c.spentPoisha || 0) * 1000) / c.paidImpressions) : 0;
              const safeDest = sanitizeExternalUrl(c.targetUrl);
              const isVid = Boolean(c.creativeMediaUrl) && /\.(mp4|webm|mov|m4v)(\?|$)|\/video\/upload\//i.test(c.creativeMediaUrl || '');

              return (
                <div
                  key={c.id}
                  className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-4 space-y-3"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      {c.creativeMediaUrl && (
                        isVid ? (
                          <video
                            src={c.creativeMediaUrl}
                            muted
                            playsInline
                            className="w-16 h-16 rounded-lg object-cover bg-black shrink-0"
                          />
                        ) : (
                          <img
                            src={c.creativeMediaUrl}
                            alt={c.title}
                            loading="lazy"
                            referrerPolicy="no-referrer"
                            className="w-16 h-16 rounded-lg object-cover bg-black/20 shrink-0"
                          />
                        )
                      )}
                      <div className="space-y-1 min-w-0">
                        <div className="flex flex-wrap items-center gap-2 text-[11px]">
                          <h3 className="font-semibold text-sm text-slate-900 dark:text-white">{c.title}</h3>
                          <span className="font-semibold uppercase text-[#D4AF37]">
                            {c.sourceType.replace(/_/g, ' ')}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span
                            className={`font-semibold capitalize ${
                              c.status === 'active'
                                ? 'text-emerald-500'
                                : c.status === 'rejected'
                                ? 'text-rose-500'
                                : 'text-[#3B82F6]'
                            }`}
                          >
                            {c.status.replace(/_/g, ' ')}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 capitalize">
                          {c.objective.replace(/_/g, ' ')} · Payment: {c.paymentStatus.replace(/_/g, ' ')} · Target: {c.targetCity || c.targetCountry || 'Bangladesh'} ({c.targetAgeRange || '18+'})
                        </p>
                        {safeDest && (
                          <a
                            href={safeDest}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-[11px] text-[#3B82F6] hover:underline truncate max-w-full"
                          >
                            <ExternalLink className="w-3 h-3 shrink-0" />
                            <span className="truncate">{safeDest}</span>
                          </a>
                        )}
                        {c.reviewNote && (
                          <p className="text-xs text-amber-500">Admin Note: {c.reviewNote}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {(c.status === 'active' || c.status === 'paused') && (
                        <button
                          type="button"
                          onClick={() => handleTogglePause(c)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-semibold hover:border-[#D4AF37] cursor-pointer"
                        >
                          {c.status === 'active' ? (
                            <>
                              <Pause className="w-3.5 h-3.5" /> Pause
                            </>
                          ) : (
                            <>
                              <Play className="w-3.5 h-3.5" /> Resume
                            </>
                          )}
                        </button>
                      )}
                      {(c.status === 'rejected' || c.status === 'draft') && (
                        <button
                          type="button"
                          onClick={() => setResubmitTarget(c)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold hover:bg-[#E5C158] cursor-pointer"
                        >
                          <RefreshCw className="w-3.5 h-3.5" /> Resubmit Payment
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px] font-mono tabular-nums text-slate-500">
                      <span>Spent: {formatBDT(c.spentPoisha)} / {formatBDT(c.lifetimeBudgetPoisha)}</span>
                      <span>Remaining: {formatBDT(remaining)} ({pct}%)</span>
                    </div>
                    <div className="h-1.5 w-full rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                      <div className="h-full bg-[#D4AF37]" style={{ width: `${pct}%` }} />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 pt-1 text-xs font-mono tabular-nums">
                    <div>
                      <span className="block text-[10px] font-sans text-slate-500">Paid Reach</span>
                      <span className="font-semibold">{c.paidReach.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="block text-[10px] font-sans text-slate-500">Impressions</span>
                      <span className="font-semibold">{c.paidImpressions.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="block text-[10px] font-sans text-slate-500">Clicks</span>
                      <span className="font-semibold text-[#3B82F6]">{c.clicks.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="block text-[10px] font-sans text-slate-500">CTR</span>
                      <span className="font-semibold text-emerald-500">{ctr}%</span>
                    </div>
                    <div>
                      <span className="block text-[10px] font-sans text-slate-500">Avg CPC</span>
                      <span className="font-semibold">{avgCpcPoisha > 0 ? formatBDT(avgCpcPoisha) : '—'}</span>
                    </div>
                    <div>
                      <span className="block text-[10px] font-sans text-slate-500">CPM / Views</span>
                      <span className="font-semibold">
                        {cpmPoisha > 0 ? formatBDT(cpmPoisha) : `${c.videoViews}v`}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      )}

      {/* Ad Payments Ledger */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
        <h2 className="font-display font-bold text-sm flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-[#3B82F6]" /> Ad Payment Submissions
        </h2>
        {payments.length === 0 ? (
          <p className="text-xs text-slate-500">No payment references submitted yet.</p>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-white/5 text-xs">
            {payments.map((p) => (
              <div key={p.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-semibold uppercase">
                    {p.method} · Ref: <span className="font-mono">{p.transactionRef}</span>
                  </p>
                  <p className="text-slate-500">Campaign ID: {p.campaignId}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-white/5 capitalize">
                    {p.status.replace('_', ' ')}
                  </span>
                  <span className="font-mono tabular-nums font-bold">{formatBDT(p.amountPoisha)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Campaign Builder Modal */}
      {showCreate && (
        <div className="fixed inset-0 z-[75] bg-black/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="w-full sm:max-w-xl rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] shadow-2xl max-h-[92vh] flex flex-col overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 dark:border-white/10">
              <h3 className="font-display font-bold text-base flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-[#D4AF37]" />
                {sourceType === 'page_promotion' ? 'Page Promotion Campaign' : 'Create Ad Campaign'}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setShowCreate(false);
                  onClearPromotePage?.();
                }}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCampaign} className="p-5 space-y-4 overflow-y-auto text-xs">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSourceType('ads_manager')}
                  className={`py-2 rounded-xl border font-semibold cursor-pointer ${
                    sourceType === 'ads_manager'
                      ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#D4AF37]'
                      : 'border-slate-200 dark:border-white/10 text-slate-500'
                  }`}
                >
                  Ads Manager Campaign
                </button>
                <button
                  type="button"
                  onClick={() => setSourceType('page_promotion')}
                  className={`py-2 rounded-xl border font-semibold cursor-pointer ${
                    sourceType === 'page_promotion'
                      ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#D4AF37]'
                      : 'border-slate-200 dark:border-white/10 text-slate-500'
                  }`}
                >
                  Promote a Public Page
                </button>
              </div>

              {sourceType === 'page_promotion' && (
                <div>
                  <label className="block text-slate-500 mb-1">Select Manageable Page (Owner or Page Admin)</label>
                  <select
                    value={selectedPageId}
                    onChange={(e) => setSelectedPageId(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                  >
                    {manageablePages.length === 0 ? (
                      <option value="">No Pages where you are Owner or Admin</option>
                    ) : (
                      manageablePages.map((pg) => (
                        <option key={pg.id} value={pg.id}>
                          {pg.name} (@{pg.username}) · {pg.roleLabel}
                        </option>
                      ))
                    )}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">Campaign Name</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Dhaka Creators Launch"
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Objective</label>
                  <select
                    value={objective}
                    onChange={(e) => setObjective(e.target.value as CampaignObjective)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                  >
                    <option value="brand_awareness">Brand Awareness</option>
                    <option value="reach">Reach</option>
                    <option value="post_engagement">Post Engagement</option>
                    <option value="page_followers">Page Followers</option>
                    <option value="video_views">Video Views</option>
                    <option value="profile_visits">Profile Visits</option>
                    <option value="website_traffic">Website Traffic</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-500 mb-1">Ad Creative Copy</label>
                <textarea
                  rows={2}
                  value={creativeText}
                  onChange={(e) => setCreativeText(e.target.value)}
                  placeholder="Write clear, authentic copy for your Sponsored placement..."
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                />
              </div>

              <MediaUploadInput
                accept="image/*,video/*"
                mediaKind="auto"
                label="Upload Creative Image/Video"
                value={creativeMediaUrl}
                onUploaded={(url) => setCreativeMediaUrl(url)}
              />

              <input
                type="url"
                value={targetUrl}
                onChange={(e) => setTargetUrl(e.target.value)}
                placeholder="Destination URL (optional, https://...)"
                className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              />

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <input
                  type="text"
                  value={targetCountry}
                  onChange={(e) => setTargetCountry(e.target.value)}
                  placeholder="Country"
                  className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                />
                <input
                  type="text"
                  value={targetCity}
                  onChange={(e) => setTargetCity(e.target.value)}
                  placeholder="City"
                  className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                />
                <select
                  value={targetAgeRange}
                  onChange={(e) => setTargetAgeRange(e.target.value)}
                  className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                >
                  <option value="18-24">18–24</option>
                  <option value="18-45">18–45</option>
                  <option value="25-54">25–54</option>
                  <option value="18-65+">18+</option>
                </select>
                <select
                  value={targetLanguage}
                  onChange={(e) => setTargetLanguage(e.target.value)}
                  className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                >
                  <option value="en_bn">EN + বাংলা</option>
                  <option value="bn">বাংলা</option>
                  <option value="en">English</option>
                </select>
              </div>

              <input
                type="text"
                value={targetInterest}
                onChange={(e) => setTargetInterest(e.target.value)}
                placeholder="Interest category (e.g., Technology, Culture, Education)"
                className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              />

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-500 mb-1">Daily Budget (BDT ৳, min 100)</label>
                  <input
                    type="number"
                    min={100}
                    step={50}
                    value={dailyBdt}
                    onChange={(e) => setDailyBdt(Number(e.target.value))}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Duration (Days)</label>
                  <input
                    type="number"
                    min={1}
                    max={90}
                    value={days}
                    onChange={(e) => setDays(Number(e.target.value))}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono tabular-nums"
                  />
                </div>
              </div>

              <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-3 space-y-1">
                <div className="flex justify-between font-semibold">
                  <span>Lifetime Spend Cap</span>
                  <span className="font-mono text-[#D4AF37]">{formatBDT(lifetimePoisha)}</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Page ad spend is never credited as Page Owner monetization earnings. Delivery stops automatically when your cap is reached.
                </p>
              </div>

              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-white/10">
                <p className="font-semibold flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-[#D4AF37]" /> Manual Payment Verification (V1)
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <select
                    value={method}
                    onChange={(e) => setMethod(e.target.value as 'bkash' | 'nagad' | 'bank')}
                    className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                  >
                    <option value="bkash">bKash</option>
                    <option value="nagad">Nagad</option>
                    <option value="bank">Bank Transfer</option>
                  </select>
                  <input
                    type="text"
                    required
                    value={txRef}
                    onChange={(e) => setTxRef(e.target.value)}
                    placeholder="Transaction Reference (e.g. TRX94821)"
                    className="sm:col-span-2 h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={busy}
                className="w-full h-11 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold flex items-center justify-center gap-2 hover:bg-[#E5C158] cursor-pointer disabled:opacity-50"
              >
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                Submit Campaign for Review
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Resubmit Payment Modal for Rejected/Draft Campaigns */}
      {resubmitTarget && (
        <div className="fixed inset-0 z-[75] bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleResubmitPayment}
            className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4 text-xs shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-sm">Resubmit Payment Verification</h3>
              <button
                type="button"
                onClick={() => setResubmitTarget(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-slate-500">
              Campaign: <strong className="text-slate-900 dark:text-white">{resubmitTarget.title}</strong> · Budget:{' '}
              <strong className="font-mono text-[#D4AF37]">
                {formatBDT(resubmitTarget.lifetimeBudgetPoisha)}
              </strong>
            </p>
            <div className="grid grid-cols-3 gap-2">
              <select
                value={resubmitMethod}
                onChange={(e) => setResubmitMethod(e.target.value as 'bkash' | 'nagad' | 'bank')}
                className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              >
                <option value="bkash">bKash</option>
                <option value="nagad">Nagad</option>
                <option value="bank">Bank</option>
              </select>
              <input
                type="text"
                required
                value={resubmitTxRef}
                onChange={(e) => setResubmitTxRef(e.target.value)}
                placeholder="New Transaction Reference"
                className="col-span-2 h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
              />
            </div>
            <button
              type="submit"
              disabled={busy}
              className="w-full h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold hover:bg-[#E5C158] cursor-pointer disabled:opacity-50"
            >
              {busy ? 'Submitting...' : 'Submit Payment Reference'}
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
