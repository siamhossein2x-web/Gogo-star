import React, { useRef, useState } from 'react';
import { Upload, Link2, Loader2, Check, AlertCircle } from 'lucide-react';
import {
  CloudinaryUploadError,
  isCloudinaryConfigured,
  uploadToCloudinary,
} from '../lib/cloudinary';
import { useToast } from './Toast';

interface Props {
  accept: 'image/*' | 'video/*' | 'image/*,video/*';
  mediaKind: 'image' | 'video' | 'auto';
  label: string;
  value?: string;
  onUploaded: (url: string, detectedType: 'image' | 'video') => void;
}

export const MediaUploadInput: React.FC<Props> = ({
  accept,
  mediaKind,
  label,
  value,
  onUploaded,
}) => {
  const fileRef = useRef<HTMLInputElement>(null);
  const { pushToast } = useToast();
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [urlDraft, setUrlDraft] = useState(value || '');
  const [dragOver, setDragOver] = useState(false);
  const [uploadError, setUploadError] = useState<{
    message: string;
    status?: number;
    body?: string;
  } | null>(null);

  const configured = isCloudinaryConfigured();

  const processFile = async (file: File) => {
    setUploading(true);
    setProgress(0);
    setUploadError(null);
    try {
      const res = await uploadToCloudinary(file, mediaKind, setProgress);
      onUploaded(res.secureUrl, res.resourceType === 'video' ? 'video' : 'image');
      setUrlDraft(res.secureUrl);
      pushToast('Media uploaded via Cloudinary.', 'success');
    } catch (err) {
      if (err instanceof CloudinaryUploadError) {
        setUploadError({
          message: err.message,
          status: err.status,
          body: err.responseBody,
        });
        pushToast(err.message, 'error');
      } else {
        const msg = err instanceof Error ? err.message : 'Upload failed.';
        setUploadError({ message: msg });
        pushToast(msg, 'error');
      }
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processFile(file);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (uploading) return;
    if (!configured) {
      setShowUrlInput(true);
      return;
    }
    const file = e.dataTransfer.files?.[0];
    if (file) await processFile(file);
  };

  const applyDirectUrl = () => {
    const trimmed = urlDraft.trim();
    if (!trimmed.startsWith('https://') && !trimmed.startsWith('/src/assets/')) {
      pushToast('Please provide a valid HTTPS media URL.', 'error');
      return;
    }
    const isVideo =
      /\/video\/upload\//i.test(trimmed) ||
      /\.(mp4|webm|mov|m4v)(\?|$)/i.test(trimmed) ||
      mediaKind === 'video';
    onUploaded(trimmed, isVideo ? 'video' : 'image');
    setShowUrlInput(false);
    setUploadError(null);
    pushToast('Media URL attached.', 'success');
  };

  return (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={handleDrop}
      className={`space-y-2 rounded-xl transition-colors ${
        dragOver ? 'ring-2 ring-[#D4AF37]/60 bg-[#D4AF37]/5 p-2 -m-2' : ''
      }`}
    >
      <div className="flex flex-wrap items-center gap-2">
        <input
          ref={fileRef}
          type="file"
          accept={accept}
          onChange={handleFileChange}
          className="hidden"
        />
        <button
          type="button"
          disabled={uploading}
          onClick={() => {
            if (!configured) {
              setShowUrlInput(true);
              pushToast(
                'Cloudinary preset not configured yet — paste an HTTPS media URL or configure Cloudinary in Settings.',
                'info'
              );
              return;
            }
            fileRef.current?.click();
          }}
          className="inline-flex items-center gap-2 min-h-[40px] px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-[#1B1E26] text-xs font-medium text-slate-800 dark:text-slate-200 hover:border-[#D4AF37]/50 transition-colors cursor-pointer disabled:opacity-50 whitespace-nowrap"
        >
          {uploading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#D4AF37]" />
          ) : (
            <Upload className="w-3.5 h-3.5 text-[#D4AF37]" />
          )}
          {uploading ? `Uploading ${progress}%` : label}
        </button>

        <button
          type="button"
          onClick={() => setShowUrlInput((s) => !s)}
          className="inline-flex items-center gap-1.5 min-h-[40px] px-3 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer whitespace-nowrap"
        >
          <Link2 className="w-3.5 h-3.5" />
          {showUrlInput ? 'Hide URL' : 'Paste HTTPS URL'}
        </button>

        {value && !uploading && (
          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-emerald-500">
            <Check className="w-3.5 h-3.5" />
            Ready
          </span>
        )}
      </div>

      {uploading && (
        <div className="w-full h-1.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
          <div
            className="h-full bg-[#D4AF37] transition-all duration-150"
            style={{ width: `${Math.max(5, progress)}%` }}
          />
        </div>
      )}

      {uploadError && (
        <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-2.5 text-[11px] text-rose-400 space-y-1">
          <p className="font-semibold flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            {uploadError.message}
          </p>
          {uploadError.body && (
            <p className="font-mono text-[10px] break-all opacity-90">
              HTTP {uploadError.status}: {uploadError.body}
            </p>
          )}
        </div>
      )}

      {!configured && (
        <p className="text-[11px] text-amber-600 dark:text-amber-400/90">
          Cloudinary unsigned preset is not configured. Configure it in Settings to enable direct file uploads, or attach a verified HTTPS media URL.
        </p>
      )}

      {showUrlInput && (
        <div className="flex items-center gap-2">
          <input
            type="url"
            value={urlDraft}
            onChange={(e) => setUrlDraft(e.target.value)}
            placeholder="https://res.cloudinary.com/... or https://..."
            className="flex-1 h-10 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#0F1116] px-3 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#D4AF37]"
          />
          <button
            type="button"
            onClick={applyDirectUrl}
            className="inline-flex items-center gap-1 h-10 px-3.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold hover:bg-[#E5C158] cursor-pointer whitespace-nowrap"
          >
            <Check className="w-3.5 h-3.5" />
            Attach
          </button>
        </div>
      )}
    </div>
  );
};
