import React, { useMemo, useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { BarChart3, Eye, Film, Heart, MessageSquare, Share2, TrendingUp, User, Flag } from 'lucide-react';
import { AdCampaign, Post, PublicPage } from '../types/hearthline';
import { formatBDT } from '../lib/finance';
import { formatCompactNumber } from '../lib/finance';

interface AdsManagerAnalyticsTabProps {
  campaigns: AdCampaign[];
  posts: Post[];
  manageablePages: Array<PublicPage & { roleLabel: 'Owner' | 'Admin' }>;
  selectedEntityId: string; // 'profile' or pageId
  onSelectEntityId: (id: string) => void;
}

export const AdsManagerAnalyticsTab: React.FC<AdsManagerAnalyticsTabProps> = ({
  campaigns,
  posts,
  manageablePages,
  selectedEntityId,
  onSelectEntityId,
}) => {
  const [timeRange, setTimeRange] = useState<'7d' | '14d' | '30d'>('14d');

  // Filter campaigns and posts by selected entity (profile vs page)
  const filteredCampaigns = useMemo(() => {
    if (selectedEntityId === 'profile') {
      return campaigns.filter((c) => !c.pageId);
    }
    return campaigns.filter((c) => c.pageId === selectedEntityId);
  }, [campaigns, selectedEntityId]);

  const filteredPosts = useMemo(() => {
    if (selectedEntityId === 'profile') {
      return posts.filter((p) => p.authorType === 'user' && !p.pageId);
    }
    return posts.filter((p) => p.pageId === selectedEntityId);
  }, [posts, selectedEntityId]);

  // Aggregate stats
  const totalImpressions = filteredCampaigns.reduce((sum, c) => sum + (c.paidImpressions || 0), 0);
  const totalClicks = filteredCampaigns.reduce((sum, c) => sum + (c.clicks || 0), 0);
  const totalVideoViews = filteredCampaigns.reduce((sum, c) => sum + (c.videoViews || 0), 0);
  const totalSpentPoisha = filteredCampaigns.reduce((sum, c) => sum + (c.spentPoisha || 0), 0);
  const overallCtr = totalImpressions > 0 ? ((totalClicks / totalImpressions) * 100).toFixed(2) : '0.00';

  // Build Daily Impressions & Engagement growth trend series (mock simulated daily breakdown or aggregated by date)
  const chartData = useMemo(() => {
    const daysCount = timeRange === '7d' ? 7 : timeRange === '14d' ? 14 : 30;
    const result = [];
    const now = Date.now();
    const dayMs = 86400000;

    for (let i = daysCount - 1; i >= 0; i--) {
      const d = new Date(now - i * dayMs);
      const dateStr = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      // Calculate deterministic simulated distribution based on campaign metrics
      const ratio = 1 - i * 0.02;
      const dayImpressions = Math.round((totalImpressions / daysCount) * Math.max(0.4, ratio + Math.sin(i) * 0.3));
      const dayClicks = Math.round((totalClicks / daysCount) * Math.max(0.3, ratio + Math.cos(i) * 0.2));
      const dayEngagement = Math.round((filteredPosts.reduce((s, p) => s + (p.likesCount || 0) + (p.commentsCount || 0), 0) / Math.max(1, daysCount)) * Math.max(0.5, ratio));

      result.push({
        date: dateStr,
        impressions: Math.max(12, dayImpressions),
        clicks: Math.max(2, dayClicks),
        engagement: Math.max(5, dayEngagement),
      });
    }
    return result;
  }, [filteredCampaigns, filteredPosts, totalImpressions, totalClicks, timeRange]);

  return (
    <div className="space-y-6">
      {/* Entity Switcher Bar & Time Range */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B]">
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-slate-500">Viewing Analytics For:</span>
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-[#0A0B0E] p-1 rounded-xl border border-slate-200 dark:border-white/10">
            <button
              type="button"
              onClick={() => onSelectEntityId('profile')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                selectedEntityId === 'profile'
                  ? 'bg-white dark:bg-[#D4AF37] text-slate-900 dark:text-[#0A0B0E] shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>Personal Profile</span>
            </button>
            {manageablePages.map((pg) => (
              <button
                key={pg.id}
                type="button"
                onClick={() => onSelectEntityId(pg.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  selectedEntityId === pg.id
                    ? 'bg-white dark:bg-[#D4AF37] text-slate-900 dark:text-[#0A0B0E] shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Flag className="w-3.5 h-3.5" />
                <span className="truncate max-w-[120px]">{pg.name}</span>
                <span className="text-[10px] opacity-75 font-mono">({pg.roleLabel})</span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-1 bg-slate-100 dark:bg-[#0A0B0E] p-1 rounded-xl border border-slate-200 dark:border-white/10 text-xs">
          {(['7d', '14d', '30d'] as const).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setTimeRange(r)}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-colors cursor-pointer uppercase ${
                timeRange === r
                  ? 'bg-white dark:bg-[#D4AF37] text-slate-900 dark:text-[#0A0B0E] shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Impressions</span>
            <Eye className="w-4 h-4 text-[#3B82F6]" />
          </div>
          <p className="text-xl font-bold font-mono text-slate-900 dark:text-white">
            {formatCompactNumber(totalImpressions)}
          </p>
          <p className="text-[11px] text-emerald-500 font-medium">+12.4% vs previous period</p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Clicks / CTR</span>
            <TrendingUp className="w-4 h-4 text-[#D4AF37]" />
          </div>
          <p className="text-xl font-bold font-mono text-slate-900 dark:text-white">
            {formatCompactNumber(totalClicks)} <span className="text-xs font-normal text-slate-400">({overallCtr}%)</span>
          </p>
          <p className="text-[11px] text-emerald-500 font-medium">Healthy CTR rate</p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Video Views</span>
            <Film className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-xl font-bold font-mono text-slate-900 dark:text-white">
            {formatCompactNumber(totalVideoViews)}
          </p>
          <p className="text-[11px] text-slate-400">Boosted video performance</p>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-1">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span>Total Ad Spent</span>
            <span className="font-mono text-[#D4AF37]">৳</span>
          </div>
          <p className="text-xl font-bold font-mono text-slate-900 dark:text-white">
            {formatBDT(totalSpentPoisha)}
          </p>
          <p className="text-[11px] text-slate-400">{filteredCampaigns.length} active campaigns</p>
        </div>
      </div>

      {/* Recharts Visualizations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Daily Impressions Area Chart */}
        <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[#3B82F6]" /> Daily Impressions Trend
            </h3>
            <span className="text-xs text-slate-400">Last {timeRange}</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorImp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.35} />
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#13151B',
                    borderColor: 'rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Area type="monotone" dataKey="impressions" stroke="#3B82F6" strokeWidth={2} fillOpacity={1} fill="url(#colorImp)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Engagement Growth Bar Chart */}
        <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#D4AF37]" /> Engagement Growth Trends
            </h3>
            <span className="text-xs text-slate-400">Likes, Comments & Clicks</span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} />
                <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#13151B',
                    borderColor: 'rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="engagement" name="Engagement" fill="#D4AF37" radius={[4, 4, 0, 0]} />
                <Bar dataKey="clicks" name="Clicks" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Top Performing Posts Performance Table */}
      <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4 shadow-sm">
        <h3 className="font-display font-bold text-sm text-slate-900 dark:text-white">
          Post &amp; Campaign Performance Breakdown
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-white/10 text-slate-400 font-semibold">
                <th className="pb-3 px-2">Campaign / Post</th>
                <th className="pb-3 px-2">Objective</th>
                <th className="pb-3 px-2">Impressions</th>
                <th className="pb-3 px-2">Clicks</th>
                <th className="pb-3 px-2">Spent</th>
                <th className="pb-3 px-2">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-white/5">
              {filteredCampaigns.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-6 text-center text-slate-400">
                    No active ad campaigns or performance data for this entity yet.
                  </td>
                </tr>
              ) : (
                filteredCampaigns.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-white/5">
                    <td className="py-3 px-2 font-semibold text-slate-900 dark:text-white max-w-[200px] truncate">
                      {c.title}
                    </td>
                    <td className="py-3 px-2 capitalize text-slate-500">{c.objective.replace(/_/g, ' ')}</td>
                    <td className="py-3 px-2 font-mono">{formatCompactNumber(c.paidImpressions || 0)}</td>
                    <td className="py-3 px-2 font-mono">{formatCompactNumber(c.clicks || 0)}</td>
                    <td className="py-3 px-2 font-mono">{formatBDT(c.spentPoisha || 0)}</td>
                    <td className="py-3 px-2">
                      <span
                        className={`px-2 py-0.5 rounded-full font-semibold uppercase text-[10px] ${
                          c.status === 'active'
                            ? 'bg-emerald-500/10 text-emerald-500'
                            : c.status === 'pending_review'
                            ? 'bg-amber-500/10 text-amber-500'
                            : 'bg-slate-500/10 text-slate-400'
                        }`}
                      >
                        {c.status.replace(/_/g, ' ')}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
