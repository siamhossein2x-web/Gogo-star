import React, { useEffect, useState } from 'react';
import {
  collection,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import { ArrowDownToLine, Award, Lock, ShieldCheck, Wallet } from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import {
  LedgerEntry,
  PageLedgerEntry,
  PageWallet,
  PersonalWallet,
  PublicPage,
  WithdrawalRequest,
} from '../types/hearthline';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { bdtToPoisha, formatBDT } from '../lib/finance';

interface WalletViewProps {
  onOpenPages?: () => void;
  onOpenProfile?: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({ onOpenPages, onOpenProfile }) => {
  const { firebaseUser, profile, platformSettings } = useAuth();
  const { pushToast } = useToast();

  const [personalWallet, setPersonalWallet] = useState<PersonalWallet | null>(null);
  const [ownedPages, setOwnedPages] = useState<PublicPage[]>([]);
  const [pageWallets, setPageWallets] = useState<PageWallet[]>([]);
  const [ledger, setLedger] = useState<LedgerEntry[]>([]);
  const [pageLedger, setPageLedger] = useState<PageLedgerEntry[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);

  // Withdrawal form
  const [walletSource, setWalletSource] = useState<'personal' | string>('personal');
  const [amountBdt, setAmountBdt] = useState(500);
  const [method, setMethod] = useState<'bkash' | 'nagad' | 'bank'>('bkash');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountTitle, setAccountTitle] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setAmountBdt(Math.max(100, Math.ceil(platformSettings.minWithdrawalPoisha / 100)));
  }, [platformSettings.minWithdrawalPoisha]);

  useEffect(() => {
    if (!firebaseUser) return;

    const uPersonal = onSnapshot(
      doc(db, 'wallets', firebaseUser.uid),
      (s) => setPersonalWallet(s.exists() ? (s.data() as PersonalWallet) : null),
      (err) => handleFirestoreError(err, OperationType.GET, `wallets/${firebaseUser.uid}`)
    );

    const uOwnedPages = onSnapshot(
      query(collection(db, 'pages'), where('ownerUid', '==', firebaseUser.uid)),
      (s) => setOwnedPages(s.docs.map((d) => ({ id: d.id, ...d.data() } as PublicPage))),
      (err) => handleFirestoreError(err, OperationType.LIST, 'pages')
    );

    const uPageWallets = onSnapshot(
      query(collection(db, 'pageWallets'), where('ownerUid', '==', firebaseUser.uid)),
      (s) => setPageWallets(s.docs.map((d) => ({ id: d.id, ...d.data() } as PageWallet))),
      (err) => handleFirestoreError(err, OperationType.LIST, 'pageWallets')
    );

    const uLedger = onSnapshot(
      query(collection(db, 'ledgerEntries'), where('uid', '==', firebaseUser.uid)),
      (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as LedgerEntry));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setLedger(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'ledgerEntries')
    );

    const uPageLedger = onSnapshot(
      query(collection(db, 'pageLedgerEntries'), where('ownerUid', '==', firebaseUser.uid)),
      (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as PageLedgerEntry));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setPageLedger(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'pageLedgerEntries')
    );

    const uWithdrawals = onSnapshot(
      query(collection(db, 'withdrawalRequests'), where('uid', '==', firebaseUser.uid)),
      (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setWithdrawals(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'withdrawalRequests')
    );

    return () => {
      uPersonal();
      uOwnedPages();
      uPageWallets();
      uLedger();
      uPageLedger();
      uWithdrawals();
    };
  }, [firebaseUser?.uid]);

  const minBdt = platformSettings.minWithdrawalPoisha / 100;

  const getPendingHoldForSource = (source: 'personal' | string): number =>
    withdrawals
      .filter(
        (w) =>
          w.status === 'pending' &&
          (source === 'personal' ? w.walletType === 'personal' : w.walletType === 'page' && w.pageId === source)
      )
      .reduce((sum, w) => sum + (w.amountPoisha || 0), 0);

  const selectedPageWallet =
    walletSource === 'personal'
      ? null
      : pageWallets.find((pw) => pw.pageId === walletSource) || null;

  const rawAvailableForSelected =
    walletSource === 'personal'
      ? personalWallet?.availablePoisha || 0
      : selectedPageWallet?.availablePoisha || 0;

  const pendingHoldSelected = getPendingHoldForSource(walletSource);
  const availableForSelected = Math.max(0, rawAvailableForSelected - pendingHoldSelected);

  const handleRequestWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email first.', 'error');
      return;
    }
    const reqPoisha = bdtToPoisha(amountBdt);
    if (reqPoisha < platformSettings.minWithdrawalPoisha) {
      pushToast(`Minimum withdrawal is ${formatBDT(platformSettings.minWithdrawalPoisha)}.`, 'error');
      return;
    }
    if (reqPoisha > availableForSelected) {
      pushToast(
        'Insufficient withdrawable balance after accounting for pending withdrawal requests.',
        'error'
      );
      return;
    }
    if (accountNumber.trim().length < 4 || accountTitle.trim().length < 2) {
      pushToast('Enter a valid payout account number and account holder name.', 'error');
      return;
    }

    setBusy(true);
    const reqId = makeSafeId('wd');
    const trimmedAccount = accountNumber.trim();
    const masked =
      trimmedAccount.length > 4
        ? `${'*'.repeat(Math.max(2, trimmedAccount.length - 4))}${trimmedAccount.slice(-4)}`
        : trimmedAccount;

    try {
      await setDoc(doc(db, 'withdrawalRequests', reqId), {
        uid: firebaseUser.uid,
        walletType: walletSource === 'personal' ? 'personal' : 'page',
        ...(walletSource !== 'personal' ? { pageId: walletSource } : {}),
        amountPoisha: reqPoisha,
        method,
        accountNumberMasked: masked,
        accountTitle: accountTitle.trim().slice(0, 100),
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setAccountNumber('');
      setAccountTitle('');
      pushToast('Withdrawal request submitted for Admin payout verification.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `withdrawalRequests/${reqId}`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="font-display text-xl font-bold flex items-center gap-2">
          <Wallet className="w-5 h-5 text-[#D4AF37]" />
          Wallet &amp; Payouts (BDT ৳)
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Integer poisha double-entry ledger. Personal Creator Wallet and Owner-Only Page Wallets remain strictly separated.
        </p>
      </div>

      {/* Personal Creator Wallet */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-[#D4AF37]" />
            <h2 className="font-display font-bold text-sm">Personal Creator Wallet</h2>
          </div>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="text-slate-500 capitalize">
              Creator Status:{' '}
              <strong className="text-[#D4AF37]">
                {(profile?.creatorMonetizationStatus || 'not_eligible').replace('_', ' ')}
              </strong>
            </span>
            {onOpenProfile && (
              <button
                type="button"
                onClick={onOpenProfile}
                className="text-[#3B82F6] font-semibold hover:underline cursor-pointer"
              >
                Eligibility &amp; Settings
              </button>
            )}
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
          <div>
            <p className="text-slate-500">Pending</p>
            <p className="font-mono tabular-nums font-bold text-base mt-0.5">
              {formatBDT(personalWallet?.pendingPoisha || 0)}
            </p>
          </div>
          <div>
            <p className="text-slate-500">Available</p>
            <p className="font-mono tabular-nums font-bold text-base text-emerald-500 mt-0.5">
              {formatBDT(personalWallet?.availablePoisha || 0)}
            </p>
          </div>
          <div>
            <p className="text-slate-500">Processing</p>
            <p className="font-mono tabular-nums font-bold text-base text-[#3B82F6] mt-0.5">
              {formatBDT(personalWallet?.processingPoisha || 0)}
            </p>
          </div>
          <div>
            <p className="text-slate-500">Paid</p>
            <p className="font-mono tabular-nums font-bold text-base mt-0.5">
              {formatBDT(personalWallet?.paidPoisha || 0)}
            </p>
          </div>
          <div>
            <p className="text-slate-500">Reversed</p>
            <p className="font-mono tabular-nums font-bold text-base text-rose-500 mt-0.5">
              {formatBDT(personalWallet?.reversedPoisha || 0)}
            </p>
          </div>
        </div>
      </div>

      {/* Page Owner 40% Wallets */}
      <div className="rounded-2xl border border-[#D4AF37]/30 bg-white dark:bg-[#13151B] p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display font-bold text-sm flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#D4AF37]" />
            Page Owner Earnings Wallets (40% Share)
          </h2>
          <div className="flex items-center gap-3 text-[11px]">
            <span className="text-[#D4AF37] font-medium">Owner-Only Access</span>
            {onOpenPages && (
              <button
                type="button"
                onClick={onOpenPages}
                className="text-[#3B82F6] font-semibold hover:underline cursor-pointer"
              >
                Manage Pages
              </button>
            )}
          </div>
        </div>
        {pageWallets.length === 0 ? (
          <p className="text-xs text-slate-500">
            You do not own any Public Pages yet. Only verified Page Owners hold Page Earnings Wallets.
          </p>
        ) : (
          <div className="space-y-3">
            {pageWallets.map((pw) => {
              const pg = ownedPages.find((p) => p.id === pw.pageId);
              const pendingReq = getPendingHoldForSource(pw.pageId);
              return (
                <div
                  key={pw.pageId}
                  className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-4 flex flex-wrap items-center justify-between gap-4 text-xs"
                >
                  <div>
                    <p className="font-semibold text-sm text-slate-900 dark:text-white">
                      {pg?.name || pw.pageId}
                    </p>
                    <p className="text-slate-500 mt-0.5">
                      Lifetime Owner 40%:{' '}
                      <span className="font-mono tabular-nums text-[#D4AF37]">
                        {formatBDT(pw.totalOwner40Poisha)}
                      </span>{' '}
                      · Platform 60%:{' '}
                      <span className="font-mono tabular-nums">
                        {formatBDT(pw.totalPlatform60Poisha)}
                      </span>
                    </p>
                  </div>
                  <div className="flex items-center gap-5 font-mono tabular-nums">
                    <div>
                      <span className="block text-[10px] text-slate-500 font-sans">Available</span>
                      <span className="font-bold text-emerald-500">
                        {formatBDT(pw.availablePoisha)}
                      </span>
                    </div>
                    {pendingReq > 0 && (
                      <div>
                        <span className="block text-[10px] text-amber-500 font-sans">
                          Pending Req
                        </span>
                        <span className="font-bold text-amber-500">{formatBDT(pendingReq)}</span>
                      </div>
                    )}
                    <div>
                      <span className="block text-[10px] text-slate-500 font-sans">Processing</span>
                      <span className="font-bold text-[#3B82F6]">
                        {formatBDT(pw.processingPoisha)}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[10px] text-slate-500 font-sans">Paid</span>
                      <span className="font-bold">{formatBDT(pw.paidPoisha)}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Withdrawal Form */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h2 className="font-display font-bold text-base flex items-center gap-2">
              <ArrowDownToLine className="w-4 h-4 text-[#D4AF37]" />
              Request Withdrawal
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Minimum withdrawal: <span className="font-mono">{formatBDT(platformSettings.minWithdrawalPoisha)}</span>. Net withdrawable right now:{' '}
              <strong className="font-mono tabular-nums text-emerald-500">
                {formatBDT(availableForSelected)}
              </strong>
              {pendingHoldSelected > 0 && (
                <> (holding <span className="font-mono">{formatBDT(pendingHoldSelected)}</span> in pending requests)</>
              )}
              .
            </p>
          </div>
          <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
        </div>

        <form onSubmit={handleRequestWithdrawal} className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="block text-slate-500 mb-1">Source Wallet</label>
            <select
              value={walletSource}
              onChange={(e) => setWalletSource(e.target.value)}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
            >
              <option value="personal">
                Personal Wallet ({formatBDT(Math.max(0, (personalWallet?.availablePoisha || 0) - getPendingHoldForSource('personal')))})
              </option>
              {pageWallets.map((pw) => {
                const pg = ownedPages.find((p) => p.id === pw.pageId);
                const netAvail = Math.max(0, pw.availablePoisha - getPendingHoldForSource(pw.pageId));
                return (
                  <option key={pw.pageId} value={pw.pageId}>
                    Page: {pg?.name || pw.pageId} ({formatBDT(netAvail)})
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Amount (BDT ৳, min {minBdt})</label>
            <input
              type="number"
              min={minBdt}
              step={1}
              value={amountBdt}
              onChange={(e) => setAmountBdt(Number(e.target.value))}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono tabular-nums"
            />
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Payout Method</label>
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value as 'bkash' | 'nagad' | 'bank')}
              className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
            >
              <option value="bkash">bKash</option>
              <option value="nagad">Nagad</option>
              <option value="bank">Bank Transfer</option>
            </select>
          </div>

          <div>
            <label className="block text-slate-500 mb-1">Account / Wallet Number</label>
            <input
              type="text"
              required
              value={accountNumber}
              onChange={(e) => setAccountNumber(e.target.value)}
              placeholder="01XXXXXXXXX or Bank A/C"
              className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-slate-500 mb-1">Account Holder Name</label>
            <input
              type="text"
              required
              value={accountTitle}
              onChange={(e) => setAccountTitle(e.target.value)}
              placeholder="Full legal account holder name"
              className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
            />
          </div>

          <div className="sm:col-span-2">
            <button
              type="submit"
              disabled={busy || availableForSelected < platformSettings.minWithdrawalPoisha}
              className="w-full sm:w-auto px-6 h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold disabled:opacity-45 cursor-pointer"
            >
              {busy ? 'Submitting...' : 'Submit Withdrawal Request'}
            </button>
          </div>
        </form>
      </div>

      {/* Withdrawal History & Personal Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
          <h3 className="font-display font-semibold text-sm">Withdrawal Requests</h3>
          {withdrawals.length === 0 ? (
            <p className="text-xs text-slate-500">No withdrawal requests yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-white/5 text-xs">
              {withdrawals.map((w) => {
                const pg = w.pageId ? ownedPages.find((p) => p.id === w.pageId) : undefined;
                return (
                  <div key={w.id} className="py-2.5 flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-semibold capitalize truncate">
                        {w.method} · {w.accountNumberMasked} · {w.accountTitle}
                      </p>
                      <p className="text-slate-500 capitalize">
                        {w.walletType === 'page'
                          ? `Page: ${pg?.name || w.pageId}`
                          : 'Personal Wallet'}{' '}
                        · <strong className="text-[#D4AF37]">{w.status}</strong>
                        {w.createdAt?.toDate
                          ? ` · ${w.createdAt.toDate().toLocaleDateString()}`
                          : ''}
                      </p>
                      {w.adminNote && (
                        <p className="text-[11px] text-slate-400 mt-0.5">{w.adminNote}</p>
                      )}
                    </div>
                    <span className="font-mono tabular-nums font-bold shrink-0">
                      {formatBDT(w.amountPoisha)}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
          <h3 className="font-display font-semibold text-sm">Personal Ledger History</h3>
          {ledger.length === 0 ? (
            <p className="text-xs text-slate-500">No personal ledger entries yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-white/5 text-xs">
              {ledger.map((l) => (
                <div key={l.id} className="py-2.5 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold capitalize">{l.source.replace(/_/g, ' ')}</p>
                    <p className="text-slate-500 truncate">{l.note || l.referenceId}</p>
                  </div>
                  <span
                    className={`font-mono tabular-nums font-bold shrink-0 ${
                      l.direction === 'credit' ? 'text-emerald-500' : 'text-rose-500'
                    }`}
                  >
                    {l.direction === 'credit' ? '+' : '-'}
                    {formatBDT(l.amountPoisha)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Immutable Page 40/60 Revenue & Payout Ledger */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-semibold text-sm">
            Page Owner 40/60 Settlement &amp; Payout Ledger
          </h3>
          <span className="text-[11px] text-slate-500">Immutable Record</span>
        </div>
        {pageLedger.length === 0 ? (
          <p className="text-xs text-slate-500">
            No Page 40/60 revenue settlements or Page withdrawals recorded yet.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="text-slate-500 border-b border-slate-200 dark:border-white/10">
                <tr>
                  <th className="py-2 pr-3">Page</th>
                  <th className="py-2 pr-3">Event</th>
                  <th className="py-2 pr-3 text-right">Gross</th>
                  <th className="py-2 pr-3 text-right">Deductions</th>
                  <th className="py-2 pr-3 text-right">Eligible Net</th>
                  <th className="py-2 pr-3 text-right text-[#D4AF37]">Owner 40%</th>
                  <th className="py-2 text-right">Platform 60%</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-white/5 font-mono tabular-nums">
                {pageLedger.map((entry) => {
                  const pg = ownedPages.find((p) => p.id === entry.pageId);
                  return (
                    <tr key={entry.id}>
                      <td className="py-2.5 pr-3 font-sans font-medium">
                        {pg?.name || entry.pageId}
                      </td>
                      <td className="py-2.5 pr-3 font-sans capitalize">
                        {entry.eventType.replace(/_/g, ' ')}
                      </td>
                      <td className="py-2.5 pr-3 text-right">{formatBDT(entry.grossPoisha)}</td>
                      <td className="py-2.5 pr-3 text-right">{formatBDT(entry.deductionsPoisha)}</td>
                      <td className="py-2.5 pr-3 text-right">{formatBDT(entry.eligibleNetPoisha)}</td>
                      <td className="py-2.5 pr-3 text-right text-[#D4AF37] font-semibold">
                        {formatBDT(entry.ownerShare40Poisha)}
                      </td>
                      <td className="py-2.5 text-right">{formatBDT(entry.platformShare60Poisha)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
