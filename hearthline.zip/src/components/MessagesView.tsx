import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  arrayRemove,
  arrayUnion,
  collection,
  deleteDoc,
  doc,
  getDoc,
  increment,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  Ban,
  Check,
  CheckCheck,
  ChevronLeft,
  Edit3,
  FileText,
  Flag,
  Image as ImageIcon,
  LogOut,
  MessageCircle,
  Plus,
  Reply,
  Search,
  Send,
  Shield,
  ShieldOff,
  Trash2,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import { ChatMessage, Conversation, ConversationMember, UserProfile } from '../types/hearthline';
import { useAuth, createNotification } from '../context/AuthContext';
import { useToast } from './Toast';
import { Avatar } from './Avatar';
import { MediaUploadInput } from './MediaUploadInput';
import {
  blockUser,
  openOrCreateDirectConversation,
  submitReport,
  unblockUser,
} from '../lib/socialActions';
import { sanitizeExternalUrl } from '../lib/url';

interface MessagesViewProps {
  initialConvId?: string;
  onOpenProfile?: (uid: string) => void;
}

function formatChatTime(ts?: { toDate?: () => Date }): string {
  if (!ts?.toDate) return '';
  const d = ts.toDate();
  const now = new Date();
  const sameDay =
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate();
  if (sameDay) return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

export const MessagesView: React.FC<MessagesViewProps> = ({ initialConvId, onOpenProfile }) => {
  const { firebaseUser, profile } = useAuth();
  const { pushToast } = useToast();

  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [myMemberStates, setMyMemberStates] = useState<Record<string, ConversationMember>>({});
  const [selectedConvId, setSelectedConvId] = useState<string | null>(initialConvId || null);
  const [convFilter, setConvFilter] = useState<'all' | 'direct' | 'group'>('all');
  const [convSearch, setConvSearch] = useState('');
  const [showMsgSearch, setShowMsgSearch] = useState(false);
  const [msgSearch, setMsgSearch] = useState('');

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [members, setMembers] = useState<ConversationMember[]>([]);
  const [usersMap, setUsersMap] = useState<Record<string, UserProfile>>({});

  // Separate friendsA & friendsB so real-time unfriending removes immediately
  const [friendsA, setFriendsA] = useState<string[]>([]);
  const [friendsB, setFriendsB] = useState<string[]>([]);
  const [friendsLoaded, setFriendsLoaded] = useState(false);
  const [blockedUids, setBlockedUids] = useState<Set<string>>(new Set());

  const [msgText, setMsgText] = useState('');
  const [attachmentUrl, setAttachmentUrl] = useState('');
  const [attachmentType, setAttachmentType] = useState<'none' | 'image' | 'video' | 'file'>('none');
  const [showAttachmentBox, setShowAttachmentBox] = useState(false);
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [editingMsgId, setEditingMsgId] = useState<string | null>(null);
  const [editingMsgText, setEditingMsgText] = useState('');
  const [sending, setSending] = useState(false);

  // Modals & Group management
  const [showNewChatModal, setShowNewChatModal] = useState(false);
  const [newChatSearch, setNewChatSearch] = useState('');
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [groupName, setGroupName] = useState('');
  const [groupPhoto, setGroupPhoto] = useState('');
  const [selectedFriendUids, setSelectedFriendUids] = useState<Set<string>>(new Set());

  const [showGroupInfo, setShowGroupInfo] = useState(false);
  const [editGroupName, setEditGroupName] = useState('');
  const [editGroupPhoto, setEditGroupPhoto] = useState('');

  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (initialConvId) setSelectedConvId(initialConvId);
  }, [initialConvId]);

  const friendUids = useMemo(() => new Set([...friendsA, ...friendsB]), [friendsA, friendsB]);

  const hydrateUsers = async (uids: string[]) => {
    const missing = uids.filter((u) => u && !usersMap[u]);
    if (missing.length === 0) return;
    const loaded: Record<string, UserProfile> = {};
    await Promise.all(
      missing.map(async (u) => {
        try {
          const s = await getDoc(doc(db, 'users', u));
          if (s.exists()) loaded[u] = s.data() as UserProfile;
        } catch {
          // ignore unavailable profile
        }
      })
    );
    if (Object.keys(loaded).length > 0) {
      setUsersMap((prev) => ({ ...prev, ...loaded }));
    }
  };

  // Load user's conversations, member unread states, confirmed friends, and blocked users
  useEffect(() => {
    if (!firebaseUser) return;

    const memberUnsubs = new Map<string, () => void>();

    const unsubConvs = onSnapshot(
      query(
        collection(db, 'conversations'),
        where('participantUids', 'array-contains', firebaseUser.uid)
      ),
      async (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...d.data() } as Conversation))
          .sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));
        setConversations(list);

        const activeIds = new Set(list.map((c) => c.id));
        Array.from(memberUnsubs.keys()).forEach((cid) => {
          if (!activeIds.has(cid)) {
            memberUnsubs.get(cid)?.();
            memberUnsubs.delete(cid);
          }
        });

        list.forEach((c) => {
          if (!memberUnsubs.has(c.id)) {
            const unsubM = onSnapshot(
              doc(db, 'conversations', c.id, 'members', firebaseUser.uid),
              (mSnap) => {
                if (mSnap.exists()) {
                  setMyMemberStates((prev) => ({
                    ...prev,
                    [c.id]: mSnap.data() as ConversationMember,
                  }));
                }
              },
              () => {}
            );
            memberUnsubs.set(c.id, unsubM);
          }
        });

        await hydrateUsers(Array.from(new Set(list.flatMap((c) => c.participantUids))));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'conversations')
    );

    let gotA = false;
    let gotB = false;

    const unsubFriendsA = onSnapshot(
      query(collection(db, 'friendships'), where('userA', '==', firebaseUser.uid)),
      (s) => {
        const list = s.docs.map((d) => d.data().userB as string);
        setFriendsA(list);
        gotA = true;
        if (gotA && gotB) setFriendsLoaded(true);
        hydrateUsers(list);
      },
      () => {}
    );

    const unsubFriendsB = onSnapshot(
      query(collection(db, 'friendships'), where('userB', '==', firebaseUser.uid)),
      (s) => {
        const list = s.docs.map((d) => d.data().userA as string);
        setFriendsB(list);
        gotB = true;
        if (gotA && gotB) setFriendsLoaded(true);
        hydrateUsers(list);
      },
      () => {}
    );

    const unsubBlocked = onSnapshot(
      query(collection(db, 'blockedUsers'), where('blockerUid', '==', firebaseUser.uid)),
      (s) => setBlockedUids(new Set(s.docs.map((d) => d.data().blockedUid as string))),
      () => {}
    );

    return () => {
      unsubConvs();
      memberUnsubs.forEach((fn) => fn());
      memberUnsubs.clear();
      unsubFriendsA();
      unsubFriendsB();
      unsubBlocked();
    };
  }, [firebaseUser?.uid]);

  const friends = useMemo(() => {
    return Array.from(friendUids)
      .map((u) => usersMap[u])
      .filter((u): u is UserProfile => Boolean(u))
      .sort((a, b) => a.displayName.localeCompare(b.displayName));
  }, [friendUids, usersMap]);

  // Listen to messages & members for active conversation
  useEffect(() => {
    if (!selectedConvId || !firebaseUser) {
      setMessages([]);
      setMembers([]);
      return;
    }

    setShowGroupInfo(false);
    setShowMsgSearch(false);
    setMsgSearch('');
    setReplyTo(null);
    setEditingMsgId(null);

    const markConversationRead = () => {
      if (!firebaseUser.emailVerified) return;
      updateDoc(doc(db, 'conversations', selectedConvId, 'members', firebaseUser.uid), {
        unreadCount: 0,
        lastReadAt: serverTimestamp(),
      }).catch(() => {});
    };

    const unsubMsgs = onSnapshot(
      query(collection(db, 'conversations', selectedConvId, 'messages'), orderBy('createdAt', 'asc')),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as ChatMessage));
        setMessages(list);
        const latest = list[list.length - 1];
        if (latest && latest.senderUid !== firebaseUser.uid) {
          markConversationRead();
        }
        setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 60);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `conversations/${selectedConvId}/messages`)
    );

    const unsubMembers = onSnapshot(
      collection(db, 'conversations', selectedConvId, 'members'),
      (snap) => {
        setMembers(snap.docs.map((d) => d.data() as ConversationMember));
      },
      () => {}
    );

    markConversationRead();

    return () => {
      unsubMsgs();
      unsubMembers();
    };
  }, [selectedConvId, firebaseUser?.uid]);

  const activeConv = conversations.find((c) => c.id === selectedConvId) || null;

  useEffect(() => {
    if (activeConv?.type === 'group') {
      setEditGroupName(activeConv.groupName || '');
      setEditGroupPhoto(activeConv.groupPhoto || '');
    }
  }, [activeConv?.id, activeConv?.groupName, activeConv?.groupPhoto]);

  const isGroupAdmin = Boolean(
    activeConv?.type === 'group' &&
      firebaseUser &&
      activeConv.adminUids?.includes(firebaseUser.uid)
  );

  const directOtherUid =
    activeConv?.type === 'direct'
      ? activeConv.participantUids.find((u) => u !== firebaseUser?.uid) || ''
      : '';
  const isDirectBlocked = Boolean(directOtherUid && blockedUids.has(directOtherUid));
  const isDirectFriend = Boolean(directOtherUid && friendUids.has(directOtherUid));
  const canSendInActiveConv =
    Boolean(activeConv) &&
    (activeConv?.type === 'group' || (!isDirectBlocked && (!friendsLoaded || isDirectFriend)));

  const getConvTitle = (c: Conversation) => {
    if (c.type === 'group') return c.groupName || 'Group Chat';
    const otherUid = c.participantUids.find((u) => u !== firebaseUser?.uid) || '';
    return usersMap[otherUid]?.displayName || 'Friend';
  };

  const getConvAvatar = (c: Conversation) => {
    if (c.type === 'group') return c.groupPhoto;
    const otherUid = c.participantUids.find((u) => u !== firebaseUser?.uid) || '';
    return usersMap[otherUid]?.photoUrl;
  };

  const handleOpenFriendChat = async (friendUid: string) => {
    if (!firebaseUser) return;
    try {
      const cid = await openOrCreateDirectConversation(firebaseUser.uid, friendUid);
      setSelectedConvId(cid);
      setShowNewChatModal(false);
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Unable to open chat.', 'error');
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (
      sending ||
      !firebaseUser?.emailVerified ||
      !selectedConvId ||
      !canSendInActiveConv ||
      (!msgText.trim() && !attachmentUrl)
    ) {
      if (!firebaseUser?.emailVerified) {
        pushToast('Verify your email to send messages.', 'error');
      }
      return;
    }

    const msgId = makeSafeId('msg');
    const cleanText = msgText.trim().slice(0, 4000);
    const preview =
      cleanText ||
      (attachmentType === 'image'
        ? 'Sent a photo'
        : attachmentType === 'video'
        ? 'Sent a video'
        : 'Sent an attachment');
    const replySummary = replyTo
      ? (
          replyTo.text ||
          (replyTo.mediaType === 'image'
            ? 'Photo'
            : replyTo.mediaType === 'video'
            ? 'Video'
            : 'Attachment')
        ).slice(0, 160)
      : '';

    setSending(true);
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'conversations', selectedConvId, 'messages', msgId), {
        senderUid: firebaseUser.uid,
        text: cleanText,
        mediaUrl: attachmentUrl,
        mediaType: attachmentUrl ? attachmentType : 'none',
        replyToId: replyTo?.id || '',
        replyPreview: replySummary,
        deleted: false,
        createdAt: serverTimestamp(),
      });

      batch.update(doc(db, 'conversations', selectedConvId), {
        lastMessageText: preview.slice(0, 300),
        lastMessageSenderUid: firebaseUser.uid,
        lastMessageAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      members.forEach((mem) => {
        const memRef = doc(db, 'conversations', selectedConvId, 'members', mem.uid);
        if (mem.uid === firebaseUser.uid) {
          batch.update(memRef, { unreadCount: 0, lastReadAt: serverTimestamp() });
        } else {
          batch.update(memRef, { unreadCount: increment(1) });
        }
      });

      await batch.commit();

      if (activeConv) {
        const recipients = activeConv.participantUids.filter((u) => u !== firebaseUser.uid);
        recipients.slice(0, 10).forEach((rUid) => {
          createNotification({
            recipientUid: rUid,
            actorUid: firebaseUser.uid,
            type: activeConv.type === 'group' ? 'group_message' : 'direct_message',
            title:
              activeConv.type === 'group'
                ? `${activeConv.groupName || 'Group'} · ${profile?.displayName || 'Member'}`
                : profile?.displayName || 'New Message',
            body: preview.slice(0, 120),
            targetTab: 'messages',
          });
        });
      }

      setMsgText('');
      setAttachmentUrl('');
      setAttachmentType('none');
      setShowAttachmentBox(false);
      setReplyTo(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `conversations/${selectedConvId}/messages/${msgId}`);
    } finally {
      setSending(false);
    }
  };

  const handleSaveEditMessage = async (m: ChatMessage) => {
    if (!activeConv || !firebaseUser?.emailVerified) return;
    const clean = editingMsgText.trim().slice(0, 4000);
    if (!clean) {
      pushToast('Message cannot be empty.', 'error');
      return;
    }
    try {
      await updateDoc(doc(db, 'conversations', activeConv.id, 'messages', m.id), { text: clean });
      setEditingMsgId(null);
      setEditingMsgText('');
      pushToast('Message updated.', 'success');
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.UPDATE,
        `conversations/${activeConv.id}/messages/${m.id}`
      );
    }
  };

  const handleDeleteMessage = async (m: ChatMessage) => {
    if (!activeConv || !firebaseUser?.emailVerified) return;
    try {
      await updateDoc(doc(db, 'conversations', activeConv.id, 'messages', m.id), {
        deleted: true,
        text: '',
      });
    } catch (err) {
      handleFirestoreError(
        err,
        OperationType.UPDATE,
        `conversations/${activeConv.id}/messages/${m.id}`
      );
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser?.emailVerified || !groupName.trim() || selectedFriendUids.size === 0) {
      pushToast('Provide a group name and select at least one confirmed friend.', 'error');
      return;
    }

    const convId = makeSafeId('grp');
    const allParticipants = Array.from(
      new Set([firebaseUser.uid, ...Array.from(selectedFriendUids)])
    );
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'conversations', convId), {
        type: 'group',
        participantUids: allParticipants,
        adminUids: [firebaseUser.uid],
        groupName: groupName.trim().slice(0, 100),
        groupPhoto: groupPhoto.trim().slice(0, 1024),
        lastMessageText: 'Group created',
        lastMessageSenderUid: firebaseUser.uid,
        lastMessageAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      allParticipants.forEach((uid) => {
        batch.set(doc(db, 'conversations', convId, 'members', uid), {
          uid,
          role: uid === firebaseUser.uid ? 'admin' : 'member',
          unreadCount: 0,
          joinedAt: serverTimestamp(),
        });
      });

      await batch.commit();

      allParticipants
        .filter((u) => u !== firebaseUser.uid)
        .slice(0, 10)
        .forEach((rUid) => {
          createNotification({
            recipientUid: rUid,
            actorUid: firebaseUser.uid,
            type: 'group_message',
            title: `Added to ${groupName.trim().slice(0, 60)}`,
            body: `${profile?.displayName || 'Someone'} created a group chat with you.`,
            targetTab: 'messages',
          });
        });

      setSelectedConvId(convId);
      setShowGroupModal(false);
      setGroupName('');
      setGroupPhoto('');
      setSelectedFriendUids(new Set());
      pushToast('Group chat created!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `conversations/${convId}`);
    }
  };

  const handleUpdateGroupDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeConv || !isGroupAdmin || !editGroupName.trim()) return;
    try {
      await updateDoc(doc(db, 'conversations', activeConv.id), {
        groupName: editGroupName.trim().slice(0, 100),
        groupPhoto: editGroupPhoto.trim().slice(0, 1024),
        updatedAt: serverTimestamp(),
      });
      pushToast('Group details updated.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `conversations/${activeConv.id}`);
    }
  };

  const handleToggleMemberAdmin = async (targetUid: string, currentRole: 'admin' | 'member') => {
    if (!activeConv || !isGroupAdmin || targetUid === firebaseUser?.uid) return;
    const currentAdmins = activeConv.adminUids || [];
    if (currentRole === 'admin' && currentAdmins.length <= 1) {
      pushToast('Group must have at least one admin.', 'error');
      return;
    }
    const nextRole = currentRole === 'admin' ? 'member' : 'admin';
    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'conversations', activeConv.id), {
        adminUids: nextRole === 'admin' ? arrayUnion(targetUid) : arrayRemove(targetUid),
        updatedAt: serverTimestamp(),
      });
      batch.update(doc(db, 'conversations', activeConv.id, 'members', targetUid), {
        role: nextRole,
      });
      await batch.commit();
      pushToast(
        nextRole === 'admin' ? 'Member promoted to Group Admin.' : 'Admin role removed.',
        'info'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `conversations/${activeConv.id}`);
    }
  };

  const handleLeaveGroup = async () => {
    if (!activeConv || activeConv.type !== 'group' || !firebaseUser) return;
    const remaining = activeConv.participantUids.filter((u) => u !== firebaseUser.uid);

    try {
      if (remaining.length === 0) {
        await deleteDoc(doc(db, 'conversations', activeConv.id, 'members', firebaseUser.uid));
        await deleteDoc(doc(db, 'conversations', activeConv.id));
      } else {
        const currentAdmins = activeConv.adminUids || [];
        const remainingAdmins = currentAdmins.filter((u) => u !== firebaseUser.uid);
        const batch = writeBatch(db);

        if (isGroupAdmin && remainingAdmins.length === 0) {
          const nextAdminUid = remaining[0];
          batch.update(doc(db, 'conversations', activeConv.id), {
            participantUids: remaining,
            adminUids: [nextAdminUid],
            updatedAt: serverTimestamp(),
          });
          batch.update(doc(db, 'conversations', activeConv.id, 'members', nextAdminUid), {
            role: 'admin',
          });
        } else {
          batch.update(doc(db, 'conversations', activeConv.id), {
            participantUids: remaining,
            ...(isGroupAdmin ? { adminUids: remainingAdmins } : {}),
            updatedAt: serverTimestamp(),
          });
        }

        batch.delete(doc(db, 'conversations', activeConv.id, 'members', firebaseUser.uid));
        await batch.commit();
      }
      setSelectedConvId(null);
      setShowGroupInfo(false);
      pushToast('You left the group.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `conversations/${activeConv.id}`);
    }
  };

  const handleRemoveGroupMember = async (targetUid: string) => {
    if (!activeConv || !isGroupAdmin) return;
    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'conversations', activeConv.id), {
        participantUids: arrayRemove(targetUid),
        adminUids: arrayRemove(targetUid),
        updatedAt: serverTimestamp(),
      });
      batch.delete(doc(db, 'conversations', activeConv.id, 'members', targetUid));
      await batch.commit();
      pushToast('Member removed from group.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `conversations/${activeConv.id}`);
    }
  };

  const handleAddGroupMember = async (targetUid: string) => {
    if (!activeConv || !isGroupAdmin) return;
    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'conversations', activeConv.id), {
        participantUids: arrayUnion(targetUid),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'conversations', activeConv.id, 'members', targetUid), {
        uid: targetUid,
        role: 'member',
        unreadCount: 0,
        joinedAt: serverTimestamp(),
      });
      await batch.commit();
      await createNotification({
        recipientUid: targetUid,
        actorUid: firebaseUser!.uid,
        type: 'group_message',
        title: `Added to ${activeConv.groupName || 'Group Chat'}`,
        body: `${profile?.displayName || 'Someone'} added you to a group chat.`,
        targetTab: 'messages',
      });
      pushToast('Member added!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `conversations/${activeConv.id}`);
    }
  };

  const filteredConvs = useMemo(() => {
    return conversations.filter((c) => {
      if (convFilter === 'direct' && c.type !== 'direct') return false;
      if (convFilter === 'group' && c.type !== 'group') return false;
      if (convSearch.trim()) {
        return getConvTitle(c).toLowerCase().includes(convSearch.trim().toLowerCase());
      }
      return true;
    });
  }, [conversations, convFilter, convSearch, usersMap, firebaseUser?.uid]);

  const displayedMessages = useMemo(() => {
    const q = msgSearch.trim().toLowerCase();
    if (!q) return messages;
    return messages.filter((m) => !m.deleted && m.text.toLowerCase().includes(q));
  }, [messages, msgSearch]);

  const getReadReceiptLabel = (m: ChatMessage): { seen: boolean; label: string } => {
    const msgMs = m.createdAt?.toMillis?.() || 0;
    if (!msgMs) return { seen: false, label: 'Sent' };
    const others = members.filter((mem) => mem.uid !== firebaseUser?.uid);
    const readers = others.filter((mem) => (mem.lastReadAt?.toMillis?.() || 0) >= msgMs);
    if (readers.length === 0) return { seen: false, label: 'Sent' };
    if (activeConv?.type === 'direct') return { seen: true, label: 'Seen' };
    return { seen: true, label: `Seen by ${readers.length}` };
  };

  const filteredFriendsForNewChat = useMemo(() => {
    const q = newChatSearch.trim().toLowerCase();
    if (!q) return friends;
    return friends.filter(
      (f) =>
        f.displayName.toLowerCase().includes(q) || f.username.toLowerCase().includes(q)
    );
  }, [friends, newChatSearch]);

  return (
    <div className="max-w-5xl mx-auto h-[calc(100vh-8.5rem)] lg:h-[calc(100vh-5.5rem)] rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] overflow-hidden grid grid-cols-1 md:grid-cols-12">
      {/* Conversations List */}
      <div
        className={`md:col-span-4 border-r border-slate-200 dark:border-white/10 flex flex-col min-h-0 ${
          selectedConvId ? 'hidden md:flex' : 'flex'
        }`}
      >
        <div className="p-4 border-b border-slate-200 dark:border-white/10 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
              Messages
            </h2>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setShowNewChatModal(true)}
                className="min-h-[36px] inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-200 text-xs font-semibold hover:border-[#D4AF37] cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-3.5 h-3.5 text-[#D4AF37]" />
                Chat
              </button>
              <button
                type="button"
                onClick={() => setShowGroupModal(true)}
                className="min-h-[36px] inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer whitespace-nowrap"
              >
                <Users className="w-3.5 h-3.5" />
                Group
              </button>
            </div>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="search"
              value={convSearch}
              onChange={(e) => setConvSearch(e.target.value)}
              placeholder="Search conversations..."
              className="w-full h-9 pl-8 pr-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#D4AF37]"
            />
          </div>

          <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#0A0B0E] border border-slate-200 dark:border-white/10">
            {[
              { id: 'all', label: 'All' },
              { id: 'direct', label: 'Direct' },
              { id: 'group', label: 'Groups' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setConvFilter(tab.id as typeof convFilter)}
                className={`flex-1 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  convFilter === tab.id
                    ? 'bg-white dark:bg-[#D4AF37] text-slate-900 dark:text-[#0A0B0E] shadow-sm'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Confirmed Friends Quick-Start Bar */}
        {friends.length > 0 && (
          <div className="px-4 py-2.5 border-b border-slate-200 dark:border-white/10 flex items-center gap-2.5 overflow-x-auto">
            {friends.map((fr) => (
              <button
                key={fr.uid}
                type="button"
                onClick={() => handleOpenFriendChat(fr.uid)}
                className="shrink-0 flex flex-col items-center gap-1 w-14 cursor-pointer"
                title={`Message ${fr.displayName}`}
              >
                <Avatar src={fr.photoUrl} name={fr.displayName} size="sm" />
                <span className="text-[10px] text-slate-600 dark:text-slate-300 truncate w-full text-center">
                  {fr.displayName.split(' ')[0]}
                </span>
              </button>
            ))}
          </div>
        )}

        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-white/5">
          {filteredConvs.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500 space-y-2">
              <MessageCircle className="w-7 h-7 text-slate-400 mx-auto" />
              <p>No conversations yet. Accept a friend request or create a group chat.</p>
            </div>
          ) : (
            filteredConvs.map((c) => {
              const active = c.id === selectedConvId;
              const unread = myMemberStates[c.id]?.unreadCount || 0;
              const timeStr = formatChatTime(c.lastMessageAt || c.updatedAt);
              const sentByMe = c.lastMessageSenderUid === firebaseUser?.uid;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedConvId(c.id)}
                  className={`w-full px-4 py-3 flex items-center gap-3 text-left transition-colors cursor-pointer ${
                    active ? 'bg-[#D4AF37]/10' : 'hover:bg-slate-50 dark:hover:bg-white/5'
                  }`}
                >
                  <Avatar src={getConvAvatar(c)} name={getConvTitle(c)} size="md" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-semibold truncate text-slate-900 dark:text-white">
                        {getConvTitle(c)}
                      </p>
                      <span className="text-[10px] text-slate-400 shrink-0 tabular-nums">
                        {timeStr}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-2 mt-0.5">
                      <p
                        className={`text-xs truncate ${
                          unread > 0
                            ? 'font-semibold text-slate-900 dark:text-white'
                            : 'text-slate-500'
                        }`}
                      >
                        {c.lastMessageText
                          ? `${sentByMe ? 'You: ' : ''}${c.lastMessageText}`
                          : 'Start the conversation'}
                      </p>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {c.type === 'group' && (
                          <span className="text-[10px] text-[#3B82F6] font-medium">Group</span>
                        )}
                        {unread > 0 && (
                          <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-[#D4AF37] text-[#0A0B0E] text-[10px] font-bold font-mono tabular-nums flex items-center justify-center">
                            {unread}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Active Chat Thread */}
      <div
        className={`md:col-span-8 flex flex-col min-h-0 ${
          !selectedConvId ? 'hidden md:flex' : 'flex'
        }`}
      >
        {!activeConv ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 space-y-3">
            <MessageCircle className="w-10 h-10 text-[#D4AF37]/70" />
            <p className="text-sm font-medium text-slate-900 dark:text-white">
              Select a conversation
            </p>
            <p className="text-xs max-w-xs">
              1-on-1 chats are unlocked automatically between confirmed friends. Create a Group Chat anytime.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowNewChatModal(true)}
                className="min-h-[40px] px-4 py-2 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-semibold text-slate-700 dark:text-slate-200 cursor-pointer"
              >
                Message a Friend
              </button>
              <button
                type="button"
                onClick={() => setShowGroupModal(true)}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
              >
                New Group Chat
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Thread Header */}
            <div className="px-4 py-3 border-b border-slate-200 dark:border-white/10 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <button
                  type="button"
                  onClick={() => setSelectedConvId(null)}
                  className="md:hidden min-w-[40px] min-h-[40px] -ml-2 rounded-xl flex items-center justify-center text-[#D4AF37] cursor-pointer"
                  aria-label="Back to conversations"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  disabled={activeConv.type !== 'direct' || !onOpenProfile || !directOtherUid}
                  onClick={() => {
                    if (activeConv.type === 'direct' && directOtherUid && onOpenProfile) {
                      onOpenProfile(directOtherUid);
                    }
                  }}
                  className={`flex items-center gap-2.5 min-w-0 text-left ${
                    activeConv.type === 'direct' && onOpenProfile ? 'cursor-pointer' : ''
                  }`}
                >
                  <Avatar src={getConvAvatar(activeConv)} name={getConvTitle(activeConv)} size="sm" />
                  <div className="min-w-0">
                    <h3 className="text-sm font-semibold truncate text-slate-900 dark:text-white">
                      {getConvTitle(activeConv)}
                    </h3>
                    <p className="text-[11px] text-slate-500 truncate">
                      {activeConv.type === 'group'
                        ? `Group · ${activeConv.participantUids.length} members`
                        : isDirectBlocked
                        ? 'Blocked'
                        : !friendsLoaded || isDirectFriend
                        ? `Confirmed Friends${
                            usersMap[directOtherUid]?.username
                              ? ` · @${usersMap[directOtherUid].username}`
                              : ''
                          }`
                        : 'Not currently friends'}
                    </p>
                  </div>
                </button>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setShowMsgSearch((s) => !s);
                    setMsgSearch('');
                  }}
                  aria-label="Search messages"
                  title="Search in conversation"
                  className={`min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center cursor-pointer ${
                    showMsgSearch
                      ? 'bg-[#D4AF37]/15 text-[#D4AF37]'
                      : 'text-slate-400 hover:text-slate-700 dark:hover:text-white'
                  }`}
                >
                  <Search className="w-4 h-4" />
                </button>

                {activeConv.type === 'group' ? (
                  <button
                    type="button"
                    onClick={() => setShowGroupInfo((s) => !s)}
                    className={`min-h-[40px] px-3 rounded-xl border text-xs font-medium cursor-pointer whitespace-nowrap ${
                      showGroupInfo
                        ? 'border-[#D4AF37] text-[#D4AF37]'
                        : 'border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    Group Info
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={async () => {
                        if (!directOtherUid || !firebaseUser) return;
                        if (isDirectBlocked) {
                          await unblockUser(firebaseUser.uid, directOtherUid);
                          pushToast('User unblocked.', 'success');
                        } else {
                          await blockUser(firebaseUser.uid, directOtherUid);
                          pushToast('User blocked.', 'info');
                        }
                      }}
                      className={`min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center cursor-pointer ${
                        isDirectBlocked
                          ? 'text-rose-500 bg-rose-500/10'
                          : 'text-slate-400 hover:text-rose-500'
                      }`}
                      title={isDirectBlocked ? 'Unblock user' : 'Block user'}
                    >
                      <Ban className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        if (!directOtherUid || !firebaseUser) return;
                        await submitReport({
                          reporterUid: firebaseUser.uid,
                          targetType: 'user',
                          targetId: directOtherUid,
                          reason: 'Messaging safety report',
                        });
                        pushToast('User reported to moderation.', 'info');
                      }}
                      className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-400 hover:text-amber-500 cursor-pointer"
                      title="Report user"
                    >
                      <Flag className="w-4 h-4" />
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* In-thread Search Bar */}
            {showMsgSearch && (
              <div className="px-4 py-2 border-b border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] flex items-center gap-2">
                <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <input
                  type="search"
                  value={msgSearch}
                  onChange={(e) => setMsgSearch(e.target.value)}
                  placeholder="Search messages in this chat..."
                  className="flex-1 bg-transparent text-xs text-slate-900 dark:text-white focus:outline-none"
                />
                {msgSearch && (
                  <button
                    type="button"
                    onClick={() => setMsgSearch('')}
                    className="text-xs text-slate-400 hover:text-white cursor-pointer"
                  >
                    Clear
                  </button>
                )}
              </div>
            )}

            {/* Group Info & Management Panel */}
            {showGroupInfo && activeConv.type === 'group' && (
              <div className="p-4 border-b border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] space-y-4 text-xs max-h-72 overflow-y-auto">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-900 dark:text-white">
                    Group Members ({activeConv.participantUids.length})
                  </span>
                  <button
                    type="button"
                    onClick={handleLeaveGroup}
                    className="min-h-[36px] inline-flex items-center gap-1 text-rose-500 hover:underline cursor-pointer font-medium"
                  >
                    <LogOut className="w-3.5 h-3.5" /> Leave Group
                  </button>
                </div>

                {isGroupAdmin && (
                  <form
                    onSubmit={handleUpdateGroupDetails}
                    className="p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] space-y-2.5"
                  >
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      Edit Group Settings
                    </p>
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        type="text"
                        required
                        value={editGroupName}
                        onChange={(e) => setEditGroupName(e.target.value)}
                        placeholder="Group Name"
                        className="flex-1 min-w-[160px] h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
                      />
                      <button
                        type="submit"
                        className="h-9 px-3.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
                      >
                        Save
                      </button>
                    </div>
                    <MediaUploadInput
                      accept="image/*"
                      mediaKind="image"
                      label="Update Group Photo"
                      value={editGroupPhoto}
                      onUploaded={(url) => setEditGroupPhoto(url)}
                    />
                  </form>
                )}

                <div className="space-y-1.5">
                  {activeConv.participantUids.map((uid) => {
                    const u = usersMap[uid];
                    const mem = members.find((m) => m.uid === uid);
                    const isMemberAdmin =
                      mem?.role === 'admin' || activeConv.adminUids?.includes(uid);
                    return (
                      <div
                        key={uid}
                        className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B]"
                      >
                        <button
                          type="button"
                          onClick={() => onOpenProfile && onOpenProfile(uid)}
                          className="flex items-center gap-2 min-w-0 cursor-pointer"
                        >
                          <Avatar src={u?.photoUrl} name={u?.displayName || uid} size="xs" />
                          <div className="text-left min-w-0">
                            <p className="font-semibold text-slate-900 dark:text-white truncate">
                              {u?.displayName || uid.slice(0, 6)}
                            </p>
                            <p className="text-[10px] text-slate-500">
                              {isMemberAdmin ? 'Group Admin' : 'Member'}
                              {uid === firebaseUser?.uid ? ' · You' : ''}
                            </p>
                          </div>
                        </button>

                        {isGroupAdmin && uid !== firebaseUser?.uid && (
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() =>
                                handleToggleMemberAdmin(uid, isMemberAdmin ? 'admin' : 'member')
                              }
                              title={isMemberAdmin ? 'Demote admin' : 'Make Group Admin'}
                              className="p-1.5 rounded-lg border border-slate-200 dark:border-white/10 text-[#3B82F6] hover:bg-[#3B82F6]/10 cursor-pointer"
                            >
                              {isMemberAdmin ? (
                                <ShieldOff className="w-3.5 h-3.5" />
                              ) : (
                                <Shield className="w-3.5 h-3.5" />
                              )}
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRemoveGroupMember(uid)}
                              title="Remove from group"
                              className="p-1.5 rounded-lg border border-slate-200 dark:border-white/10 text-rose-500 hover:bg-rose-500/10 cursor-pointer"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {isGroupAdmin && (
                  <div className="space-y-1.5 pt-1">
                    <span className="text-slate-500 font-medium">Add confirmed friend:</span>
                    <div className="flex flex-wrap items-center gap-2">
                      {friends.filter((f) => !activeConv.participantUids.includes(f.uid)).length ===
                      0 ? (
                        <span className="text-slate-400">All confirmed friends are already in this group.</span>
                      ) : (
                        friends
                          .filter((f) => !activeConv.participantUids.includes(f.uid))
                          .map((f) => (
                            <button
                              key={f.uid}
                              type="button"
                              onClick={() => handleAddGroupMember(f.uid)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#3B82F6]/15 text-[#3B82F6] font-medium cursor-pointer"
                            >
                              <UserPlus className="w-3 h-3" /> {f.displayName}
                            </button>
                          ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Message Feed */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {displayedMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-xs text-slate-500 py-10">
                  <MessageCircle className="w-7 h-7 text-slate-400 mb-2" />
                  <p>
                    {msgSearch.trim()
                      ? 'No messages match your search.'
                      : 'No messages yet. Say hello to start the conversation.'}
                  </p>
                </div>
              ) : (
                displayedMessages.map((m) => {
                  const isMine = m.senderUid === firebaseUser?.uid;
                  const sender = usersMap[m.senderUid];
                  const timeLabel = formatChatTime(m.createdAt);
                  const receipt = isMine ? getReadReceiptLabel(m) : null;
                  const isEditing = editingMsgId === m.id;

                  return (
                    <div
                      key={m.id}
                      className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                    >
                      {!isMine && activeConv.type === 'group' && (
                        <button
                          type="button"
                          onClick={() => onOpenProfile && onOpenProfile(m.senderUid)}
                          className="text-[11px] font-medium text-slate-500 hover:text-[#D4AF37] mb-0.5 px-1 cursor-pointer"
                        >
                          {sender?.displayName || 'Member'}
                        </button>
                      )}
                      <div
                        className={`group max-w-[82%] sm:max-w-[72%] rounded-2xl px-3.5 py-2.5 text-sm space-y-1.5 ${
                          isMine
                            ? 'bg-[#D4AF37] text-[#0A0B0E]'
                            : 'bg-slate-100 dark:bg-[#1B1E26] text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {m.replyPreview && !m.deleted && (
                          <div className="text-[11px] opacity-80 border-b border-current/20 pb-1">
                            Replying to: {m.replyPreview}
                          </div>
                        )}
                        {!m.deleted && m.mediaUrl && m.mediaType === 'image' && (
                          <img
                            src={m.mediaUrl}
                            alt="Message attachment"
                            referrerPolicy="no-referrer"
                            className="max-h-60 rounded-xl object-cover bg-black/10"
                          />
                        )}
                        {!m.deleted && m.mediaUrl && m.mediaType === 'video' && (
                          <video
                            src={m.mediaUrl}
                            controls
                            muted
                            className="max-h-60 rounded-xl bg-black"
                          />
                        )}
                        {!m.deleted && m.mediaUrl && m.mediaType === 'file' && (() => {
                          const safeHref =
                            sanitizeExternalUrl(m.mediaUrl) ||
                            (m.mediaUrl.startsWith('/src/assets/') ? m.mediaUrl : null);
                          return safeHref ? (
                            <a
                              href={safeHref}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1.5 underline text-xs font-medium"
                            >
                              <FileText className="w-3.5 h-3.5" /> View Attachment
                            </a>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 text-xs opacity-70">
                              <FileText className="w-3.5 h-3.5" /> Attachment blocked (unsafe URL)
                            </span>
                          );
                        })()}

                        {isEditing ? (
                          <div className="space-y-1.5 min-w-[200px]">
                            <input
                              type="text"
                              value={editingMsgText}
                              onChange={(e) => setEditingMsgText(e.target.value)}
                              className="w-full h-8 px-2.5 rounded-lg bg-white/90 text-slate-900 text-xs focus:outline-none"
                            />
                            <div className="flex items-center justify-end gap-2 text-[11px] font-semibold">
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingMsgId(null);
                                  setEditingMsgText('');
                                }}
                                className="cursor-pointer opacity-75"
                              >
                                Cancel
                              </button>
                              <button
                                type="button"
                                onClick={() => handleSaveEditMessage(m)}
                                className="inline-flex items-center gap-0.5 cursor-pointer"
                              >
                                <Check className="w-3 h-3" /> Save
                              </button>
                            </div>
                          </div>
                        ) : (
                          (m.deleted || m.text) && (
                            <p className={`break-words ${m.deleted ? 'italic opacity-65 text-xs' : ''}`}>
                              {m.deleted ? 'Message deleted' : m.text}
                            </p>
                          )
                        )}

                        <div className="flex items-center justify-end gap-1.5 text-[10px] opacity-75 tabular-nums">
                          <span>{timeLabel}</span>
                          {isMine && receipt && (
                            <span
                              className={`inline-flex items-center gap-0.5 ${
                                receipt.seen ? 'font-semibold' : 'opacity-70'
                              }`}
                              title={receipt.label}
                            >
                              <CheckCheck
                                className={`w-3.5 h-3.5 ${
                                  receipt.seen ? 'text-[#0A0B0E] dark:text-[#0A0B0E]' : ''
                                }`}
                              />
                              {receipt.seen && <span>{receipt.label}</span>}
                            </span>
                          )}
                        </div>
                      </div>

                      {!m.deleted && !isEditing && (
                        <div className="flex items-center gap-3 mt-0.5 px-1 text-[11px] text-slate-400">
                          <button
                            type="button"
                            onClick={() => setReplyTo(m)}
                            className="hover:text-[#3B82F6] inline-flex items-center gap-0.5 py-0.5 cursor-pointer"
                          >
                            <Reply className="w-3 h-3" /> Reply
                          </button>
                          {isMine && m.text && (
                            <button
                              type="button"
                              onClick={() => {
                                setEditingMsgId(m.id);
                                setEditingMsgText(m.text);
                              }}
                              className="hover:text-[#D4AF37] inline-flex items-center gap-0.5 py-0.5 cursor-pointer"
                            >
                              <Edit3 className="w-3 h-3" /> Edit
                            </button>
                          )}
                          {isMine && (
                            <button
                              type="button"
                              onClick={() => handleDeleteMessage(m)}
                              className="hover:text-rose-500 inline-flex items-center gap-0.5 py-0.5 cursor-pointer"
                            >
                              <Trash2 className="w-3 h-3" /> Delete
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
              <div ref={bottomRef} />
            </div>

            {/* Composer or Block/Unfriend Notice */}
            {!canSendInActiveConv ? (
              <div className="p-3.5 border-t border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-slate-600 dark:text-slate-300">
                  {isDirectBlocked
                    ? 'You blocked this user. Unblock them to send new messages.'
                    : 'One-to-one messaging is available only between confirmed friends.'}
                </span>
                {isDirectBlocked && directOtherUid && firebaseUser && (
                  <button
                    type="button"
                    onClick={async () => {
                      await unblockUser(firebaseUser.uid, directOtherUid);
                      pushToast('User unblocked.', 'success');
                    }}
                    className="px-3 py-1.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
                  >
                    Unblock
                  </button>
                )}
              </div>
            ) : (
              <form
                onSubmit={handleSendMessage}
                className="p-3 border-t border-slate-200 dark:border-white/10 space-y-2"
              >
                {replyTo && (
                  <div className="flex items-center justify-between text-xs bg-slate-100 dark:bg-[#0A0B0E] px-3 py-1.5 rounded-xl">
                    <span className="truncate text-slate-600 dark:text-slate-300">
                      Replying to:{' '}
                      {replyTo.text ||
                        (replyTo.mediaType === 'image'
                          ? 'Photo'
                          : replyTo.mediaType === 'video'
                          ? 'Video'
                          : 'Attachment')}
                    </span>
                    <button
                      type="button"
                      onClick={() => setReplyTo(null)}
                      aria-label="Cancel reply"
                      className="p-1 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
                {showAttachmentBox && (
                  <div className="p-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
                    <MediaUploadInput
                      accept="image/*,video/*"
                      mediaKind="auto"
                      label="Attach Image / Video"
                      value={attachmentUrl}
                      onUploaded={(url, kind) => {
                        setAttachmentUrl(url);
                        setAttachmentType(kind);
                      }}
                    />
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAttachmentBox((s) => !s)}
                    className={`w-10 h-10 rounded-xl border flex items-center justify-center cursor-pointer shrink-0 ${
                      showAttachmentBox || attachmentUrl
                        ? 'border-[#D4AF37] text-[#D4AF37]'
                        : 'border-slate-200 dark:border-white/10 text-slate-500 hover:text-[#D4AF37]'
                    }`}
                    aria-label="Attach media"
                  >
                    <ImageIcon className="w-4 h-4" />
                  </button>
                  <input
                    type="text"
                    value={msgText}
                    onChange={(e) => setMsgText(e.target.value)}
                    placeholder="Write a message..."
                    maxLength={4000}
                    className="flex-1 h-10 px-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm text-slate-900 dark:text-white focus:outline-none focus:border-[#D4AF37]"
                  />
                  <button
                    type="submit"
                    disabled={sending || (!msgText.trim() && !attachmentUrl)}
                    className="w-10 h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] flex items-center justify-center hover:bg-[#E5C158] disabled:opacity-45 cursor-pointer shrink-0"
                    aria-label="Send message"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}
          </>
        )}
      </div>

      {/* Start 1-on-1 Chat Modal */}
      {showNewChatModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="max-w-md w-full rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
                New 1-on-1 Message
              </h3>
              <button
                type="button"
                aria-label="Close modal"
                onClick={() => setShowNewChatModal(false)}
                className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                type="search"
                value={newChatSearch}
                onChange={(e) => setNewChatSearch(e.target.value)}
                placeholder="Search confirmed friends..."
                className="w-full h-9 pl-8 pr-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
              />
            </div>

            <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-white/5">
              {filteredFriendsForNewChat.length === 0 ? (
                <p className="text-xs text-slate-500 text-center py-6">
                  {friends.length === 0
                    ? 'Add and confirm friends first to start a 1-on-1 chat.'
                    : 'No matching friends found.'}
                </p>
              ) : (
                filteredFriendsForNewChat.map((fr) => (
                  <button
                    key={fr.uid}
                    type="button"
                    onClick={() => handleOpenFriendChat(fr.uid)}
                    className="w-full py-2.5 px-2 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-white/5 rounded-xl text-left cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Avatar src={fr.photoUrl} name={fr.displayName} size="sm" />
                      <div className="min-w-0">
                        <p className="text-xs font-semibold truncate text-slate-900 dark:text-white">
                          {fr.displayName}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">@{fr.username}</p>
                      </div>
                    </div>
                    <span className="text-xs font-semibold text-[#D4AF37]">Message</span>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Create Group Modal */}
      {showGroupModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="max-w-md w-full rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
                Create Group Chat
              </h3>
              <button
                type="button"
                aria-label="Close modal"
                onClick={() => setShowGroupModal(false)}
                className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateGroup} className="space-y-3">
              <input
                type="text"
                required
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="Group Name"
                maxLength={100}
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
              />
              <MediaUploadInput
                accept="image/*"
                mediaKind="image"
                label="Group Photo (Optional)"
                value={groupPhoto}
                onUploaded={(url) => setGroupPhoto(url)}
              />
              <div className="space-y-1.5 max-h-48 overflow-y-auto">
                <p className="text-xs font-medium text-slate-500">
                  Select Confirmed Friends ({selectedFriendUids.size} selected):
                </p>
                {friends.length === 0 ? (
                  <p className="text-xs text-slate-400">Add friends first to invite them to a group.</p>
                ) : (
                  friends.map((fr) => {
                    const checked = selectedFriendUids.has(fr.uid);
                    return (
                      <label
                        key={fr.uid}
                        className="flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer text-xs"
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => {
                            setSelectedFriendUids((prev) => {
                              const next = new Set(prev);
                              if (checked) next.delete(fr.uid);
                              else next.add(fr.uid);
                              return next;
                            });
                          }}
                          className="accent-[#D4AF37]"
                        />
                        <Avatar src={fr.photoUrl} name={fr.displayName} size="xs" />
                        <span className="truncate">{fr.displayName}</span>
                      </label>
                    );
                  })
                )}
              </div>
              <button
                type="submit"
                className="w-full h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Create Group
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
