import React, { useEffect, useState } from 'react';
import {
  Bell,
  Compass,
  Flag,
  Home,
  LayoutDashboard,
  Megaphone,
  Menu,
  MessageCircle,
  Moon,
  Plus,
  Search,
  Settings,
  Shield,
  Sun,
  User,
  Users,
  Video,
  Wallet,
  WifiOff,
  X,
  Globe,
  Download,
} from 'lucide-react';
import { collection, doc, limit, onSnapshot, orderBy, query, where } from 'firebase/firestore';
import { db, BOOTSTRAPPED_SUPER_ADMIN_EMAIL } from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { useT } from '../i18n/translations';
import { AppTab, PublicPage, UserProfile, AdCampaign } from '../types/hearthline';
import { Avatar } from './Avatar';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { recordVerifiedAdEvent } from '../lib/socialActions';
import { sanitizeExternalUrl } from '../lib/url';

interface LayoutShellProps {
  activeTab: AppTab;
  onSelectTab: (tab: AppTab, extra?: { targetUid?: string; convId?: string }) => void;
  onOpenUpload: (mode?: 'post' | 'story' | 'spark') => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  children: React.ReactNode;
}

export const LayoutShell: React.FC<LayoutShellProps> = ({
  activeTab,
  onSelectTab,
  onOpenUpload,
  searchQuery,
  onSearchChange,
  children,
}) => {
  const { firebaseUser, profile, isModerator, theme, setTheme, language, setLanguage } = useAuth();
  const t = useT(language);
  const isOnline = useOnlineStatus();
  const { isInstallable, install } = usePWAInstall();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);

  const [suggestedUsers, setSuggestedUsers] = useState<UserProfile[]>([]);
  const [suggestedPages, setSuggestedPages] = useState<PublicPage[]>([]);
  const [sponsoredAd, setSponsoredAd] = useState<AdCampaign | null>(null);

  useEffect(() => {
    if (!firebaseUser) return;

    const qNotifs = query(
      collection(db, 'notifications'),
      where('recipientUid', '==', firebaseUser.uid),
      where('read', '==', false)
    );
    const unsubN = onSnapshot(qNotifs, (snap) => setUnreadNotifs(snap.size), () => {});

    const qConvs = query(
      collection(db, 'conversations'),
      where('participantUids', 'array-contains', firebaseUser.uid)
    );
    const memberUnsubs = new Map<string, () => void>();
    const unreadByConv = new Map<string, number>();

    const recomputeUnread = () => {
      let total = 0;
      unreadByConv.forEach((n) => {
        if (n > 0) total += n;
      });
      setUnreadMsgs(total);
    };

    const unsubC = onSnapshot(
      qConvs,
      (snap) => {
        const activeIds = new Set(snap.docs.map((d) => d.id));
        // Clean up removed conversations
        Array.from(memberUnsubs.keys()).forEach((cid) => {
          if (!activeIds.has(cid)) {
            memberUnsubs.get(cid)?.();
            memberUnsubs.delete(cid);
            unreadByConv.delete(cid);
          }
        });
        // Attach member listeners for conversations
        snap.docs.forEach((d) => {
          if (!memberUnsubs.has(d.id)) {
            const unsubMem = onSnapshot(
              doc(db, 'conversations', d.id, 'members', firebaseUser.uid),
              (mSnap) => {
                const count = mSnap.exists() ? Number(mSnap.data().unreadCount || 0) : 0;
                unreadByConv.set(d.id, count);
                recomputeUnread();
              },
              () => {}
            );
            memberUnsubs.set(d.id, unsubMem);
          }
        });
        recomputeUnread();
      },
      () => {}
    );

    const unsubUsers = onSnapshot(
      query(collection(db, 'users'), where('accountStatus', '==', 'active'), limit(6)),
      (snap) => {
        setSuggestedUsers(
          snap.docs
            .map((d) => d.data() as UserProfile)
            .filter((u) => u.uid !== firebaseUser.uid)
            .slice(0, 4)
        );
      },
      () => {}
    );

    const unsubPages = onSnapshot(
      query(collection(db, 'pages'), orderBy('followersCount', 'desc'), limit(4)),
      (snap) => {
        setSuggestedPages(snap.docs.map((d) => ({ id: d.id, ...d.data() } as PublicPage)));
      },
      () => {}
    );

    const unsubAds = onSnapshot(
      query(collection(db, 'adCampaigns'), where('status', '==', 'active'), limit(3)),
      (snap) => {
        const eligible = snap.docs
          .map((d) => ({ id: d.id, ...d.data() } as AdCampaign))
          .find((c) => c.paymentStatus === 'verified' && c.spentPoisha < c.lifetimeBudgetPoisha);
        setSponsoredAd(eligible || null);
      },
      () => {}
    );

    return () => {
      unsubN();
      unsubC();
      memberUnsubs.forEach((fn) => fn());
      memberUnsubs.clear();
      unsubUsers();
      unsubPages();
      unsubAds();
    };
  }, [firebaseUser]);

  useEffect(() => {
    if (sponsoredAd && firebaseUser) {
      recordVerifiedAdEvent(sponsoredAd.id, firebaseUser.uid, 'impression');
    }
  }, [sponsoredAd?.id, firebaseUser?.uid]);

  const isSuperAdminEmail = Boolean(
    firebaseUser?.email &&
      firebaseUser.email.toLowerCase() === BOOTSTRAPPED_SUPER_ADMIN_EMAIL.toLowerCase()
  );
  const canAccessAdmin = isSuperAdminEmail || isModerator;

  const desktopNavItems: { id: AppTab; label: string; icon: React.ElementType; badge?: number }[] = [
    { id: 'home', label: t('home'), icon: Home },
    { id: 'spark', label: t('spark'), icon: Video },
    { id: 'friends', label: t('friends'), icon: Users },
    { id: 'messages', label: t('messages'), icon: MessageCircle, badge: unreadMsgs },
    { id: 'notifications', label: t('notifications'), icon: Bell, badge: unreadNotifs },
    { id: 'pages', label: t('pages'), icon: Flag },
    { id: 'communities', label: t('communities'), icon: Compass },
    { id: 'wallet', label: t('wallet'), icon: Wallet },
    { id: 'ads', label: t('adsManager'), icon: Megaphone },
    { id: 'profile', label: t('profile'), icon: User },
    ...(canAccessAdmin ? [{ id: 'admin' as AppTab, label: t('admin'), icon: Shield }] : []),
    { id: 'settings', label: t('settings'), icon: Settings },
  ];

  const secondaryMobileItems = desktopNavItems.filter(
    (item) => !['home', 'spark', 'messages', 'profile'].includes(item.id)
  );

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0A0B0E] text-slate-900 dark:text-[#F3F4F6] flex flex-col">
      {!isOnline && (
        <div className="bg-amber-500 text-[#0A0B0E] text-xs font-semibold px-4 py-1.5 flex items-center justify-center gap-2 z-50">
          <WifiOff className="w-3.5 h-3.5" />
          Offline — Viewing cached data. Reconnect to sync changes.
        </div>
      )}

      {/* Top Navigation Bar (Strict 3-zone layout) */}
      <header className="sticky top-0 z-40 h-14 border-b border-slate-200 dark:border-white/10 bg-white/90 dark:bg-[#0A0B0E]/90 backdrop-blur-md px-4 lg:px-6 flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            className="lg:hidden w-10 h-10 -ml-2 rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
            aria-label="Open navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => onSelectTab('home')}
            className="flex items-center gap-2.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span className="w-8 h-8 rounded-lg bg-[#D4AF37] text-[#0A0B0E] flex items-center justify-center font-display font-extrabold text-base">
              H
            </span>
            <span className="font-display font-bold text-lg tracking-tight text-slate-900 dark:text-white">
              HEARTHLINE
            </span>
          </button>
        </div>

        {/* Zone 2: Global Search */}
        <div className="flex-1 max-w-md hidden sm:block">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (e.target.value.trim() && activeTab !== 'friends') {
                  onSelectTab('friends');
                }
              }}
              placeholder={t('searchPlaceholder')}
              className="w-full h-9 pl-10 pr-4 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-[#14171F] text-xs text-slate-900 dark:text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
            />
          </div>
        </div>

        {/* Zone 3: Single Primary Create CTA & Admin Shortcut */}
        <div className="flex items-center gap-2 shrink-0">
          {canAccessAdmin && (
            <button
              type="button"
              onClick={() => onSelectTab('admin')}
              className={`hidden md:inline-flex items-center gap-1.5 h-9 px-3 rounded-xl border text-xs font-semibold cursor-pointer ${
                activeTab === 'admin'
                  ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#D4AF37]'
                  : 'border-[#D4AF37]/40 text-[#D4AF37] hover:bg-[#D4AF37]/10'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Panel</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => onSelectTab('notifications')}
            className="relative lg:hidden w-10 h-10 rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifs > 0 && (
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#D4AF37]" />
            )}
          </button>

          <button
            type="button"
            onClick={() => onOpenUpload('post')}
            className="hidden sm:inline-flex items-center gap-2 h-9 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold hover:bg-[#E5C158] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t('upload')}</span>
          </button>
        </div>
      </header>

      {/* Main Responsive Workspace */}
      <div className="flex-1 max-w-[1440px] w-full mx-auto flex">
        {/* Desktop Left Sidebar */}
        <aside className="hidden lg:flex flex-col w-64 shrink-0 border-r border-slate-200 dark:border-white/10 px-3 py-5 sticky top-14 h-[calc(100vh-3.5rem)] justify-between overflow-y-auto">
          <nav className="space-y-1">
            {desktopNavItems.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    active
                      ? 'bg-[#D4AF37]/15 text-[#D4AF37]'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <span className="flex items-center gap-3">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </span>
                  {item.badge && item.badge > 0 ? (
                    <span className="px-2 py-0.5 rounded-full bg-[#3B82F6] text-white text-[11px] font-mono tabular-nums">
                      {item.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>

          <div className="pt-4 border-t border-slate-200 dark:border-white/10 space-y-2.5">
            <div className="flex items-center gap-2 px-2">
              <button
                type="button"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="flex-1 h-9 rounded-xl border border-slate-200 dark:border-white/10 flex items-center justify-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 hover:border-[#D4AF37] cursor-pointer"
              >
                {theme === 'dark' ? <Sun className="w-3.5 h-3.5 text-[#D4AF37]" /> : <Moon className="w-3.5 h-3.5" />}
                {theme === 'dark' ? 'Light' : 'Dark'}
              </button>
              <button
                type="button"
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                className="flex-1 h-9 rounded-xl border border-slate-200 dark:border-white/10 flex items-center justify-center gap-1.5 text-xs text-slate-600 dark:text-slate-300 hover:border-[#D4AF37] cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 text-[#3B82F6]" />
                {language === 'en' ? 'বাংলা' : 'EN'}
              </button>
            </div>
            {profile && (
              <button
                type="button"
                onClick={() => onSelectTab('profile')}
                className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 text-left cursor-pointer"
              >
                <Avatar src={profile.photoUrl} name={profile.displayName} size="sm" />
                <div className="min-w-0">
                  <p className="text-xs font-semibold truncate text-slate-900 dark:text-white">
                    {profile.displayName}
                  </p>
                  <p className="text-[11px] text-slate-500 truncate">@{profile.username}</p>
                </div>
              </button>
            )}
          </div>
        </aside>

        {/* Center Main Content */}
        <main
          className={`flex-1 min-w-0 ${
            activeTab === 'spark' ? 'p-0' : 'px-3 sm:px-6 py-5 pb-24 lg:pb-8'
          }`}
        >
          {children}
        </main>

        {/* Desktop Right Recommendations Sidebar */}
        {activeTab !== 'spark' && activeTab !== 'admin' && (
          <aside className="hidden xl:block w-80 shrink-0 border-l border-slate-200 dark:border-white/10 px-4 py-5 space-y-6 sticky top-14 h-[calc(100vh-3.5rem)] overflow-y-auto">
            {sponsoredAd && (
              <div className="rounded-2xl border border-[#D4AF37]/30 bg-white dark:bg-[#13151B] p-4 space-y-3">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-[#D4AF37]">Sponsored</span>
                  <span className="text-slate-400 capitalize">{sponsoredAd.objective.replace(/_/g, ' ')}</span>
                </div>
                {sponsoredAd.creativeMediaUrl && (
                  /\.(mp4|webm|mov|m4v)(\?|$)|\/video\/upload\//i.test(sponsoredAd.creativeMediaUrl) ? (
                    <video
                      src={sponsoredAd.creativeMediaUrl}
                      muted
                      playsInline
                      className="w-full h-36 object-cover rounded-xl bg-black"
                    />
                  ) : (
                    <img
                      src={sponsoredAd.creativeMediaUrl}
                      alt={sponsoredAd.title}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="w-full h-36 object-cover rounded-xl bg-black"
                    />
                  )
                )}
                <div>
                  <h4 className="font-semibold text-sm text-slate-900 dark:text-white line-clamp-1">
                    {sponsoredAd.title}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-1">
                    {sponsoredAd.creativeText}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    if (firebaseUser) {
                      await recordVerifiedAdEvent(sponsoredAd.id, firebaseUser.uid, 'click');
                    }
                    const safeUrl = sanitizeExternalUrl(sponsoredAd.targetUrl);
                    if (sponsoredAd.pageId) {
                      onSelectTab('pages');
                    } else if (safeUrl) {
                      window.open(safeUrl, '_blank', 'noopener,noreferrer');
                    } else {
                      onSelectTab('ads');
                    }
                  }}
                  className="w-full py-2 rounded-xl bg-[#3B82F6] text-white text-xs font-semibold hover:bg-blue-600 transition-colors cursor-pointer"
                >
                  {sponsoredAd.pageId ? 'Visit Page' : 'Learn More'}
                </button>
              </div>
            )}

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display font-semibold text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  {t('suggestions')}
                </h3>
                <button
                  onClick={() => onSelectTab('friends')}
                  className="text-xs text-[#D4AF37] hover:underline cursor-pointer"
                >
                  See all
                </button>
              </div>
              {suggestedUsers.length === 0 ? (
                <p className="text-xs text-slate-500">Invite friends to connect on HEARTHLINE.</p>
              ) : (
                <div className="space-y-2.5">
                  {suggestedUsers.map((u) => (
                    <button
                      key={u.uid}
                      type="button"
                      onClick={() => onSelectTab('profile', { targetUid: u.uid })}
                      className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 text-left cursor-pointer"
                    >
                      <Avatar src={u.photoUrl} name={u.displayName} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold truncate text-slate-900 dark:text-white">
                          {u.displayName}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">@{u.username}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-white/10">
              <div className="flex items-center justify-between">
                <h3 className="font-display font-semibold text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Public Pages
                </h3>
                <button
                  onClick={() => onSelectTab('pages')}
                  className="text-xs text-[#D4AF37] hover:underline cursor-pointer"
                >
                  Explore
                </button>
              </div>
              {suggestedPages.length === 0 ? (
                <p className="text-xs text-slate-500">Create a Public Page to grow your audience.</p>
              ) : (
                <div className="space-y-2.5">
                  {suggestedPages.map((pg) => (
                    <button
                      key={pg.id}
                      type="button"
                      onClick={() => onSelectTab('pages')}
                      className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 text-left cursor-pointer"
                    >
                      <Avatar src={pg.avatarUrl} name={pg.name} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold truncate text-slate-900 dark:text-white">
                          {pg.name}
                        </p>
                        <p className="text-[11px] text-slate-500 truncate">
                          {pg.category} · {pg.followersCount} followers
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </aside>
        )}
      </div>

      {/* Mobile Fixed Bottom Navigation — EXACTLY 5 items */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-16 pb-safe border-t border-slate-200 dark:border-white/10 bg-white/95 dark:bg-[#0A0B0E]/95 backdrop-blur-md grid grid-cols-5 items-center px-1">
        <button
          type="button"
          onClick={() => onSelectTab('home')}
          className={`flex flex-col items-center justify-center min-h-[44px] cursor-pointer ${
            activeTab === 'home' ? 'text-[#D4AF37]' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">{t('home')}</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('spark')}
          className={`flex flex-col items-center justify-center min-h-[44px] cursor-pointer ${
            activeTab === 'spark' ? 'text-[#D4AF37]' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <Video className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">{t('spark')}</span>
        </button>

        <div className="flex items-center justify-center">
          <button
            type="button"
            onClick={() => onOpenUpload('post')}
            aria-label="Upload Post, Story, or Spark Video"
            className="w-12 h-12 -mt-4 rounded-2xl bg-[#D4AF37] text-[#0A0B0E] shadow-lg shadow-[#D4AF37]/25 flex items-center justify-center active:scale-95 transition-transform cursor-pointer"
          >
            <Plus className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>

        <button
          type="button"
          onClick={() => onSelectTab('messages')}
          className={`relative flex flex-col items-center justify-center min-h-[44px] cursor-pointer ${
            activeTab === 'messages' ? 'text-[#D4AF37]' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <MessageCircle className="w-5 h-5" />
          {unreadMsgs > 0 && (
            <span className="absolute top-1.5 right-4 w-2 h-2 rounded-full bg-[#3B82F6]" />
          )}
          <span className="text-[10px] font-medium mt-0.5">{t('messages')}</span>
        </button>

        <button
          type="button"
          onClick={() => onSelectTab('profile')}
          className={`flex flex-col items-center justify-center min-h-[44px] cursor-pointer ${
            activeTab === 'profile' ? 'text-[#D4AF37]' : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">{t('profile')}</span>
        </button>
      </nav>

      {/* Mobile Secondary Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-72 max-w-[82vw] bg-white dark:bg-[#12141A] h-full border-r border-slate-200 dark:border-white/10 p-5 flex flex-col justify-between overflow-y-auto">
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <LayoutDashboard className="w-5 h-5 text-[#D4AF37]" />
                  <span className="font-display font-bold text-base">Menu</span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => {
                    onSearchChange(e.target.value);
                    if (e.target.value.trim()) {
                      onSelectTab('friends');
                    }
                  }}
                  placeholder="Search HEARTHLINE..."
                  className="w-full h-9 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-[#0A0B0E] text-xs"
                />
              </div>

              <div className="space-y-1">
                {secondaryMobileItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        onSelectTab(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-medium cursor-pointer ${
                        activeTab === item.id
                          ? 'bg-[#D4AF37]/15 text-[#D4AF37]'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5'
                      }`}
                    >
                      <span className="flex items-center gap-3">
                        <Icon className="w-4 h-4" />
                        {item.label}
                      </span>
                      {item.badge && item.badge > 0 ? (
                        <span className="px-2 py-0.5 rounded-full bg-[#3B82F6] text-white text-xs font-mono">
                          {item.badge}
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 dark:border-white/10 space-y-2">
              {isInstallable && (
                <button
                  onClick={install}
                  className="w-full py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  Install HEARTHLINE App
                </button>
              )}
              <div className="flex gap-2">
                <button
                  onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                  className="flex-1 py-2 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-medium cursor-pointer"
                >
                  {theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
                </button>
                <button
                  onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                  className="flex-1 py-2 rounded-xl border border-slate-200 dark:border-white/10 text-xs font-medium cursor-pointer"
                >
                  {language === 'en' ? 'বাংলা' : 'English'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
