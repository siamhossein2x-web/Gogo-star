import React, { useEffect, useMemo, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  Bell,
  Check,
  CheckCheck,
  Coins,
  Heart,
  Megaphone,
  MessageCircle,
  MessageSquare,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { AppTab, NotificationItem, UserProfile } from '../types/hearthline';
import { useAuth } from '../context/AuthContext';
import { Avatar } from './Avatar';
import { useToast } from './Toast';

interface Props {
  onNavigate: (tab: AppTab, extra?: { targetUid?: string; convId?: string }) => void;
}

type NotifFilter = 'all' | 'unread' | 'social' | 'messages' | 'pages_wallet';

function formatRelativeTime(ts?: { toDate?: () => Date }): string {
  if (!ts?.toDate) return 'Just now';
  const diffSec = Math.max(0, Math.floor((Date.now() - ts.toDate().getTime()) / 1000));
  if (diffSec < 60) return 'Just now';
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  if (diffSec < 604800) return `${Math.floor(diffSec / 86400)}d ago`;
  return ts.toDate().toLocaleDateString([], { month: 'short', day: 'numeric' });
}

function getNotificationIcon(type: string): { Icon: React.ElementType; tone: string } {
  switch (type) {
    case 'friend_request':
      return { Icon: UserPlus, tone: 'text-[#3B82F6]' };
    case 'friend_accepted':
      return { Icon: UserCheck, tone: 'text-emerald-500' };
    case 'new_follower':
      return { Icon: Users, tone: 'text-[#D4AF37]' };
    case 'post_reaction':
    case 'spark_like':
    case 'story_reaction':
      return { Icon: Heart, tone: 'text-rose-500' };
    case 'post_comment':
    case 'spark_comment':
    case 'story_reply':
      return { Icon: MessageSquare, tone: 'text-[#3B82F6]' };
    case 'direct_message':
    case 'group_message':
      return { Icon: MessageCircle, tone: 'text-[#D4AF37]' };
    case 'page_monetization_credit':
    case 'withdrawal_paid':
    case 'withdrawal_rejected':
    case 'withdrawal_processing':
      return { Icon: Coins, tone: 'text-[#D4AF37]' };
    default:
      if (type.startsWith('ad_')) return { Icon: Megaphone, tone: 'text-[#3B82F6]' };
      return { Icon: Bell, tone: 'text-[#D4AF37]' };
  }
}

function matchesFilter(n: NotificationItem, filter: NotifFilter): boolean {
  if (filter === 'all') return true;
  if (filter === 'unread') return !n.read;
  if (filter === 'messages') {
    return n.type === 'direct_message' || n.type === 'group_message' || n.targetTab === 'messages';
  }
  if (filter === 'pages_wallet') {
    return (
      n.type.includes('page') ||
      n.type.includes('withdrawal') ||
      n.type.startsWith('ad_') ||
      n.targetTab === 'wallet' ||
      n.targetTab === 'pages' ||
      n.targetTab === 'ads'
    );
  }
  return (
    n.type.includes('friend') ||
    n.type.includes('follow') ||
    n.type.includes('post') ||
    n.type.includes('spark') ||
    n.type.includes('story')
  );
}

export const NotificationsView: React.FC<Props> = ({ onNavigate }) => {
  const { firebaseUser } = useAuth();
  const { pushToast } = useToast();

  const [items, setItems] = useState<NotificationItem[]>([]);
  const [usersMap, setUsersMap] = useState<Record<string, UserProfile>>({});
  const [filter, setFilter] = useState<NotifFilter>('all');
  const [loading, setLoading] = useState(true);
  const [busyBulk, setBusyBulk] = useState(false);

  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      query(collection(db, 'notifications'), where('recipientUid', '==', firebaseUser.uid)),
      async (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as NotificationItem));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setItems(list);
        setLoading(false);

        const missingActors = Array.from(
          new Set(list.map((n) => n.actorUid).filter((u) => u && !usersMap[u]))
        );
        if (missingActors.length > 0) {
          const loaded: Record<string, UserProfile> = {};
          await Promise.all(
            missingActors.map(async (u) => {
              try {
                const uSnap = await getDoc(doc(db, 'users', u));
                if (uSnap.exists()) loaded[u] = uSnap.data() as UserProfile;
              } catch {
                // ignore unavailable actor profile
              }
            })
          );
          if (Object.keys(loaded).length > 0) {
            setUsersMap((prev) => ({ ...prev, ...loaded }));
          }
        }
      },
      (err) => {
        setLoading(false);
        handleFirestoreError(err, OperationType.LIST, 'notifications');
      }
    );
    return () => unsub();
  }, [firebaseUser?.uid]);

  const unreadCount = useMemo(() => items.filter((i) => !i.read).length, [items]);
  const readCount = useMemo(() => items.filter((i) => i.read).length, [items]);
  const filteredItems = useMemo(
    () => items.filter((n) => matchesFilter(n, filter)),
    [items, filter]
  );

  const markAllRead = async () => {
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to update notifications.', 'error');
      return;
    }
    const unread = items.filter((i) => !i.read);
    if (unread.length === 0) return;
    setBusyBulk(true);
    try {
      for (let i = 0; i < unread.length; i += 400) {
        const batch = writeBatch(db);
        unread.slice(i, i + 400).forEach((n) => {
          batch.update(doc(db, 'notifications', n.id), { read: true });
        });
        await batch.commit();
      }
      pushToast('All notifications marked as read.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'notifications');
    } finally {
      setBusyBulk(false);
    }
  };

  const clearReadNotifications = async () => {
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to clear notifications.', 'error');
      return;
    }
    const readItems = items.filter((i) => i.read);
    if (readItems.length === 0) return;
    setBusyBulk(true);
    try {
      for (let i = 0; i < readItems.length; i += 400) {
        const batch = writeBatch(db);
        readItems.slice(i, i + 400).forEach((n) => {
          batch.delete(doc(db, 'notifications', n.id));
        });
        await batch.commit();
      }
      pushToast('Cleared read notifications.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'notifications');
    } finally {
      setBusyBulk(false);
    }
  };

  const toggleReadState = async (n: NotificationItem) => {
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to update notifications.', 'error');
      return;
    }
    try {
      await updateDoc(doc(db, 'notifications', n.id), { read: !n.read });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `notifications/${n.id}`);
    }
  };

  const deleteNotification = async (n: NotificationItem) => {
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to delete notifications.', 'error');
      return;
    }
    try {
      await deleteDoc(doc(db, 'notifications', n.id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `notifications/${n.id}`);
    }
  };

  const openNotification = async (n: NotificationItem) => {
    if (!n.read && firebaseUser?.emailVerified) {
      try {
        await updateDoc(doc(db, 'notifications', n.id), { read: true });
      } catch {
        // non-fatal navigation read-mark
      }
    }
    if (n.targetTab) {
      const tab = n.targetTab as AppTab;
      onNavigate(tab, tab === 'profile' && n.actorUid ? { targetUid: n.actorUid } : undefined);
    }
  };

  return (
    <div className="max-w-2xl mx-auto rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-slate-200 dark:border-white/10 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <Bell className="w-5 h-5 text-[#D4AF37]" />
            <h2 className="font-display font-bold text-base text-slate-900 dark:text-white">
              Notifications
            </h2>
            {unreadCount > 0 && (
              <span className="text-xs text-[#D4AF37] font-mono tabular-nums font-semibold">
                {unreadCount} unread
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button
                type="button"
                disabled={busyBulk}
                onClick={markAllRead}
                className="min-h-[38px] px-3 rounded-xl border border-slate-200 dark:border-white/10 inline-flex items-center gap-1.5 text-xs font-medium text-[#3B82F6] hover:bg-slate-50 dark:hover:bg-white/5 disabled:opacity-50 cursor-pointer whitespace-nowrap"
              >
                <CheckCheck className="w-4 h-4" /> Mark all read
              </button>
            )}
            {readCount > 0 && (
              <button
                type="button"
                disabled={busyBulk}
                onClick={clearReadNotifications}
                className="min-h-[38px] px-3 rounded-xl border border-slate-200 dark:border-white/10 inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 hover:text-rose-500 disabled:opacity-50 cursor-pointer whitespace-nowrap"
              >
                <Trash2 className="w-3.5 h-3.5" /> Clear read
              </button>
            )}
          </div>
        </div>

        {/* Interactive Filter Tabs */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-[#0A0B0E] border border-slate-200 dark:border-white/10 overflow-x-auto">
          {[
            { id: 'all', label: 'All' },
            { id: 'unread', label: unreadCount > 0 ? `Unread (${unreadCount})` : 'Unread' },
            { id: 'social', label: 'Social' },
            { id: 'messages', label: 'Messages' },
            { id: 'pages_wallet', label: 'Pages & Wallet' },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setFilter(tab.id as NotifFilter)}
              className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                filter === tab.id
                  ? 'bg-white dark:bg-[#D4AF37] text-slate-900 dark:text-[#0A0B0E] shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Notification List */}
      {loading ? (
        <div className="p-5 space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center gap-3 animate-pulse">
              <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-white/10 shrink-0" />
              <div className="flex-1 space-y-2">
                <div className="h-3 w-40 bg-slate-200 dark:bg-white/10 rounded" />
                <div className="h-2.5 w-64 bg-slate-200 dark:bg-white/10 rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="p-10 text-center space-y-2">
          <Bell className="w-8 h-8 text-slate-400 mx-auto" />
          <p className="text-sm font-medium text-slate-800 dark:text-slate-200">
            {filter === 'unread' ? 'You are all caught up' : 'No notifications yet'}
          </p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Real-time alerts from friend requests, reactions, comments, direct and group messages, Pages, and Wallet updates appear here.
          </p>
        </div>
      ) : (
        <div className="divide-y divide-slate-100 dark:divide-white/5">
          {filteredItems.map((n) => {
            const actor = usersMap[n.actorUid];
            const { Icon, tone } = getNotificationIcon(n.type);
            return (
              <div
                key={n.id}
                className={`px-4 sm:px-5 py-3.5 flex items-start gap-3 transition-colors ${
                  !n.read ? 'bg-[#D4AF37]/5' : 'hover:bg-slate-50/70 dark:hover:bg-white/[0.03]'
                }`}
              >
                <button
                  type="button"
                  onClick={() => openNotification(n)}
                  className="relative shrink-0 cursor-pointer"
                  aria-label={`Open notification: ${n.title}`}
                >
                  <Avatar
                    src={actor?.photoUrl}
                    name={actor?.displayName || n.title || 'H'}
                    size="md"
                  />
                  <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white dark:bg-[#13151B] border border-slate-200 dark:border-white/10 flex items-center justify-center">
                    <Icon className={`w-3 h-3 ${tone}`} />
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => openNotification(n)}
                  className="flex-1 min-w-0 text-left space-y-0.5 cursor-pointer"
                >
                  <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                    {n.title}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 break-words">
                    {n.body}
                  </p>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 pt-0.5">
                    {actor?.displayName && (
                      <>
                        <span>{actor.displayName}</span>
                        <span aria-hidden="true">·</span>
                      </>
                    )}
                    <span>{formatRelativeTime(n.createdAt)}</span>
                    {!n.read && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-[#D4AF37] font-semibold">Unread</span>
                      </>
                    )}
                  </div>
                </button>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => toggleReadState(n)}
                    aria-label={n.read ? 'Mark as unread' : 'Mark as read'}
                    title={n.read ? 'Mark as unread' : 'Mark as read'}
                    className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-400 hover:text-[#3B82F6] hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                  >
                    <Check className={`w-4 h-4 ${!n.read ? 'text-[#D4AF37]' : ''}`} />
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteNotification(n)}
                    aria-label="Delete notification"
                    title="Delete notification"
                    className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
