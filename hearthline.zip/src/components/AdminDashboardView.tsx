import React, { useEffect, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  limit,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  AlertTriangle,
  ArrowRight,
  Ban,
  CheckCircle2,
  Coins,
  FileText,
  Key,
  Lock,
  LogOut,
  Megaphone,
  Shield,
  ShieldAlert,
  Sliders,
  Sparkles,
  UserCheck,
  Wallet,
  XCircle,
} from 'lucide-react';
import {
  BOOTSTRAPPED_SUPER_ADMIN_EMAIL,
  db,
  handleFirestoreError,
  makeSafeId,
  OperationType,
} from '../lib/firebase';
import {
  AdCampaign,
  AdPayment,
  AdminLog,
  Post,
  PublicPage,
  ReportItem,
  SparkVideo,
  UserProfile,
  UserRole,
  WithdrawalRequest,
} from '../types/hearthline';
import { createNotification, useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { bdtToPoisha, calculatePageRevenueSplit, formatBDT } from '../lib/finance';
import { settlePageRevenue4060 } from '../lib/socialActions';
import { sanitizeExternalUrl } from '../lib/url';

interface PageAppItem {
  id: string;
  pageId: string;
  ownerUid: string;
  followersCount: number;
  pageAgeDays: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: Timestamp;
}

interface CreatorAppItem {
  id: string;
  uid: string;
  followersCount: number;
  accountAgeDays: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: Timestamp;
}

export const AdminDashboardView: React.FC = () => {
  const {
    firebaseUser,
    profile,
    isModerator,
    isAdmin,
    isSuperAdmin,
    platformSettings,
    featureFlags,
    signOut,
  } = useAuth();
  const { pushToast } = useToast();
  const [gatewayBusy, setGatewayBusy] = useState(false);

  const [tab, setTab] = useState<
    'overview' | 'ads' | 'monetization' | 'withdrawals' | 'moderation' | 'settings'
  >('overview');

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [pages, setPages] = useState<PublicPage[]>([]);
  const [postsCount, setPostsCount] = useState(0);
  const [sparksCount, setSparksCount] = useState(0);
  const [campaigns, setCampaigns] = useState<AdCampaign[]>([]);
  const [adPayments, setAdPayments] = useState<AdPayment[]>([]);
  const [pageApps, setPageApps] = useState<PageAppItem[]>([]);
  const [creatorApps, setCreatorApps] = useState<CreatorAppItem[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [logs, setLogs] = useState<AdminLog[]>([]);

  const [adFilter, setAdFilter] = useState<'all' | AdCampaign['status']>('all');
  const [reportFilter, setReportFilter] = useState<'all' | ReportItem['status']>('all');
  const [adNotes, setAdNotes] = useState<Record<string, string>>({});
  const [appNotes, setAppNotes] = useState<Record<string, string>>({});
  const [wdNotes, setWdNotes] = useState<Record<string, string>>({});

  // Page 40/60 settlement form
  const [settlePageId, setSettlePageId] = useState('');
  const [grossBdt, setGrossBdt] = useState(1000);
  const [deductionsBdt, setDeductionsBdt] = useState(50);
  const [settleNote, setSettleNote] = useState('Monthly verified Page ad revenue settlement');
  const [busyAction, setBusyAction] = useState(false);

  // Creator Reward Distribution form
  const [rewardUid, setRewardUid] = useState('');
  const [rewardBdt, setRewardBdt] = useState(500);
  const [rewardNote, setRewardNote] = useState('Verified creator pool payout');

  // Super Admin settings form
  const [minWdBdt, setMinWdBdt] = useState(platformSettings.minWithdrawalPoisha / 100);
  const [pageMinFollowers, setPageMinFollowers] = useState(platformSettings.pageMinFollowers);
  const [pageMinAgeDays, setPageMinAgeDays] = useState(platformSettings.pageMinAgeDays);
  const [creatorMinFollowers, setCreatorMinFollowers] = useState(platformSettings.creatorMinFollowers);
  const [creatorMinAgeDays, setCreatorMinAgeDays] = useState(platformSettings.creatorMinAgeDays);
  const [ownerSharePct, setOwnerSharePct] = useState(platformSettings.pageOwnerShareBps / 100);
  const [creatorPoolPct, setCreatorPoolPct] = useState(platformSettings.creatorPoolBps / 100);
  const [videoAllocPct, setVideoAllocPct] = useState(platformSettings.creatorVideoAllocPct);
  const [postAllocPct, setPostAllocPct] = useState(platformSettings.creatorPostAllocPct);
  const [qualityAllocPct, setQualityAllocPct] = useState(platformSettings.creatorQualityAllocPct);

  // Role assignment form
  const [roleTargetUid, setRoleTargetUid] = useState('');
  const [roleValue, setRoleValue] = useState<UserRole>('moderator');

  useEffect(() => {
    setMinWdBdt(platformSettings.minWithdrawalPoisha / 100);
    setPageMinFollowers(platformSettings.pageMinFollowers);
    setPageMinAgeDays(platformSettings.pageMinAgeDays);
    setCreatorMinFollowers(platformSettings.creatorMinFollowers);
    setCreatorMinAgeDays(platformSettings.creatorMinAgeDays);
    setOwnerSharePct(platformSettings.pageOwnerShareBps / 100);
    setCreatorPoolPct(platformSettings.creatorPoolBps / 100);
    setVideoAllocPct(platformSettings.creatorVideoAllocPct);
    setPostAllocPct(platformSettings.creatorPostAllocPct);
    setQualityAllocPct(platformSettings.creatorQualityAllocPct);
  }, [platformSettings]);

  useEffect(() => {
    if (!firebaseUser || !isModerator) return;

    const uUsers = onSnapshot(
      isAdmin
        ? query(collection(db, 'users'), limit(150))
        : query(collection(db, 'users'), where('accountStatus', '==', 'active'), limit(150)),
      (s) => setUsers(s.docs.map((d) => d.data() as UserProfile))
    );
    const uPages = onSnapshot(query(collection(db, 'pages'), limit(100)), (s) => {
      const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as PublicPage));
      setPages(list);
      const approved = list.find((p) => p.monetizationStatus === 'approved');
      if (!settlePageId && approved) setSettlePageId(approved.id);
    });
    const uPosts = onSnapshot(
      isAdmin
        ? query(collection(db, 'posts'), limit(200))
        : query(
            collection(db, 'posts'),
            where('visibility', 'in', ['public', 'friends', 'community']),
            limit(200)
          ),
      (s) => setPostsCount((s.docs.map((d) => d.data() as Post)).length)
    );
    const uSparks = onSnapshot(query(collection(db, 'sparkVideos'), limit(200)), (s) =>
      setSparksCount((s.docs.map((d) => d.data() as SparkVideo)).length)
    );
    const uReports = onSnapshot(collection(db, 'reports'), (s) => {
      const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as ReportItem));
      list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
      setReports(list);
    });
    const uLogs = onSnapshot(query(collection(db, 'adminLogs'), limit(80)), (s) => {
      const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as AdminLog));
      list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
      setLogs(list);
    });

    let uCamps = () => {};
    let uPays = () => {};
    let uPApps = () => {};
    let uCApps = () => {};
    let uWds = () => {};

    if (isAdmin) {
      uCamps = onSnapshot(collection(db, 'adCampaigns'), (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as AdCampaign));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setCampaigns(list);
      });
      uPays = onSnapshot(collection(db, 'adPayments'), (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as AdPayment));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setAdPayments(list);
      });
      uPApps = onSnapshot(collection(db, 'pageMonetizationApplications'), (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as PageAppItem));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setPageApps(list);
      });
      uCApps = onSnapshot(collection(db, 'creatorMonetizationApplications'), (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as CreatorAppItem));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setCreatorApps(list);
      });
      uWds = onSnapshot(collection(db, 'withdrawalRequests'), (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as WithdrawalRequest));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setWithdrawals(list);
      });
    }

    return () => {
      uUsers();
      uPages();
      uPosts();
      uSparks();
      uReports();
      uLogs();
      uCamps();
      uPays();
      uPApps();
      uCApps();
      uWds();
    };
  }, [firebaseUser?.uid, isModerator, isAdmin]);

  const isMasterSuperAdminEmail =
    firebaseUser?.email?.toLowerCase() === BOOTSTRAPPED_SUPER_ADMIN_EMAIL.toLowerCase();

  const handleClaimSuperAdmin = async () => {
    if (!firebaseUser) return;
    setGatewayBusy(true);
    try {
      await setDoc(doc(db, 'admins', firebaseUser.uid), {
        uid: firebaseUser.uid,
        role: 'super_admin',
        createdAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'users', firebaseUser.uid), {
        role: 'super_admin',
        updatedAt: serverTimestamp(),
      });
      pushToast('Super Admin access successfully activated!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `admins/${firebaseUser.uid}`);
    } finally {
      setGatewayBusy(false);
    }
  };

  const handleRequestAdminRole = async () => {
    if (!firebaseUser) return;
    setGatewayBusy(true);
    try {
      const repId = makeSafeId('rep');
      await setDoc(doc(db, 'reports', repId), {
        reporterUid: firebaseUser.uid,
        targetType: 'user',
        targetId: firebaseUser.uid,
        reason: 'Admin Role Request',
        details: `User ${firebaseUser.email || 'Anonymous'} (${firebaseUser.uid}) requested Moderator/Admin access.`,
        status: 'open',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      pushToast('Role request submitted to Super Admin moderation queue.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'reports');
    } finally {
      setGatewayBusy(false);
    }
  };

  if (!isModerator) {
    return (
      <div className="max-w-3xl mx-auto space-y-6">
        {/* Gateway Header */}
        <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 sm:p-8 space-y-4 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/40 flex items-center justify-center text-[#D4AF37]">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="font-display text-xl sm:text-2xl font-bold text-slate-900 dark:text-white">
                    HEARTHLINE Admin Panel
                  </h1>
                  <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full border border-amber-500/40 bg-amber-500/10 text-amber-500">
                    অ্যাডমিন প্যানেল
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Governance console for ad reviews, 40/60 Page monetization settlements, payouts, and moderation.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-rose-500/30 bg-rose-500/10 text-rose-500 font-medium">
                <Lock className="w-3.5 h-3.5" /> Restricted Access
              </span>
            </div>
          </div>

          {/* Account Status Card */}
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-5 space-y-3 text-xs">
            <h2 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#3B82F6]" /> Current Signed-In Session
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-slate-600 dark:text-slate-300">
              <div>
                <span className="text-slate-500 block text-[11px]">User Account:</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {profile?.displayName || firebaseUser?.displayName || 'User'}
                </span>
                <span className="text-slate-500 block text-[11px] truncate">
                  {firebaseUser?.email || 'No email associated'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px]">System Role:</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="px-2.5 py-0.5 rounded-full bg-slate-200 dark:bg-white/10 font-mono font-semibold uppercase text-slate-800 dark:text-slate-200">
                    {profile?.role || 'user'}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    (Requires Moderator or Admin)
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 dark:border-white/10 flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <span className="text-slate-500">
                Super Admin Account: <strong className="font-mono text-[#D4AF37]">{BOOTSTRAPPED_SUPER_ADMIN_EMAIL}</strong>
              </span>
              <button
                type="button"
                onClick={() => {
                  if (firebaseUser?.uid) {
                    navigator.clipboard.writeText(firebaseUser.uid);
                    pushToast('UID copied to clipboard.', 'info');
                  }
                }}
                className="text-[#3B82F6] hover:underline cursor-pointer"
              >
                Copy your UID ({firebaseUser?.uid?.slice(0, 8)}...)
              </button>
            </div>
          </div>

          {/* Contextual Action depending on email */}
          {isMasterSuperAdminEmail ? (
            <div className="rounded-2xl border border-[#D4AF37]/40 bg-[#D4AF37]/10 p-5 space-y-3">
              <div className="flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    Super Admin Master Account Detected
                  </h3>
                  <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                    You are signed in as <strong>{BOOTSTRAPPED_SUPER_ADMIN_EMAIL}</strong>. Click below to activate your Super Admin credentials and open the complete Admin Dashboard.
                  </p>
                </div>
              </div>
              <button
                type="button"
                disabled={gatewayBusy}
                onClick={handleClaimSuperAdmin}
                className="w-full sm:w-auto h-11 px-6 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold text-xs flex items-center justify-center gap-2 hover:bg-[#E5C158] cursor-pointer disabled:opacity-50 transition-colors"
              >
                <Key className="w-4 h-4" />
                <span>{gatewayBusy ? 'Activating...' : 'Activate Super Admin Privileges & Open Panel'}</span>
              </button>
            </div>
          ) : (
            <div className="rounded-2xl border border-blue-500/20 bg-blue-500/5 p-5 space-y-3">
              <h3 className="font-semibold text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-[#3B82F6]" /> How to Access the Admin Panel:
              </h3>
              <ol className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 list-decimal list-inside leading-relaxed">
                <li>
                  Sign in with the primary administrator account: <strong className="font-mono text-[#D4AF37]">{BOOTSTRAPPED_SUPER_ADMIN_EMAIL}</strong>.
                </li>
                <li>
                  Or contact the Super Admin and ask them to add your UID (<span className="font-mono font-semibold">{firebaseUser?.uid}</span>) as an Admin or Moderator under <em>Platform Settings → Role Assignment</em>.
                </li>
              </ol>
              <div className="flex flex-wrap gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={signOut}
                  className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold text-xs flex items-center gap-2 hover:bg-[#E5C158] cursor-pointer transition-colors"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign In with Admin Account ({BOOTSTRAPPED_SUPER_ADMIN_EMAIL})</span>
                </button>
                <button
                  type="button"
                  disabled={gatewayBusy}
                  onClick={handleRequestAdminRole}
                  className="h-10 px-4 rounded-xl border border-slate-200 dark:border-white/10 hover:border-[#3B82F6] text-xs font-semibold cursor-pointer disabled:opacity-50"
                >
                  {gatewayBusy ? 'Sending Request...' : 'Submit Admin Role Request'}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Administrative Capabilities Showcase */}
        <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4">
          <h2 className="font-display font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#D4AF37]" /> Core Admin Control Capabilities
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] space-y-1">
              <div className="flex items-center gap-2 font-semibold text-slate-900 dark:text-white">
                <Megaphone className="w-4 h-4 text-[#3B82F6]" /> Ads Manager &amp; Payment Review
              </div>
              <p className="text-slate-500 leading-relaxed">
                Inspect advertiser campaign creatives, verify bKash/Nagad/Bank transaction reference codes, and activate real-time ad delivery.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] space-y-1">
              <div className="flex items-center gap-2 font-semibold text-[#D4AF37]">
                <Coins className="w-4 h-4 text-[#D4AF37]" /> Page Monetization (40/60 Split)
              </div>
              <p className="text-slate-500 leading-relaxed">
                Approve eligible Public Pages and execute verified 40% Owner / 60% Platform revenue settlements credited directly to Page Owner Wallets.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] space-y-1">
              <div className="flex items-center gap-2 font-semibold text-emerald-500">
                <Wallet className="w-4 h-4 text-emerald-500" /> BDT Withdrawal Payouts
              </div>
              <p className="text-slate-500 leading-relaxed">
                Manage personal creator and Page Owner withdrawal requests, transition payouts to Processing / Paid, and prevent over-withdrawal.
              </p>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] space-y-1">
              <div className="flex items-center gap-2 font-semibold text-rose-500">
                <ShieldAlert className="w-4 h-4 text-rose-500" /> Content Moderation &amp; Safety
              </div>
              <p className="text-slate-500 leading-relaxed">
                Triage user safety reports, remove violating posts or Spark videos in 1-click, and record permanent immutable audit logs.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const writeAdminLog = async (action: string, targetCollection: string, targetId: string, details: string) => {
    if (!firebaseUser) return;
    await setDoc(doc(db, 'adminLogs', makeSafeId('alog')), {
      adminUid: firebaseUser.uid,
      action: action.slice(0, 120),
      targetCollection: targetCollection.slice(0, 80),
      targetId: targetId.slice(0, 128),
      details: details.slice(0, 1000),
      createdAt: serverTimestamp(),
    });
  };

  const handleReviewCampaign = async (c: AdCampaign, approve: boolean) => {
    if (!firebaseUser || !isAdmin) return;
    setBusyAction(true);
    const customNote = (adNotes[c.id] || '').trim();
    const note =
      customNote ||
      (approve ? 'Verified and activated by Admin.' : 'Rejected during Admin review.');
    try {
      const matchingPay = adPayments.find((p) => p.campaignId === c.id);
      await updateDoc(doc(db, 'adCampaigns', c.id), {
        status: approve ? 'active' : 'rejected',
        paymentStatus: approve ? 'verified' : 'refunded',
        reviewNote: note.slice(0, 500),
        updatedAt: serverTimestamp(),
      });
      if (matchingPay) {
        await updateDoc(doc(db, 'adPayments', matchingPay.id), {
          status: approve ? 'verified' : 'rejected',
          verifiedBy: firebaseUser.uid,
          updatedAt: serverTimestamp(),
        });
      }
      await writeAdminLog(
        approve ? 'ad_campaign_approved' : 'ad_campaign_rejected',
        'adCampaigns',
        c.id,
        `Campaign "${c.title}" (${formatBDT(c.lifetimeBudgetPoisha)}): ${note}`
      );
      await createNotification({
        recipientUid: c.advertiserUid,
        actorUid: firebaseUser.uid,
        type: 'ad_review',
        title: approve ? 'Ad Campaign Activated' : 'Ad Campaign Rejected',
        body: approve
          ? `Your campaign "${c.title}" passed payment & policy review and is now active.`
          : `Your campaign "${c.title}" was rejected: ${note}`,
        targetTab: 'ads',
      });
      pushToast(approve ? 'Campaign verified & activated!' : 'Campaign rejected.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `adCampaigns/${c.id}`);
    } finally {
      setBusyAction(false);
    }
  };

  const handlePageMonetizationReview = async (app: PageAppItem, approve: boolean) => {
    if (!firebaseUser || !isAdmin) return;
    setBusyAction(true);
    const customNote = (appNotes[app.id] || '').trim();
    const note =
      customNote ||
      (approve
        ? 'Approved for 40/60 Page monetization.'
        : 'Does not meet originality/eligibility policy.');
    try {
      await updateDoc(doc(db, 'pageMonetizationApplications', app.id), {
        status: approve ? 'approved' : 'rejected',
        reviewedBy: firebaseUser.uid,
        reviewNote: note.slice(0, 500),
        updatedAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'pages', app.pageId), {
        monetizationStatus: approve ? 'approved' : 'not_eligible',
        updatedAt: serverTimestamp(),
      });
      await writeAdminLog(
        approve ? 'page_monetization_approved' : 'page_monetization_rejected',
        'pages',
        app.pageId,
        `Owner ${app.ownerUid}: ${note}`
      );
      await createNotification({
        recipientUid: app.ownerUid,
        actorUid: firebaseUser.uid,
        type: 'page_monetization_review',
        title: approve ? 'Page Monetization Approved' : 'Page Monetization Update',
        body: approve
          ? 'Your Public Page is now approved under the mandatory 40% Owner / 60% Platform split.'
          : `Your Page monetization application was declined: ${note}`,
        targetTab: 'pages',
      });
      pushToast(approve ? 'Page monetization approved!' : 'Application rejected.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `pages/${app.pageId}`);
    } finally {
      setBusyAction(false);
    }
  };

  const handleCreatorMonetizationReview = async (app: CreatorAppItem, approve: boolean) => {
    if (!firebaseUser || !isAdmin) return;
    setBusyAction(true);
    const customNote = (appNotes[app.id] || '').trim();
    const note =
      customNote ||
      (approve
        ? 'Approved for Personal Creator Pool monetization.'
        : 'Does not meet originality or policy requirements.');
    try {
      await updateDoc(doc(db, 'creatorMonetizationApplications', app.id), {
        status: approve ? 'approved' : 'rejected',
        reviewedBy: firebaseUser.uid,
        reviewNote: note.slice(0, 500),
        updatedAt: serverTimestamp(),
      });
      await updateDoc(doc(db, 'users', app.uid), {
        creatorMonetizationStatus: approve ? 'approved' : 'not_eligible',
        updatedAt: serverTimestamp(),
      });
      await writeAdminLog(
        approve ? 'creator_monetization_approved' : 'creator_monetization_rejected',
        'users',
        app.uid,
        `Creator app ${app.id}: ${note}`
      );
      await createNotification({
        recipientUid: app.uid,
        actorUid: firebaseUser.uid,
        type: 'creator_monetization_review',
        title: approve ? 'Creator Monetization Approved' : 'Creator Monetization Update',
        body: approve
          ? 'Your personal creator account is now approved for eligible creator pool payouts.'
          : `Your creator monetization application was declined: ${note}`,
        targetTab: 'profile',
      });
      pushToast(approve ? 'Creator monetization approved!' : 'Creator application declined.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${app.uid}`);
    } finally {
      setBusyAction(false);
    }
  };

  const handleSettle4060 = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !isAdmin || !settlePageId) return;
    setBusyAction(true);
    try {
      await settlePageRevenue4060({
        adminUid: firebaseUser.uid,
        pageId: settlePageId,
        grossPoisha: bdtToPoisha(grossBdt),
        deductionsPoisha: bdtToPoisha(deductionsBdt),
        ownerPercentBps: platformSettings.pageOwnerShareBps,
        platformPercentBps: platformSettings.platformShareBps,
        referenceNote: settleNote,
      });
      pushToast('40/60 Page revenue settled to Page Owner Wallet!', 'success');
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Settlement failed.', 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const handleRewardCreator = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !isAdmin || !rewardUid) return;
    const amountPoisha = bdtToPoisha(rewardBdt);
    if (amountPoisha <= 0) return;

    setBusyAction(true);
    const refId = makeSafeId('creward');
    try {
      await runTransaction(db, async (tx) => {
        const wRef = doc(db, 'wallets', rewardUid);
        const wSnap = await tx.get(wRef);
        if (!wSnap.exists()) {
          tx.set(wRef, {
            uid: rewardUid,
            pendingPoisha: 0,
            availablePoisha: amountPoisha,
            processingPoisha: 0,
            paidPoisha: 0,
            reversedPoisha: 0,
            updatedAt: serverTimestamp(),
          });
        } else {
          const cur = wSnap.data().availablePoisha || 0;
          tx.update(wRef, {
            availablePoisha: cur + amountPoisha,
            updatedAt: serverTimestamp(),
          });
        }

        tx.set(doc(db, 'ledgerEntries', refId), {
          uid: rewardUid,
          source: 'creator_reward',
          direction: 'credit',
          amountPoisha,
          referenceId: refId,
          note: rewardNote.trim().slice(0, 300),
          createdAt: serverTimestamp(),
        });
      });
      await writeAdminLog(
        'creator_reward_credited',
        'wallets',
        rewardUid,
        `Credited ${formatBDT(amountPoisha)}: ${rewardNote}`
      );
      await createNotification({
        recipientUid: rewardUid,
        actorUid: firebaseUser.uid,
        type: 'creator_reward',
        title: 'Creator Reward Credited',
        body: `You received ${formatBDT(amountPoisha)} in your Personal Creator Wallet.`,
        targetTab: 'wallet',
      });
      pushToast('Creator reward credited!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `wallets/${rewardUid}`);
    } finally {
      setBusyAction(false);
    }
  };

  const handleWithdrawalTransition = async (
    w: WithdrawalRequest,
    nextStatus: 'processing' | 'paid' | 'rejected' | 'reversed'
  ) => {
    if (!firebaseUser || !isAdmin) return;
    setBusyAction(true);
    const ledgerId = makeSafeId('wdlog');
    try {
      await runTransaction(db, async (tx) => {
        const reqRef = doc(db, 'withdrawalRequests', w.id);
        const reqSnap = await tx.get(reqRef);
        if (!reqSnap.exists()) throw new Error('Withdrawal request missing.');
        const curStatus = reqSnap.data().status as WithdrawalRequest['status'];
        if (!['pending', 'processing'].includes(curStatus)) {
          throw new Error('This withdrawal request is already finalized.');
        }

        const isPage = w.walletType === 'page' && Boolean(w.pageId);
        const walletRef = isPage ? doc(db, 'pageWallets', w.pageId!) : doc(db, 'wallets', w.uid);
        const wSnap = await tx.get(walletRef);
        if (!wSnap.exists()) throw new Error('Target wallet not found.');
        const wData = wSnap.data();

        let nextAvail = wData.availablePoisha || 0;
        let nextProc = wData.processingPoisha || 0;
        let nextPaid = wData.paidPoisha || 0;
        let nextRev = wData.reversedPoisha || 0;

        if (curStatus === 'pending' && nextStatus === 'processing') {
          if (nextAvail < w.amountPoisha) throw new Error('Insufficient available balance.');
          nextAvail -= w.amountPoisha;
          nextProc += w.amountPoisha;
        } else if (curStatus === 'pending' && nextStatus === 'paid') {
          if (nextAvail < w.amountPoisha) throw new Error('Insufficient available balance.');
          nextAvail -= w.amountPoisha;
          nextPaid += w.amountPoisha;
        } else if (curStatus === 'processing' && nextStatus === 'paid') {
          nextProc = Math.max(0, nextProc - w.amountPoisha);
          nextPaid += w.amountPoisha;
        } else if (curStatus === 'processing' && nextStatus === 'rejected') {
          nextProc = Math.max(0, nextProc - w.amountPoisha);
          nextAvail += w.amountPoisha;
        } else if (curStatus === 'processing' && nextStatus === 'reversed') {
          nextProc = Math.max(0, nextProc - w.amountPoisha);
          nextRev += w.amountPoisha;
          nextAvail += w.amountPoisha;
        }

        tx.update(walletRef, {
          availablePoisha: nextAvail,
          processingPoisha: nextProc,
          paidPoisha: nextPaid,
          reversedPoisha: nextRev,
          updatedAt: serverTimestamp(),
        });

        const customWdNote = (wdNotes[w.id] || '').trim();
        tx.update(reqRef, {
          status: nextStatus,
          reviewedBy: firebaseUser.uid,
          adminNote: (customWdNote || `Marked ${nextStatus} by Admin.`).slice(0, 300),
          updatedAt: serverTimestamp(),
        });

        if (isPage && w.pageId && nextStatus !== 'rejected') {
          const evt =
            nextStatus === 'processing'
              ? 'withdrawal_hold'
              : nextStatus === 'paid'
              ? 'withdrawal_paid'
              : 'withdrawal_reversed';
          tx.set(doc(db, 'pageLedgerEntries', ledgerId), {
            pageId: w.pageId,
            ownerUid: w.uid,
            eventType: evt,
            grossPoisha: 0,
            deductionsPoisha: 0,
            eligibleNetPoisha: 0,
            ownerShare40Poisha: w.amountPoisha,
            platformShare60Poisha: 0,
            ownerPercentBps: platformSettings.pageOwnerShareBps,
            platformPercentBps: platformSettings.platformShareBps,
            referenceId: w.id,
            createdAt: serverTimestamp(),
          });
        } else if (!isPage && (nextStatus === 'paid' || nextStatus === 'processing')) {
          if (curStatus === 'pending') {
            tx.set(doc(db, 'ledgerEntries', ledgerId), {
              uid: w.uid,
              source: 'withdrawal',
              direction: 'debit',
              amountPoisha: w.amountPoisha,
              referenceId: w.id,
              note: `${w.method.toUpperCase()} payout (${nextStatus})`,
              createdAt: serverTimestamp(),
            });
          }
        }
      });

      await writeAdminLog(
        `withdrawal_${nextStatus}`,
        'withdrawalRequests',
        w.id,
        `${w.walletType} withdrawal ${formatBDT(w.amountPoisha)} for ${w.uid}`
      );
      await createNotification({
        recipientUid: w.uid,
        actorUid: firebaseUser.uid,
        type: 'withdrawal_update',
        title: `Withdrawal ${nextStatus.toUpperCase()}`,
        body: `Your ${w.method.toUpperCase()} withdrawal request of ${formatBDT(w.amountPoisha)} is now ${nextStatus}.`,
        targetTab: 'wallet',
      });
      pushToast(`Withdrawal updated to ${nextStatus}.`, 'success');
    } catch (err) {
      pushToast(err instanceof Error ? err.message : 'Failed to update withdrawal.', 'error');
    } finally {
      setBusyAction(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !isSuperAdmin) return;
    if (videoAllocPct + postAllocPct + qualityAllocPct !== 100) {
      pushToast('Creator Pool allocations (Video + Post + Quality) must sum to 100%.', 'error');
      return;
    }
    const ownerBps = Math.round(ownerSharePct * 100);
    const platformBps = 10000 - ownerBps;
    if (ownerBps < 0 || ownerBps > 10000) {
      pushToast('Owner share must be between 0% and 100%.', 'error');
      return;
    }

    setBusyAction(true);
    try {
      await setDoc(doc(db, 'platformSettings', 'global'), {
        minWithdrawalPoisha: bdtToPoisha(Math.max(100, minWdBdt)),
        pageMinFollowers: Math.max(0, Math.round(pageMinFollowers)),
        pageMinAgeDays: Math.max(0, Math.round(pageMinAgeDays)),
        creatorMinFollowers: Math.max(0, Math.round(creatorMinFollowers)),
        creatorMinAgeDays: Math.max(0, Math.round(creatorMinAgeDays)),
        pageOwnerShareBps: ownerBps,
        platformShareBps: platformBps,
        creatorPoolBps: Math.round(creatorPoolPct * 100),
        creatorVideoAllocPct: Math.round(videoAllocPct),
        creatorPostAllocPct: Math.round(postAllocPct),
        creatorQualityAllocPct: Math.round(qualityAllocPct),
        updatedBy: firebaseUser.uid,
        updatedAt: serverTimestamp(),
      });
      await writeAdminLog(
        'platform_settings_updated',
        'platformSettings',
        'global',
        `Owner ${ownerSharePct}% / Platform ${100 - ownerSharePct}%, MinWd ৳${minWdBdt}`
      );
      pushToast('Platform financial rules saved.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'platformSettings/global');
    } finally {
      setBusyAction(false);
    }
  };

  const handleAssignRole = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !isSuperAdmin || !roleTargetUid.trim()) return;
    const uid = roleTargetUid.trim();
    setBusyAction(true);
    try {
      const userSnap = await getDoc(doc(db, 'users', uid));
      if (!userSnap.exists()) {
        pushToast('User UID not found.', 'error');
        setBusyAction(false);
        return;
      }

      if (roleValue === 'user') {
        await deleteDoc(doc(db, 'admins', uid));
      } else {
        await setDoc(doc(db, 'admins', uid), {
          uid,
          role: roleValue,
          createdAt: serverTimestamp(),
        });
      }
      await updateDoc(doc(db, 'users', uid), {
        role: roleValue,
        updatedAt: serverTimestamp(),
      });
      await writeAdminLog('role_assigned', 'admins', uid, `Assigned role: ${roleValue}`);
      setRoleTargetUid('');
      pushToast(`Assigned role "${roleValue}" to ${uid}.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `admins/${uid}`);
    } finally {
      setBusyAction(false);
    }
  };

  const previewSplit = calculatePageRevenueSplit(
    bdtToPoisha(grossBdt),
    bdtToPoisha(deductionsBdt),
    platformSettings.pageOwnerShareBps,
    platformSettings.platformShareBps
  );

  const pendingCampaigns = campaigns.filter((c) => c.status === 'pending_review');
  const activeAds = campaigns.filter((c) => c.status === 'active');
  const verifiedAdSpendPoisha = campaigns.reduce((sum, c) => sum + (c.spentPoisha || 0), 0);
  const totalAdImps = campaigns.reduce((sum, c) => sum + (c.paidImpressions || 0), 0);
  const totalAdClicks = campaigns.reduce((sum, c) => sum + (c.clicks || 0), 0);
  const platformCtr = totalAdImps > 0 ? ((totalAdClicks / totalAdImps) * 100).toFixed(2) : '0.00';
  const filteredCampaigns =
    adFilter === 'all' ? campaigns : campaigns.filter((c) => c.status === adFilter);
  const filteredReports =
    reportFilter === 'all' ? reports : reports.filter((r) => r.status === reportFilter);

  const pendingWithdrawals = withdrawals.filter((w) => ['pending', 'processing'].includes(w.status));
  const openReports = reports.filter((r) => r.status === 'open');
  const approvedPages = pages.filter((p) => p.monetizationStatus === 'approved');
  const approvedCreators = users.filter((u) => u.creatorMonetizationStatus === 'approved');

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-bold flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#D4AF37]" />
            HEARTHLINE Admin &amp; Governance
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Role-protected operations, ad payment verification, 40/60 Page Owner revenue settlement, payouts, and audit logs.
          </p>
        </div>
        <span className="px-3 py-1 rounded-lg bg-[#D4AF37]/15 text-[#D4AF37] text-xs font-semibold uppercase">
          {isSuperAdmin ? 'Super Admin' : isAdmin ? 'Admin' : 'Moderator'}
        </span>
      </div>

      {/* Admin Sub-tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'overview', label: 'Overview' },
          ...(isAdmin
            ? [
                { id: 'ads', label: `Ad Reviews (${pendingCampaigns.length})` },
                { id: 'monetization', label: 'Monetization & 40/60' },
                { id: 'withdrawals', label: `Withdrawals (${pendingWithdrawals.length})` },
              ]
            : []),
          { id: 'moderation', label: `Moderation (${openReports.length})` },
          ...(isSuperAdmin ? [{ id: 'settings', label: 'Super Admin Rules' }] : []),
        ].map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id as typeof tab)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer ${
              tab === t.id
                ? 'bg-[#D4AF37] text-[#0A0B0E]'
                : 'border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-slate-600 dark:text-slate-300'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* OVERVIEW */}
      {tab === 'overview' && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
              <p className="text-xs text-slate-500">Total Users</p>
              <p className="font-mono tabular-nums text-2xl font-bold mt-1">{users.length}</p>
            </div>
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
              <p className="text-xs text-slate-500">Public Pages</p>
              <p className="font-mono tabular-nums text-2xl font-bold mt-1">{pages.length}</p>
            </div>
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
              <p className="text-xs text-slate-500">Posts &amp; Spark</p>
              <p className="font-mono tabular-nums text-2xl font-bold mt-1">
                {postsCount} / {sparksCount}
              </p>
            </div>
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
              <p className="text-xs text-slate-500">Open Reports</p>
              <p className="font-mono tabular-nums text-2xl font-bold text-amber-500 mt-1">
                {openReports.length}
              </p>
            </div>
          </div>

          {isAdmin && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
                <p className="text-xs text-slate-500">Active Ad Campaigns</p>
                <p className="font-mono tabular-nums text-xl font-bold text-emerald-500 mt-1">
                  {activeAds.length}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
                <p className="text-xs text-slate-500">Verified Ad Spend</p>
                <p className="font-mono tabular-nums text-xl font-bold text-[#D4AF37] mt-1">
                  {formatBDT(verifiedAdSpendPoisha)}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
                <p className="text-xs text-slate-500">Ad Impressions / Clicks</p>
                <p className="font-mono tabular-nums text-xl font-bold mt-1">
                  {totalAdImps} / {totalAdClicks}
                </p>
              </div>
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
                <p className="text-xs text-slate-500">Platform Avg CTR</p>
                <p className="font-mono tabular-nums text-xl font-bold text-[#3B82F6] mt-1">
                  {platformCtr}%
                </p>
              </div>
            </div>
          )}

          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
            <h2 className="font-display font-bold text-sm flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#D4AF37]" /> Immutable Admin Audit Logs
            </h2>
            {logs.length === 0 ? (
              <p className="text-xs text-slate-500">No admin audit logs recorded yet.</p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-white/5 text-xs max-h-80 overflow-y-auto">
                {logs.map((l) => (
                  <div key={l.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-white">
                        {l.action}{' '}
                        <span className="font-mono text-[11px] text-[#3B82F6]">
                          [{l.targetCollection}/{l.targetId}]
                        </span>
                      </p>
                      <p className="text-slate-500">{l.details}</p>
                    </div>
                    <span className="text-[11px] font-mono text-slate-400">
                      by {l.adminUid.slice(0, 8)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ADS & PAYMENTS REVIEW */}
      {tab === 'ads' && isAdmin && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="font-display font-bold text-base flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-[#D4AF37]" /> Ad Campaign &amp; Payment Verification
            </h2>
            <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
              {(
                [
                  ['all', 'All'],
                  ['pending_review', 'Pending Review'],
                  ['active', 'Active'],
                  ['paused', 'Paused'],
                  ['completed', 'Completed'],
                  ['rejected', 'Rejected'],
                ] as const
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setAdFilter(id)}
                  className={`px-2.5 py-1 rounded-lg font-semibold cursor-pointer ${
                    adFilter === id
                      ? 'bg-[#D4AF37] text-[#0A0B0E]'
                      : 'bg-slate-100 dark:bg-white/5 text-slate-500'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {filteredCampaigns.length === 0 ? (
            <p className="text-xs text-slate-500">No ad campaigns match this filter.</p>
          ) : (
            <div className="space-y-3">
              {filteredCampaigns.map((c) => {
                const pay = adPayments.find((p) => p.campaignId === c.id);
                const ctr =
                  c.paidImpressions > 0
                    ? ((c.clicks / c.paidImpressions) * 100).toFixed(2)
                    : '0.00';
                const safeDest = sanitizeExternalUrl(c.targetUrl);
                const isVid =
                  Boolean(c.creativeMediaUrl) &&
                  /\.(mp4|webm|mov|m4v)(\?|$)|\/video\/upload\//i.test(c.creativeMediaUrl || '');

                return (
                  <div
                    key={c.id}
                    className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-4 space-y-3 text-xs"
                  >
                    <div className="flex flex-wrap items-start justify-between gap-4">
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        {c.creativeMediaUrl && (
                          isVid ? (
                            <video
                              src={c.creativeMediaUrl}
                              muted
                              playsInline
                              className="w-16 h-16 rounded-lg object-cover bg-black shrink-0"
                            />
                          ) : (
                            <img
                              src={c.creativeMediaUrl}
                              alt={c.title}
                              loading="lazy"
                              referrerPolicy="no-referrer"
                              className="w-16 h-16 rounded-lg object-cover bg-black/20 shrink-0"
                            />
                          )
                        )}
                        <div className="space-y-1 min-w-0">
                          <p className="font-semibold text-sm text-slate-900 dark:text-white">{c.title}</p>
                          <p className="text-slate-500">
                            Advertiser: <span className="font-mono">{c.advertiserUid}</span> · Budget:{' '}
                            <strong className="font-mono text-[#D4AF37]">
                              {formatBDT(c.spentPoisha)} / {formatBDT(c.lifetimeBudgetPoisha)}
                            </strong>{' '}
                            · Status: <strong className="uppercase">{c.status}</strong>
                          </p>
                          <p className="text-slate-500">
                            Objective: {c.objective.replace(/_/g, ' ')} · Target: {c.targetCity || c.targetCountry || 'Global'} · Imps {c.paidImpressions} · Clicks {c.clicks} · CTR {ctr}%
                          </p>
                          {c.creativeText && (
                            <p className="text-slate-600 dark:text-slate-300 line-clamp-2">{c.creativeText}</p>
                          )}
                          {safeDest && (
                            <p className="text-[11px] text-[#3B82F6] truncate">Destination: {safeDest}</p>
                          )}
                          {pay && (
                            <p className="text-[#3B82F6]">
                              Payment: {pay.method.toUpperCase()} Ref{' '}
                              <span className="font-mono font-bold">{pay.transactionRef}</span> ({pay.status})
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        {c.status === 'pending_review' && (
                          <>
                            <button
                              type="button"
                              disabled={busyAction}
                              onClick={() => handleReviewCampaign(c, true)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-emerald-500 text-white font-semibold cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" /> Verify &amp; Activate
                            </button>
                            <button
                              type="button"
                              disabled={busyAction}
                              onClick={() => handleReviewCampaign(c, false)}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-500 text-white font-semibold cursor-pointer"
                            >
                              <XCircle className="w-3.5 h-3.5" /> Reject
                            </button>
                          </>
                        )}
                        {c.status === 'active' && (
                          <button
                            type="button"
                            onClick={async () => {
                              await updateDoc(doc(db, 'adCampaigns', c.id), {
                                status: 'paused',
                                updatedAt: serverTimestamp(),
                              });
                              await writeAdminLog('ad_paused_admin', 'adCampaigns', c.id, 'Paused by Admin');
                              pushToast('Campaign paused.', 'info');
                            }}
                            className="px-3 py-1.5 rounded-xl border border-amber-500/40 text-amber-500 font-semibold cursor-pointer"
                          >
                            Pause Ad
                          </button>
                        )}
                        {c.status === 'paused' && c.paymentStatus === 'verified' && (
                          <button
                            type="button"
                            onClick={async () => {
                              await updateDoc(doc(db, 'adCampaigns', c.id), {
                                status: 'active',
                                updatedAt: serverTimestamp(),
                              });
                              await writeAdminLog('ad_resumed_admin', 'adCampaigns', c.id, 'Resumed by Admin');
                              pushToast('Campaign resumed.', 'success');
                            }}
                            className="px-3 py-1.5 rounded-xl border border-emerald-500/40 text-emerald-500 font-semibold cursor-pointer"
                          >
                            Resume Ad
                          </button>
                        )}
                      </div>
                    </div>

                    {c.status === 'pending_review' && (
                      <input
                        type="text"
                        value={adNotes[c.id] || ''}
                        onChange={(e) => setAdNotes((prev) => ({ ...prev, [c.id]: e.target.value }))}
                        placeholder="Optional review note to send to advertiser..."
                        className="w-full h-8 px-3 rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-xs"
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* MONETIZATION & 40/60 PAGE SETTLEMENT */}
      {tab === 'monetization' && isAdmin && (
        <div className="space-y-6">
          {/* Mandatory 40/60 Page Settlement Tool */}
          <div className="rounded-2xl border border-[#D4AF37]/30 bg-white dark:bg-[#13151B] p-6 space-y-4">
            <div>
              <h2 className="font-display font-bold text-base flex items-center gap-2">
                <Coins className="w-5 h-5 text-[#D4AF37]" /> Settle Verified Page Ad Revenue (40/60 Rule)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Credits {platformSettings.pageOwnerShareBps / 100}% strictly to the verified Page Owner&apos;s Page Wallet and allocates{' '}
                {platformSettings.platformShareBps / 100}% to HEARTHLINE.
              </p>
            </div>

            {approvedPages.length === 0 ? (
              <p className="text-xs text-amber-500">
                No approved monetized Pages yet. Approve a Page monetization application below first.
              </p>
            ) : (
              <form onSubmit={handleSettle4060} className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-500 mb-1">Approved Public Page</label>
                  <select
                    value={settlePageId}
                    onChange={(e) => setSettlePageId(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                  >
                    {approvedPages.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} (Owner: {p.ownerUid.slice(0, 8)})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Settlement Reference Note</label>
                  <input
                    type="text"
                    required
                    value={settleNote}
                    onChange={(e) => setSettleNote(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Verified Collected Gross (BDT ৳)</label>
                  <input
                    type="number"
                    min={1}
                    value={grossBdt}
                    onChange={(e) => setGrossBdt(Number(e.target.value))}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono tabular-nums"
                  />
                </div>
                <div>
                  <label className="block text-slate-500 mb-1">Documented Deductions (Fees/Taxes ৳)</label>
                  <input
                    type="number"
                    min={0}
                    value={deductionsBdt}
                    onChange={(e) => setDeductionsBdt(Number(e.target.value))}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono tabular-nums"
                  />
                </div>

                <div className="sm:col-span-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-3 flex flex-wrap items-center justify-between gap-3 font-mono tabular-nums">
                  <span>Eligible Net: {formatBDT(previewSplit.eligibleNetPoisha)}</span>
                  <span className="text-[#D4AF37] font-bold">
                    Owner {platformSettings.pageOwnerShareBps / 100}%: {formatBDT(previewSplit.ownerSharePoisha)}
                  </span>
                  <span>
                    Platform {platformSettings.platformShareBps / 100}%: {formatBDT(previewSplit.platformSharePoisha)}
                  </span>
                </div>

                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    disabled={busyAction || previewSplit.eligibleNetPoisha <= 0}
                    className="px-5 h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer disabled:opacity-45"
                  >
                    Execute Atomic 40/60 Settlement
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Creator Reward Distribution */}
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4">
            <h2 className="font-display font-bold text-base">Personal Creator Pool Reward Distribution</h2>
            {approvedCreators.length === 0 ? (
              <p className="text-xs text-slate-500">No approved creators yet.</p>
            ) : (
              <form onSubmit={handleRewardCreator} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <select
                  value={rewardUid}
                  onChange={(e) => setRewardUid(e.target.value)}
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                >
                  <option value="">Select Approved Creator</option>
                  {approvedCreators.map((u) => (
                    <option key={u.uid} value={u.uid}>
                      {u.displayName} (@{u.username})
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  min={10}
                  value={rewardBdt}
                  onChange={(e) => setRewardBdt(Number(e.target.value))}
                  placeholder="Amount BDT"
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
                <input
                  type="text"
                  value={rewardNote}
                  onChange={(e) => setRewardNote(e.target.value)}
                  placeholder="Pool period note"
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                />
                <div className="sm:col-span-3">
                  <button
                    type="submit"
                    disabled={busyAction || !rewardUid}
                    className="px-5 h-10 rounded-xl bg-[#3B82F6] text-white font-semibold cursor-pointer disabled:opacity-45"
                  >
                    Credit Creator Wallet
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Applications Lists */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
              <h3 className="font-display font-bold text-sm">Page Monetization Applications</h3>
              {pageApps.length === 0 ? (
                <p className="text-xs text-slate-500">No applications yet.</p>
              ) : (
                <div className="space-y-2.5 text-xs">
                  {pageApps.map((a) => {
                    const pg = pages.find((p) => p.id === a.pageId);
                    return (
                      <div
                        key={a.id}
                        className="p-3 rounded-xl border border-slate-200 dark:border-white/10 space-y-2"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div>
                            <p className="font-semibold">
                              {pg ? `${pg.name} (@${pg.username})` : `Page: ${a.pageId}`}
                            </p>
                            <p className="text-slate-500">
                              {a.followersCount} followers · {a.pageAgeDays} days ·{' '}
                              <span className="capitalize font-medium text-[#D4AF37]">{a.status}</span>
                            </p>
                          </div>
                          {a.status === 'pending' && (
                            <div className="flex gap-1.5">
                              <button
                                disabled={busyAction}
                                onClick={() => handlePageMonetizationReview(a, true)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-500 text-white font-semibold cursor-pointer"
                              >
                                Approve
                              </button>
                              <button
                                disabled={busyAction}
                                onClick={() => handlePageMonetizationReview(a, false)}
                                className="px-2.5 py-1 rounded-lg bg-rose-500 text-white font-semibold cursor-pointer"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                        </div>
                        {a.status === 'pending' && (
                          <input
                            type="text"
                            value={appNotes[a.id] || ''}
                            onChange={(e) => setAppNotes((prev) => ({ ...prev, [a.id]: e.target.value }))}
                            placeholder="Optional review note..."
                            className="w-full h-8 px-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
                          />
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
              <h3 className="font-display font-bold text-sm">Creator Monetization Applications</h3>
              {creatorApps.length === 0 ? (
                <p className="text-xs text-slate-500">No applications yet.</p>
              ) : (
                <div className="space-y-2.5 text-xs">
                  {creatorApps.map((a) => {
                    const applicant = users.find((u) => u.uid === a.uid);
                    return (
                      <div
                        key={a.id}
                        className="p-3 rounded-xl border border-slate-200 dark:border-white/10 space-y-2"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div>
                            <p className="font-semibold">
                              {applicant ? `${applicant.displayName} (@${applicant.username})` : a.uid}
                            </p>
                            <p className="text-slate-500">
                              {a.followersCount} followers · {a.accountAgeDays} days ·{' '}
                              <span className="capitalize font-medium text-[#D4AF37]">{a.status}</span>
                            </p>
                          </div>
                          {a.status === 'pending' && (
                            <div className="flex gap-1.5">
                              <button
                                disabled={busyAction}
                                onClick={() => handleCreatorMonetizationReview(a, true)}
                                className="px-2.5 py-1 rounded-lg bg-emerald-500 text-white font-semibold cursor-pointer"
                              >
                                Approve
                              </button>
                              <button
                                disabled={busyAction}
                                onClick={() => handleCreatorMonetizationReview(a, false)}
                                className="px-2.5 py-1 rounded-lg bg-rose-500 text-white font-semibold cursor-pointer"
                              >
                                Reject
                              </button>
                            </div>
                          )}
                        </div>
                        {a.status === 'pending' && (
                          <input
                            type="text"
                            value={appNotes[a.id] || ''}
                            onChange={(e) => setAppNotes((prev) => ({ ...prev, [a.id]: e.target.value }))}
                            placeholder="Optional review note..."
                            className="w-full h-8 px-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
                          />
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* WITHDRAWALS */}
      {tab === 'withdrawals' && isAdmin && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4">
          <h2 className="font-display font-bold text-base flex items-center gap-2">
            <Wallet className="w-5 h-5 text-[#D4AF37]" /> Withdrawal Verification Queue
          </h2>
          {withdrawals.length === 0 ? (
            <p className="text-xs text-slate-500">No withdrawal requests submitted yet.</p>
          ) : (
            <div className="space-y-3">
              {withdrawals.map((w) => {
                const pg = w.pageId ? pages.find((p) => p.id === w.pageId) : undefined;
                const applicant = users.find((u) => u.uid === w.uid);
                return (
                  <div
                    key={w.id}
                    className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-4 space-y-2.5 text-xs"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div>
                        <p className="font-semibold text-sm font-mono tabular-nums">
                          {formatBDT(w.amountPoisha)} via {w.method.toUpperCase()} ({w.accountNumberMasked})
                        </p>
                        <p className="text-slate-500">
                          {w.accountTitle}
                          {applicant ? ` (@${applicant.username})` : ''} ·{' '}
                          {w.walletType === 'page'
                            ? `Page: ${pg?.name || w.pageId}`
                            : 'Personal Creator Wallet'}{' '}
                          · Status: <strong className="uppercase text-[#D4AF37]">{w.status}</strong>
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {w.status === 'pending' && (
                          <>
                            <button
                              disabled={busyAction}
                              onClick={() => handleWithdrawalTransition(w, 'processing')}
                              className="px-3 py-1.5 rounded-xl bg-[#3B82F6] text-white font-semibold cursor-pointer"
                            >
                              Mark Processing
                            </button>
                            <button
                              disabled={busyAction}
                              onClick={() => handleWithdrawalTransition(w, 'paid')}
                              className="px-3 py-1.5 rounded-xl bg-emerald-500 text-white font-semibold cursor-pointer"
                            >
                              Mark Paid
                            </button>
                            <button
                              disabled={busyAction}
                              onClick={() => handleWithdrawalTransition(w, 'rejected')}
                              className="px-3 py-1.5 rounded-xl bg-rose-500 text-white font-semibold cursor-pointer"
                            >
                              Reject
                            </button>
                          </>
                        )}
                        {w.status === 'processing' && (
                          <>
                            <button
                              disabled={busyAction}
                              onClick={() => handleWithdrawalTransition(w, 'paid')}
                              className="px-3 py-1.5 rounded-xl bg-emerald-500 text-white font-semibold cursor-pointer"
                            >
                              Confirm Paid
                            </button>
                            <button
                              disabled={busyAction}
                              onClick={() => handleWithdrawalTransition(w, 'reversed')}
                              className="px-3 py-1.5 rounded-xl bg-amber-500 text-[#0A0B0E] font-semibold cursor-pointer"
                            >
                              Reverse to Wallet
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                    {(w.status === 'pending' || w.status === 'processing') && (
                      <input
                        type="text"
                        value={wdNotes[w.id] || ''}
                        onChange={(e) => setWdNotes((prev) => ({ ...prev, [w.id]: e.target.value }))}
                        placeholder="Optional payout reference / admin note..."
                        className="w-full h-8 px-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-xs"
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* MODERATION & USERS */}
      {tab === 'moderation' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display font-bold text-sm flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" /> Safety Reports
              </h2>
              <div className="flex items-center gap-1 text-[11px]">
                {(['all', 'open', 'resolved', 'dismissed'] as const).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setReportFilter(st)}
                    className={`px-2 py-0.5 rounded-md font-semibold capitalize cursor-pointer ${
                      reportFilter === st
                        ? 'bg-[#D4AF37] text-[#0A0B0E]'
                        : 'bg-slate-100 dark:bg-white/5 text-slate-500'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>
            {filteredReports.length === 0 ? (
              <p className="text-xs text-slate-500">No reports match this filter.</p>
            ) : (
              <div className="space-y-2.5 text-xs">
                {filteredReports.map((r) => (
                  <div
                    key={r.id}
                    className="p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold uppercase text-[#D4AF37]">
                        {r.targetType} · {r.targetId}
                      </span>
                      <span className="capitalize text-slate-400">{r.status}</span>
                    </div>
                    <p>{r.reason}</p>
                    {r.details && <p className="text-slate-500">{r.details}</p>}
                    {r.status === 'open' && (
                      <div className="flex flex-wrap gap-2">
                        {(r.targetType === 'post' || r.targetType === 'video') && (
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                const col = r.targetType === 'post' ? 'posts' : 'sparkVideos';
                                await deleteDoc(doc(db, col, r.targetId));
                                await updateDoc(doc(db, 'reports', r.id), {
                                  status: 'resolved',
                                  resolvedBy: firebaseUser!.uid,
                                  updatedAt: serverTimestamp(),
                                });
                                await writeAdminLog(
                                  `moderated_delete_${r.targetType}`,
                                  col,
                                  r.targetId,
                                  `Removed per report ${r.id}: ${r.reason}`
                                );
                                pushToast(`Reported ${r.targetType} deleted & report resolved.`, 'success');
                              } catch (err) {
                                handleFirestoreError(err, OperationType.DELETE, r.targetId);
                              }
                            }}
                            className="px-2.5 py-1 rounded-lg bg-rose-500 text-white font-semibold cursor-pointer"
                          >
                            Remove Content
                          </button>
                        )}
                        <button
                          onClick={async () => {
                            await updateDoc(doc(db, 'reports', r.id), {
                              status: 'resolved',
                              resolvedBy: firebaseUser!.uid,
                              updatedAt: serverTimestamp(),
                            });
                            await writeAdminLog('report_resolved', 'reports', r.id, r.reason);
                            pushToast('Report resolved.', 'success');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500 text-white font-semibold cursor-pointer"
                        >
                          Resolve
                        </button>
                        <button
                          onClick={async () => {
                            await updateDoc(doc(db, 'reports', r.id), {
                              status: 'dismissed',
                              resolvedBy: firebaseUser!.uid,
                              updatedAt: serverTimestamp(),
                            });
                            await writeAdminLog('report_dismissed', 'reports', r.id, r.reason);
                            pushToast('Report dismissed.', 'info');
                          }}
                          className="px-2.5 py-1 rounded-lg border border-slate-300 dark:border-white/15 cursor-pointer"
                        >
                          Dismiss
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
            <h2 className="font-display font-bold text-sm flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#3B82F6]" /> User Account Controls
            </h2>
            <div className="divide-y divide-slate-100 dark:divide-white/5 text-xs max-h-[420px] overflow-y-auto">
              {users.map((u) => (
                <div key={u.uid} className="py-2.5 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-semibold truncate">
                      {u.displayName} (@{u.username})
                    </p>
                    <p className="text-slate-500 font-mono text-[11px] truncate">
                      {u.uid} · {u.role} · {u.accountStatus}
                    </p>
                  </div>
                  {isAdmin && u.uid !== firebaseUser?.uid && (
                    <button
                      onClick={async () => {
                        const next = u.accountStatus === 'suspended' ? 'active' : 'suspended';
                        await updateDoc(doc(db, 'users', u.uid), {
                          accountStatus: next,
                          updatedAt: serverTimestamp(),
                        });
                        await writeAdminLog(`user_${next}`, 'users', u.uid, `Status changed to ${next}`);
                        pushToast(`User ${next}.`, 'info');
                      }}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-semibold cursor-pointer ${
                        u.accountStatus === 'suspended'
                          ? 'bg-emerald-500/15 text-emerald-500'
                          : 'bg-rose-500/15 text-rose-500'
                      }`}
                    >
                      <Ban className="w-3 h-3" />
                      {u.accountStatus === 'suspended' ? 'Reactivate' : 'Suspend'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* SUPER ADMIN FINANCIAL RULES & FEATURE FLAGS */}
      {tab === 'settings' && isSuperAdmin && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <form
            onSubmit={handleSaveSettings}
            className="rounded-2xl border border-[#D4AF37]/30 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs"
          >
            <h2 className="font-display font-bold text-base flex items-center gap-2">
              <Sliders className="w-5 h-5 text-[#D4AF37]" /> Revenue Share &amp; Eligibility Policies
            </h2>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-500 mb-1">Page Owner Share (%)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={ownerSharePct}
                  onChange={(e) => setOwnerSharePct(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">HEARTHLINE Platform Share (%)</label>
                <input
                  type="number"
                  readOnly
                  value={100 - ownerSharePct}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-black/30 font-mono text-slate-400"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">Min Withdrawal (BDT ৳)</label>
                <input
                  type="number"
                  min={100}
                  value={minWdBdt}
                  onChange={(e) => setMinWdBdt(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">Creator Pool (%)</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={creatorPoolPct}
                  onChange={(e) => setCreatorPoolPct(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">Page Min Followers</label>
                <input
                  type="number"
                  min={0}
                  value={pageMinFollowers}
                  onChange={(e) => setPageMinFollowers(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">Page Min Age (Days)</label>
                <input
                  type="number"
                  min={0}
                  value={pageMinAgeDays}
                  onChange={(e) => setPageMinAgeDays(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">Creator Min Followers</label>
                <input
                  type="number"
                  min={0}
                  value={creatorMinFollowers}
                  onChange={(e) => setCreatorMinFollowers(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">Creator Min Age (Days)</label>
                <input
                  type="number"
                  min={0}
                  value={creatorMinAgeDays}
                  onChange={(e) => setCreatorMinAgeDays(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-slate-500 mb-1">Video %</label>
                <input
                  type="number"
                  value={videoAllocPct}
                  onChange={(e) => setVideoAllocPct(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">Post %</label>
                <input
                  type="number"
                  value={postAllocPct}
                  onChange={(e) => setPostAllocPct(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
              <div>
                <label className="block text-slate-500 mb-1">Quality %</label>
                <input
                  type="number"
                  value={qualityAllocPct}
                  onChange={(e) => setQualityAllocPct(Number(e.target.value))}
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={busyAction}
              className="px-5 h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
            >
              Save Platform Settings
            </button>
          </form>

          <div className="space-y-5">
            <form
              onSubmit={handleAssignRole}
              className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-3 text-xs"
            >
              <h3 className="font-display font-bold text-sm">Assign Moderator / Admin Role</h3>
              <input
                type="text"
                required
                value={roleTargetUid}
                onChange={(e) => setRoleTargetUid(e.target.value)}
                placeholder="Target User UID"
                className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
              />
              <select
                value={roleValue}
                onChange={(e) => setRoleValue(e.target.value as UserRole)}
                className="w-full h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              >
                <option value="moderator">Moderator</option>
                <option value="admin">Admin</option>
                <option value="super_admin">Super Admin</option>
                <option value="user">Revoke to Standard User</option>
              </select>
              <button
                type="submit"
                disabled={busyAction}
                className="px-4 h-9 rounded-xl bg-[#3B82F6] text-white font-semibold cursor-pointer"
              >
                Update Staff Role
              </button>
            </form>

            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-2.5 text-xs">
              <h3 className="font-display font-bold text-sm">V1 Feature Flags (Postponed Scope Guard)</h3>
              <div className="grid grid-cols-2 gap-2 text-slate-500">
                {[
                  ['Live Streaming', featureFlags.liveStreamingEnabled],
                  ['Marketplace', featureFlags.marketplaceEnabled],
                  ['Voice Calls', featureFlags.voiceCallsEnabled],
                  ['Video Calls', featureFlags.videoCallsEnabled],
                  ['Creator Gifts', featureFlags.creatorGiftsEnabled],
                  ['Creator Coins', featureFlags.creatorCoinsEnabled],
                  ['AI Assistant', featureFlags.aiAssistantEnabled],
                ].map(([label, enabled]) => (
                  <div
                    key={String(label)}
                    className="flex items-center justify-between px-3 py-2 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                  >
                    <span>{label}</span>
                    <span className="font-mono text-[11px] font-semibold">
                      {enabled ? 'ON' : 'OFF (V1)'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
