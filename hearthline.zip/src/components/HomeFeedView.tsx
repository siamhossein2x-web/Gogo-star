import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  increment,
  limit,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  BookmarkPlus,
  ChevronLeft,
  ChevronRight,
  Eye,
  Film,
  Image as ImageIcon,
  Plus,
  Send,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  AdCampaign,
  Post,
  PublicPage,
  Story,
  StoryViewRecord,
  UserProfile,
} from '../types/hearthline';
import { useAuth, createNotification } from '../context/AuthContext';
import { useT } from '../i18n/translations';
import { Avatar } from './Avatar';
import { PostCard } from './PostCard';
import { BoostPostModal } from './BoostPostModal';
import { SuggestedPostsSection } from './SuggestedPostsSection';
import { isStoryActive } from '../lib/socialActions';
import { rankSuggestedPosts } from '../lib/feedRanking';
import { useToast } from './Toast';

interface HomeFeedProps {
  onOpenProfile: (uid: string) => void;
  onOpenUpload: (mode: 'post' | 'story' | 'spark') => void;
  onOpenPages?: () => void;
}

export const HomeFeedView: React.FC<HomeFeedProps> = ({
  onOpenProfile,
  onOpenUpload,
  onOpenPages,
}) => {
  const { firebaseUser, profile, language } = useAuth();
  const t = useT(language);
  const { pushToast } = useToast();

  const loadedUidsRef = useRef<Set<string>>(new Set());
  const loadedPagesRef = useRef<Set<string>>(new Set());

  const [filter, setFilter] = useState<'for_you' | 'friends' | 'following' | 'latest'>('for_you');
  const [posts, setPosts] = useState<Post[]>([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [usersMap, setUsersMap] = useState<Record<string, UserProfile>>({});
  const [pagesMap, setPagesMap] = useState<Record<string, PublicPage>>({});
  const [friendsA, setFriendsA] = useState<string[]>([]);
  const [friendsB, setFriendsB] = useState<string[]>([]);
  const [followingUids, setFollowingUids] = useState<Set<string>>(new Set());
  const [hiddenPostIds, setHiddenPostIds] = useState<Set<string>>(new Set());

  const [stories, setStories] = useState<Story[]>([]);
  const [activeStoryIndex, setActiveStoryIndex] = useState<number | null>(null);
  const [storyReplyText, setStoryReplyText] = useState('');
  const [myStoryReaction, setMyStoryReaction] = useState<string | null>(null);
  const [storyViews, setStoryViews] = useState<StoryViewRecord[]>([]);
  const [showViewersList, setShowViewersList] = useState(false);

  const [activeCampaigns, setActiveCampaigns] = useState<AdCampaign[]>([]);
  const [boostTarget, setBoostTarget] = useState<Post | null>(null);
  const [highlightedPostId, setHighlightedPostId] = useState<string | null>(null);
  const highlightTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (highlightTimerRef.current !== null) {
        window.clearTimeout(highlightTimerRef.current);
      }
    };
  }, []);

  const friendUids = useMemo(() => new Set([...friendsA, ...friendsB]), [friendsA, friendsB]);

  const visibleStories = useMemo(
    () =>
      stories.filter(
        (st) =>
          st.privacy === 'public' ||
          st.authorUid === firebaseUser?.uid ||
          friendUids.has(st.authorUid)
      ),
    [stories, firebaseUser?.uid, friendUids]
  );

  const activeStory =
    activeStoryIndex !== null && visibleStories[activeStoryIndex]
      ? visibleStories[activeStoryIndex]
      : null;

  useEffect(() => {
    if (!firebaseUser) return;

    let publicPosts: Post[] = [];
    let myPosts: Post[] = [];
    let gotPublic = false;
    let gotMine = false;

    const hydrateAuthorsAndPages = async (uids: string[], pageIds: string[]) => {
      const missingUids = uids.filter((u) => u && !loadedUidsRef.current.has(u));
      const missingPages = pageIds.filter((pid) => pid && !loadedPagesRef.current.has(pid));

      if (missingUids.length > 0) {
        missingUids.forEach((u) => loadedUidsRef.current.add(u));
        const loadedUsers: Record<string, UserProfile> = {};
        await Promise.all(
          missingUids.map(async (u) => {
            try {
              const s = await getDoc(doc(db, 'users', u));
              if (s.exists()) loadedUsers[u] = s.data() as UserProfile;
            } catch {
              // ignore deactivated/inaccessible author
            }
          })
        );
        if (Object.keys(loadedUsers).length > 0) {
          setUsersMap((prev) => ({ ...prev, ...loadedUsers }));
        }
      }

      if (missingPages.length > 0) {
        missingPages.forEach((pid) => loadedPagesRef.current.add(pid));
        const loadedPages: Record<string, PublicPage> = {};
        await Promise.all(
          missingPages.map(async (pid) => {
            try {
              const s = await getDoc(doc(db, 'pages', pid));
              if (s.exists()) loadedPages[pid] = { id: s.id, ...s.data() } as PublicPage;
            } catch {
              // ignore inaccessible page
            }
          })
        );
        if (Object.keys(loadedPages).length > 0) {
          setPagesMap((prev) => ({ ...prev, ...loadedPages }));
        }
      }
    };

    const syncMergedPosts = () => {
      if (!gotPublic && !gotMine) return;
      const byId = new Map<string, Post>();
      publicPosts.forEach((p) => byId.set(p.id, p));
      myPosts.forEach((p) => byId.set(p.id, p));
      const merged = Array.from(byId.values()).sort(
        (a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0)
      );
      setPosts(merged);
      setLoadingPosts(false);
      const uids = Array.from(new Set(merged.map((p) => p.authorUid)));
      const pIds = Array.from(
        new Set(merged.map((p) => p.pageId).filter((v): v is string => Boolean(v)))
      );
      hydrateAuthorsAndPages(uids, pIds);
    };

    const unsubPublicPosts = onSnapshot(
      query(
        collection(db, 'posts'),
        where('visibility', 'in', ['public', 'friends', 'community']),
        limit(60)
      ),
      (snap) => {
        publicPosts = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Post));
        gotPublic = true;
        syncMergedPosts();
      },
      (err) => {
        setLoadingPosts(false);
        handleFirestoreError(err, OperationType.LIST, 'posts');
      }
    );

    const unsubMyPosts = onSnapshot(
      query(collection(db, 'posts'), where('authorUid', '==', firebaseUser.uid), limit(30)),
      (snap) => {
        myPosts = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Post));
        gotMine = true;
        syncMergedPosts();
      },
      (err) => {
        setLoadingPosts(false);
        handleFirestoreError(err, OperationType.LIST, 'posts');
      }
    );

    const unsubStories = onSnapshot(
      query(collection(db, 'stories'), where('privacy', 'in', ['public', 'friends']), limit(30)),
      async (snap) => {
        const all = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Story));
        all.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        const live = all.filter((st) => isStoryActive(st.expiresAt) || st.isHighlight);
        setStories(live);
        await hydrateAuthorsAndPages(Array.from(new Set(live.map((s) => s.authorUid))), []);
      },
      () => {}
    );

    const unsubFollows = onSnapshot(
      query(collection(db, 'follows'), where('followerUid', '==', firebaseUser.uid)),
      (snap) => {
        setFollowingUids(new Set(snap.docs.map((d) => d.data().targetId as string)));
      },
      () => {}
    );

    const unsubFriendsA = onSnapshot(
      query(collection(db, 'friendships'), where('userA', '==', firebaseUser.uid)),
      (snap) => setFriendsA(snap.docs.map((d) => d.data().userB as string)),
      () => {}
    );

    const unsubFriendsB = onSnapshot(
      query(collection(db, 'friendships'), where('userB', '==', firebaseUser.uid)),
      (snap) => setFriendsB(snap.docs.map((d) => d.data().userA as string)),
      () => {}
    );

    const unsubAds = onSnapshot(
      query(collection(db, 'adCampaigns'), where('status', '==', 'active'), limit(15)),
      (snap) => {
        const eligible = snap.docs
          .map((d) => ({ id: d.id, ...d.data() } as AdCampaign))
          .filter((c) => c.paymentStatus === 'verified' && c.spentPoisha < c.lifetimeBudgetPoisha);
        setActiveCampaigns(eligible);
        const adUids = Array.from(new Set(eligible.map((c) => c.advertiserUid)));
        const adPages = Array.from(
          new Set(eligible.map((c) => c.pageId).filter((v): v is string => Boolean(v)))
        );
        hydrateAuthorsAndPages(adUids, adPages);
      },
      () => {}
    );

    return () => {
      unsubPublicPosts();
      unsubMyPosts();
      unsubStories();
      unsubFollows();
      unsubFriendsA();
      unsubFriendsB();
      unsubAds();
    };
  }, [firebaseUser?.uid]);

  // Listen to views & current user's reaction on the active Story
  useEffect(() => {
    if (!activeStory || !firebaseUser) {
      setStoryViews([]);
      setMyStoryReaction(null);
      setShowViewersList(false);
      return;
    }

    const unsubViews = onSnapshot(
      collection(db, 'stories', activeStory.id, 'views'),
      async (snap) => {
        const list = snap.docs.map((d) => d.data() as StoryViewRecord);
        setStoryViews(list);
        const mine = list.find((v) => v.viewerUid === firebaseUser.uid);
        setMyStoryReaction(mine?.reaction || null);

        if (activeStory.authorUid === firebaseUser.uid) {
          const missing = list
            .map((v) => v.viewerUid)
            .filter((u) => !usersMap[u]);
          if (missing.length > 0) {
            const loaded: Record<string, UserProfile> = {};
            await Promise.all(
              missing.map(async (u) => {
                try {
                  const s = await getDoc(doc(db, 'users', u));
                  if (s.exists()) loaded[u] = s.data() as UserProfile;
                } catch {}
              })
            );
            if (Object.keys(loaded).length > 0) {
              setUsersMap((prev) => ({ ...prev, ...loaded }));
            }
          }
        }
      },
      () => {}
    );

    return () => unsubViews();
  }, [activeStory?.id, firebaseUser?.uid]);

  // Keyboard navigation inside Story Viewer
  useEffect(() => {
    if (activeStoryIndex === null) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setActiveStoryIndex(null);
      if (e.key === 'ArrowRight') {
        setActiveStoryIndex((idx) =>
          idx !== null && idx + 1 < visibleStories.length ? idx + 1 : null
        );
      }
      if (e.key === 'ArrowLeft') {
        setActiveStoryIndex((idx) => (idx !== null && idx > 0 ? idx - 1 : idx));
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [activeStoryIndex, visibleStories.length]);

  const openStoryViewer = async (index: number) => {
    const story = visibleStories[index];
    if (!story) return;
    setActiveStoryIndex(index);
    if (!firebaseUser) return;
    const viewRef = doc(db, 'stories', story.id, 'views', firebaseUser.uid);
    try {
      const snap = await getDoc(viewRef);
      if (!snap.exists()) {
        await setDoc(viewRef, {
          viewerUid: firebaseUser.uid,
          viewedAt: serverTimestamp(),
        });
        await updateDoc(doc(db, 'stories', story.id), {
          viewsCount: increment(1),
        });
      }
    } catch {
      // non-fatal
    }
  };

  const reactToStory = async (emoji: string) => {
    if (!activeStory || !firebaseUser?.emailVerified) {
      pushToast('Verify your email to react to stories.', 'error');
      return;
    }
    const viewRef = doc(db, 'stories', activeStory.id, 'views', firebaseUser.uid);
    try {
      const snap = await getDoc(viewRef);
      if (snap.exists()) {
        // Strictly update ONLY 'reaction' field to satisfy firestore.rules affectedKeys().hasOnly(['reaction'])
        await updateDoc(viewRef, { reaction: emoji });
      } else {
        await setDoc(viewRef, {
          viewerUid: firebaseUser.uid,
          reaction: emoji,
          viewedAt: serverTimestamp(),
        });
      }
      setMyStoryReaction(emoji);
      if (activeStory.authorUid !== firebaseUser.uid) {
        await createNotification({
          recipientUid: activeStory.authorUid,
          actorUid: firebaseUser.uid,
          type: 'story_reaction',
          title: `Story Reaction ${emoji}`,
          body: `${profile?.displayName || 'Someone'} reacted ${emoji} to your story.`,
          targetTab: 'home',
        });
      }
      pushToast(`Reacted ${emoji} to story`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `stories/${activeStory.id}/views`);
    }
  };

  const sendStoryReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeStory || !firebaseUser?.emailVerified || !storyReplyText.trim()) return;
    try {
      await createNotification({
        recipientUid: activeStory.authorUid,
        actorUid: firebaseUser.uid,
        type: 'story_reply',
        title: 'Story Reply',
        body: `${profile?.displayName || 'Friend'} replied to your story: "${storyReplyText
          .trim()
          .slice(0, 140)}"`,
        targetTab: 'home',
      });
      setStoryReplyText('');
      pushToast('Reply sent!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'notifications');
    }
  };

  const handleDeleteActiveStory = async () => {
    if (!activeStory || activeStory.authorUid !== firebaseUser?.uid) return;
    try {
      await deleteDoc(doc(db, 'stories', activeStory.id));
      setActiveStoryIndex(null);
      pushToast('Story deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `stories/${activeStory.id}`);
    }
  };

  const visiblePosts = useMemo(() => {
    const filtered = posts
      .filter((p) => !hiddenPostIds.has(p.id))
      .filter((p) => {
        if (p.visibility === 'only_me' && p.authorUid !== firebaseUser?.uid) return false;
        if (
          p.visibility === 'friends' &&
          p.authorUid !== firebaseUser?.uid &&
          !friendUids.has(p.authorUid)
        ) {
          return false;
        }
        if (filter === 'friends') {
          return p.authorUid === firebaseUser?.uid || friendUids.has(p.authorUid);
        }
        if (filter === 'following') {
          return (
            p.authorUid === firebaseUser?.uid ||
            followingUids.has(p.authorUid) ||
            (p.pageId ? followingUids.has(p.pageId) : false)
          );
        }
        return true;
      });

    if (filter === 'for_you') {
      const now = Date.now();
      return [...filtered].sort((a, b) => {
        const ageHrsA = Math.max(0.5, (now - (a.createdAt?.toMillis?.() || now)) / 3600000);
        const ageHrsB = Math.max(0.5, (now - (b.createdAt?.toMillis?.() || now)) / 3600000);
        const engA =
          (a.likesCount || 0) * 2 +
          (a.commentsCount || 0) * 3 +
          (a.sharesCount || 0) * 4 +
          (a.isBoosted ? 12 : 0) +
          (friendUids.has(a.authorUid) || followingUids.has(a.authorUid) ? 10 : 0);
        const engB =
          (b.likesCount || 0) * 2 +
          (b.commentsCount || 0) * 3 +
          (b.sharesCount || 0) * 4 +
          (b.isBoosted ? 12 : 0) +
          (friendUids.has(b.authorUid) || followingUids.has(b.authorUid) ? 10 : 0);
        const scoreA = (engA + 5) / Math.pow(ageHrsA + 2, 1.15);
        const scoreB = (engB + 5) / Math.pow(ageHrsB + 2, 1.15);
        return scoreB - scoreA;
      });
    }

    return filtered;
  }, [posts, hiddenPostIds, firebaseUser?.uid, friendUids, followingUids, filter]);

  const suggestedEntries = useMemo(
    () =>
      rankSuggestedPosts({
        posts,
        currentUid: firebaseUser?.uid,
        friendUids,
        followingUids,
        hiddenPostIds,
        limit: 5,
      }),
    [posts, firebaseUser?.uid, friendUids, followingUids, hiddenPostIds]
  );

  const handleSelectSuggestedPost = (post: Post) => {
    if (filter !== 'for_you' && filter !== 'latest') {
      setFilter('for_you');
    }
    setHighlightedPostId(post.id);
    if (highlightTimerRef.current !== null) {
      window.clearTimeout(highlightTimerRef.current);
    }
    highlightTimerRef.current = window.setTimeout(() => {
      setHighlightedPostId((curr) => (curr === post.id ? null : curr));
    }, 2600);

    window.requestAnimationFrame(() => {
      window.setTimeout(() => {
        const el = document.getElementById(`feed-post-${post.id}`);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }, 60);
    });
  };

  const deliverableCampaigns = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);
    return activeCampaigns.filter((c) => {
      if (c.status !== 'active' || c.paymentStatus !== 'verified') return false;
      if ((c.spentPoisha || 0) >= c.lifetimeBudgetPoisha) return false;
      if (c.startDate && c.startDate > today) return false;
      if (c.endDate && c.endDate < today) return false;
      if (
        c.targetCountry &&
        profile?.locationCountry &&
        !c.targetCountry.toLowerCase().includes(profile.locationCountry.toLowerCase()) &&
        !profile.locationCountry.toLowerCase().includes(c.targetCountry.toLowerCase())
      ) {
        return false;
      }
      if (c.targetLanguage && c.targetLanguage !== 'en_bn' && c.targetLanguage !== language) {
        return false;
      }
      return true;
    });
  }, [activeCampaigns, profile?.locationCountry, language]);

  const renderSponsoredCard = (campaign: AdCampaign) => {
    const isVid =
      Boolean(campaign.creativeMediaUrl) &&
      (/\.(mp4|webm|mov|m4v)(\?|$)|\/video\/upload\//i.test(campaign.creativeMediaUrl || '') ||
        campaign.objective === 'video_views');
    const targetPage = campaign.pageId ? pagesMap[campaign.pageId] : undefined;
    return (
      <PostCard
        key={`sp_${campaign.id}`}
        post={{
          id: `sp_${campaign.id}`,
          authorUid: campaign.advertiserUid,
          authorType: targetPage ? 'page' : 'user',
          pageId: campaign.pageId,
          postType: isVid ? 'video' : campaign.creativeMediaUrl ? 'image' : 'text',
          content: campaign.creativeText || campaign.title,
          mediaUrls: campaign.creativeMediaUrl ? [campaign.creativeMediaUrl] : [],
          linkUrl: campaign.targetUrl,
          linkTitle: campaign.title,
          visibility: 'public',
          likesCount: 0,
          commentsCount: 0,
          sharesCount: 0,
          isBoosted: true,
          createdAt: Timestamp.now(),
          updatedAt: Timestamp.now(),
        }}
        author={usersMap[campaign.advertiserUid]}
        page={targetPage}
        isSponsored
        sponsoredCampaignId={campaign.id}
        onOpenProfile={onOpenProfile}
        onSponsoredNavigate={onOpenPages}
      />
    );
  };

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      {/* Stories Strip */}
      <section className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-semibold text-xs text-slate-600 dark:text-slate-300">
            {t('stories')}
          </h2>
          <span className="text-[11px] text-slate-400">24h live</span>
        </div>
        <div className="flex items-center gap-3 overflow-x-auto pb-1">
          <button
            type="button"
            onClick={() => onOpenUpload('story')}
            className="shrink-0 w-20 flex flex-col items-center gap-1.5 cursor-pointer group"
          >
            <div className="w-16 h-16 rounded-2xl border-2 border-dashed border-[#D4AF37]/60 bg-[#D4AF37]/10 flex items-center justify-center group-hover:bg-[#D4AF37]/20 transition-colors">
              <Plus className="w-6 h-6 text-[#D4AF37]" />
            </div>
            <span className="text-[11px] font-medium text-slate-700 dark:text-slate-300 truncate w-full text-center">
              {t('addStory')}
            </span>
          </button>

          {visibleStories.map((st, idx) => {
            const stAuthor = usersMap[st.authorUid];
            return (
              <button
                key={st.id}
                type="button"
                onClick={() => openStoryViewer(idx)}
                className="shrink-0 w-20 flex flex-col items-center gap-1.5 cursor-pointer"
              >
                <div className="w-16 h-16 rounded-2xl p-0.5 bg-gradient-to-tr from-[#D4AF37] to-[#3B82F6]">
                  <div className="w-full h-full rounded-[14px] overflow-hidden bg-[#0A0B0E] flex items-center justify-center">
                    {st.storyType === 'image' && st.mediaUrl ? (
                      <img
                        src={st.mediaUrl}
                        alt={stAuthor?.displayName || 'Story'}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <Avatar src={stAuthor?.photoUrl} name={stAuthor?.displayName || 'S'} size="md" />
                    )}
                  </div>
                </div>
                <span className="text-[11px] text-slate-700 dark:text-slate-300 truncate w-full text-center">
                  {stAuthor?.displayName?.split(' ')[0] || 'Story'}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Quick Post Composer Bar */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-3">
        <div className="flex items-center gap-3">
          <Avatar src={profile?.photoUrl} name={profile?.displayName || 'You'} size="md" />
          <button
            type="button"
            onClick={() => onOpenUpload('post')}
            className="flex-1 h-11 px-4 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-left text-xs sm:text-sm text-slate-500 hover:border-[#D4AF37]/50 transition-colors cursor-pointer truncate"
          >
            {t('createPost')}
          </button>
        </div>
        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-100 dark:border-white/5 text-xs">
          <button
            type="button"
            onClick={() => onOpenUpload('post')}
            className="min-h-[40px] flex items-center justify-center gap-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 text-slate-700 dark:text-slate-300 font-medium cursor-pointer whitespace-nowrap"
          >
            <ImageIcon className="w-4 h-4 text-[#D4AF37]" />
            Photo / Video
          </button>
          <button
            type="button"
            onClick={() => onOpenUpload('story')}
            className="min-h-[40px] flex items-center justify-center gap-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 text-slate-700 dark:text-slate-300 font-medium cursor-pointer whitespace-nowrap"
          >
            <Sparkles className="w-4 h-4 text-[#3B82F6]" />
            24h Story
          </button>
          <button
            type="button"
            onClick={() => onOpenUpload('spark')}
            className="min-h-[40px] flex items-center justify-center gap-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 text-slate-700 dark:text-slate-300 font-medium cursor-pointer whitespace-nowrap"
          >
            <Film className="w-4 h-4 text-rose-400" />
            Spark Video
          </button>
        </div>
      </div>

      {/* Suggested for You (Engagement-Prioritized Discovery) */}
      {!loadingPosts && suggestedEntries.length > 0 && (
        <SuggestedPostsSection
          entries={suggestedEntries}
          usersMap={usersMap}
          pagesMap={pagesMap}
          followingUids={followingUids}
          onOpenProfile={onOpenProfile}
          onSelectPost={handleSelectSuggestedPost}
          onDismissPost={(pid) => setHiddenPostIds((prev) => new Set(prev).add(pid))}
        />
      )}

      {/* Feed Filter Tabs */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#13151B] border border-slate-200 dark:border-white/10">
        {[
          { id: 'for_you', label: t('forYou') },
          { id: 'friends', label: t('friends') },
          { id: 'following', label: t('following') },
          { id: 'latest', label: t('latest') },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilter(tab.id as typeof filter)}
            className={`flex-1 min-h-[38px] py-2 rounded-lg text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              filter === tab.id
                ? 'bg-white dark:bg-[#D4AF37] text-slate-900 dark:text-[#0A0B0E] shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Posts + Active Sponsored Ad Interleaving */}
      {loadingPosts ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3 animate-pulse"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-slate-200 dark:bg-white/10" />
                <div className="space-y-2 flex-1">
                  <div className="h-3 w-32 bg-slate-200 dark:bg-white/10 rounded" />
                  <div className="h-2.5 w-20 bg-slate-200 dark:bg-white/10 rounded" />
                </div>
              </div>
              <div className="h-16 bg-slate-200 dark:bg-white/10 rounded-xl" />
            </div>
          ))}
        </div>
      ) : visiblePosts.length === 0 && deliverableCampaigns.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-10 text-center space-y-3">
          <Sparkles className="w-8 h-8 text-[#D4AF37] mx-auto" />
          <h3 className="font-display font-semibold text-base text-slate-900 dark:text-white">
            {filter === 'friends'
              ? 'No friend posts yet'
              : filter === 'following'
              ? 'No posts from followed accounts yet'
              : 'Your feed is ready'}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Publish your first post or connect with friends to see real-time stories and updates here.
          </p>
          <button
            type="button"
            onClick={() => onOpenUpload('post')}
            className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
          >
            Create First Post
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {visiblePosts.length === 0 && deliverableCampaigns[0] && renderSponsoredCard(deliverableCampaigns[0])}
          {visiblePosts.map((post, idx) => {
            const slotIndex =
              visiblePosts.length === 1 && idx === 0
                ? 0
                : idx % 4 === 1
                ? Math.floor((idx - 1) / 4)
                : -1;
            const sponsoredUnit =
              slotIndex >= 0 && deliverableCampaigns[slotIndex]
                ? deliverableCampaigns[slotIndex]
                : null;
            return (
              <React.Fragment key={post.id}>
                <div
                  id={`feed-post-${post.id}`}
                  className={
                    highlightedPostId === post.id
                      ? 'rounded-2xl ring-2 ring-[#D4AF37]/70 transition-shadow'
                      : undefined
                  }
                >
                  <PostCard
                    post={post}
                    author={usersMap[post.authorUid]}
                    page={post.pageId ? pagesMap[post.pageId] : undefined}
                    onOpenProfile={onOpenProfile}
                    onBoostPost={(p) => setBoostTarget(p)}
                    onHidePost={(pid) => setHiddenPostIds((prev) => new Set(prev).add(pid))}
                  />
                </div>
                {sponsoredUnit && renderSponsoredCard(sponsoredUnit)}
              </React.Fragment>
            );
          })}
        </div>
      )}

      {/* Story Viewer Modal */}
      {activeStory && (
        <div className="fixed inset-0 z-[80] bg-black/95 flex items-center justify-center p-4">
          <div className="max-w-sm w-full h-[82vh] max-h-[700px] rounded-3xl overflow-hidden border border-white/15 bg-[#12141A] relative flex flex-col justify-between">
            {activeStory.storyType === 'image' && activeStory.mediaUrl && (
              <img
                src={activeStory.mediaUrl}
                alt="Story"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover"
              />
            )}
            {activeStory.storyType === 'video' && activeStory.mediaUrl && (
              <video
                src={activeStory.mediaUrl}
                autoPlay
                controls
                muted
                playsInline
                className="absolute inset-0 w-full h-full object-cover"
              />
            )}
            {activeStory.storyType === 'text' && (
              <div
                style={{ backgroundColor: activeStory.bgColor || '#141824' }}
                className="absolute inset-0 flex items-center justify-center p-8 text-center"
              >
                <p className="font-display text-2xl font-bold text-white">{activeStory.text}</p>
              </div>
            )}

            {/* Top Progress + Author Bar */}
            <div className="relative z-10 p-4 bg-gradient-to-b from-black/80 via-black/45 to-transparent space-y-2.5">
              {/* Progress segments */}
              <div className="flex items-center gap-1">
                {visibleStories.map((st, sIdx) => (
                  <button
                    key={st.id}
                    type="button"
                    aria-label={`View story ${sIdx + 1}`}
                    onClick={() => setActiveStoryIndex(sIdx)}
                    className={`h-1 flex-1 rounded-full transition-colors cursor-pointer ${
                      sIdx === activeStoryIndex
                        ? 'bg-[#D4AF37]'
                        : sIdx < (activeStoryIndex ?? 0)
                        ? 'bg-white/70'
                        : 'bg-white/25'
                    }`}
                  />
                ))}
              </div>

              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setActiveStoryIndex(null);
                    onOpenProfile(activeStory.authorUid);
                  }}
                  className="flex items-center gap-2.5 min-w-0 cursor-pointer"
                >
                  <Avatar
                    src={usersMap[activeStory.authorUid]?.photoUrl}
                    name={usersMap[activeStory.authorUid]?.displayName || 'U'}
                    size="sm"
                  />
                  <div className="text-left min-w-0">
                    <p className="text-xs font-semibold text-white truncate">
                      {usersMap[activeStory.authorUid]?.displayName || 'Creator'}
                    </p>
                    <p className="text-[11px] text-slate-300 flex items-center gap-1">
                      <Eye className="w-3 h-3" /> {Math.max(activeStory.viewsCount, storyViews.length)} views
                      <span aria-hidden="true">·</span>
                      <span className="capitalize">{activeStory.privacy}</span>
                    </p>
                  </div>
                </button>

                <div className="flex items-center gap-1.5 shrink-0">
                  {activeStory.authorUid === firebaseUser?.uid && (
                    <>
                      <button
                        type="button"
                        onClick={() => setShowViewersList((v) => !v)}
                        className="px-2.5 h-8 rounded-full bg-black/50 text-white text-[11px] font-medium cursor-pointer"
                      >
                        Viewers ({Math.max(activeStory.viewsCount, storyViews.length)})
                      </button>
                      <button
                        type="button"
                        onClick={async () => {
                          await updateDoc(doc(db, 'stories', activeStory.id), {
                            isHighlight: !activeStory.isHighlight,
                            highlightTitle: 'Highlights',
                          });
                          pushToast(
                            activeStory.isHighlight ? 'Removed from Highlights' : 'Saved to Highlights!',
                            'success'
                          );
                        }}
                        className="w-8 h-8 rounded-full bg-black/50 text-[#D4AF37] flex items-center justify-center cursor-pointer"
                        title="Toggle Highlight"
                      >
                        <BookmarkPlus className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={handleDeleteActiveStory}
                        className="w-8 h-8 rounded-full bg-black/50 text-rose-400 flex items-center justify-center cursor-pointer"
                        title="Delete Story"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  )}
                  <button
                    type="button"
                    onClick={() => setActiveStoryIndex(null)}
                    aria-label="Close story"
                    className="w-8 h-8 rounded-full bg-black/50 text-white flex items-center justify-center cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Prev / Next Navigation Buttons */}
            {activeStoryIndex !== null && activeStoryIndex > 0 && (
              <button
                type="button"
                aria-label="Previous story"
                onClick={() => setActiveStoryIndex(activeStoryIndex - 1)}
                className="absolute left-2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-black/75 cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
            )}
            {activeStoryIndex !== null && activeStoryIndex + 1 < visibleStories.length && (
              <button
                type="button"
                aria-label="Next story"
                onClick={() => setActiveStoryIndex(activeStoryIndex + 1)}
                className="absolute right-2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-black/75 cursor-pointer"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            )}

            {/* Viewers Drawer (Owner Only) */}
            {showViewersList && activeStory.authorUid === firebaseUser?.uid && (
              <div className="relative z-20 mx-4 mb-2 rounded-2xl border border-white/15 bg-black/85 backdrop-blur-md p-3 max-h-40 overflow-y-auto space-y-2 text-xs text-white">
                <div className="flex items-center justify-between font-semibold text-slate-300">
                  <span>Seen by</span>
                  <button
                    type="button"
                    onClick={() => setShowViewersList(false)}
                    className="text-slate-400 cursor-pointer"
                  >
                    Close
                  </button>
                </div>
                {storyViews.length === 0 ? (
                  <p className="text-slate-400 text-[11px]">No viewers yet.</p>
                ) : (
                  storyViews.map((sv) => {
                    const viewer = usersMap[sv.viewerUid];
                    return (
                      <div key={sv.viewerUid} className="flex items-center justify-between">
                        <span className="truncate">{viewer?.displayName || sv.viewerUid}</span>
                        {sv.reaction && <span>{sv.reaction}</span>}
                      </div>
                    );
                  })
                )}
              </div>
            )}

            {/* Bottom Caption, Reaction Bar & Reply */}
            <div className="relative z-10 p-4 bg-gradient-to-t from-black/90 via-black/60 to-transparent space-y-2.5">
              {activeStory.text && activeStory.storyType !== 'text' && (
                <p className="text-sm text-white text-center pb-1">{activeStory.text}</p>
              )}
              <div className="flex items-center justify-center gap-2.5">
                {['❤️', '🔥', '👏', '✨', '😂', '😮'].map((emoji) => (
                  <button
                    key={emoji}
                    type="button"
                    onClick={() => reactToStory(emoji)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-base transition-transform hover:scale-110 cursor-pointer ${
                      myStoryReaction === emoji
                        ? 'bg-[#D4AF37] ring-2 ring-white'
                        : 'bg-white/15 hover:bg-white/25'
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
              <form onSubmit={sendStoryReply} className="flex items-center gap-2">
                <input
                  type="text"
                  value={storyReplyText}
                  onChange={(e) => setStoryReplyText(e.target.value)}
                  placeholder="Reply to story..."
                  className="flex-1 h-10 px-3.5 rounded-full bg-white/15 border border-white/20 text-xs text-white placeholder:text-slate-300 focus:outline-none focus:border-[#D4AF37]"
                />
                <button
                  type="submit"
                  aria-label="Send story reply"
                  className="w-10 h-10 rounded-full bg-[#D4AF37] text-[#0A0B0E] flex items-center justify-center cursor-pointer shrink-0"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Boost Post Modal */}
      <BoostPostModal post={boostTarget} onClose={() => setBoostTarget(null)} />
    </div>
  );
};
