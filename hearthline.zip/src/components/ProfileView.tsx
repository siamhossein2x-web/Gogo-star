import React, { useEffect, useState } from 'react';
import {
  collection,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  Award,
  Ban,
  CheckCircle2,
  Edit3,
  Flag,
  MapPin,
  MessageCircle,
  Share2,
  UserPlus,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, makeFriendshipId, makeSafeId, OperationType } from '../lib/firebase';
import { Post, SparkVideo, Story, UserProfile } from '../types/hearthline';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { Avatar } from './Avatar';
import { PostCard } from './PostCard';
import { BoostPostModal } from './BoostPostModal';
import { MediaUploadInput } from './MediaUploadInput';
import { BRAND_ASSETS } from '../lib/assets';
import {
  blockUser,
  openOrCreateDirectConversation,
  sendFriendRequest,
  submitReport,
  toggleFollow,
} from '../lib/socialActions';

interface ProfileViewProps {
  targetUid?: string;
  onOpenProfile: (uid: string) => void;
  onOpenChat: (convId: string) => void;
  onOpenWallet?: () => void;
}

interface CreatorMonetizationAppRecord {
  id: string;
  uid: string;
  followersCount: number;
  accountAgeDays: number;
  status: 'pending' | 'approved' | 'rejected';
  reviewNote?: string;
  createdAt?: Timestamp;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  targetUid,
  onOpenProfile,
  onOpenChat,
  onOpenWallet,
}) => {
  const { firebaseUser, profile: myProfile, platformSettings } = useAuth();
  const { pushToast } = useToast();

  const viewUid = targetUid || firebaseUser?.uid || '';
  const isMe = viewUid === firebaseUser?.uid;

  const [viewedUser, setViewedUser] = useState<UserProfile | null>(null);
  const [subTab, setSubTab] = useState<'posts' | 'photos' | 'videos' | 'saved' | 'creator'>('posts');
  const [posts, setPosts] = useState<Post[]>([]);
  const [sparks, setSparks] = useState<SparkVideo[]>([]);
  const [highlights, setHighlights] = useState<Story[]>([]);
  const [savedPosts, setSavedPosts] = useState<Post[]>([]);
  const [isFriend, setIsFriend] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);

  const [editing, setEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editPhoto, setEditPhoto] = useState('');
  const [editCover, setEditCover] = useState('');
  const [editPrivacy, setEditPrivacy] = useState<'public' | 'friends' | 'private'>('public');

  const [boostTarget, setBoostTarget] = useState<Post | null>(null);
  const [latestCreatorApp, setLatestCreatorApp] = useState<CreatorMonetizationAppRecord | null>(null);
  const [attestedCreator, setAttestedCreator] = useState(true);
  const [busyCreatorApp, setBusyCreatorApp] = useState(false);

  useEffect(() => {
    if (!viewUid || !firebaseUser) return;

    const unsubUser = onSnapshot(doc(db, 'users', viewUid), (snap) => {
      if (snap.exists()) {
        const u = snap.data() as UserProfile;
        setViewedUser(u);
        if (isMe) {
          setEditName(u.displayName);
          setEditBio(u.bio || '');
          setEditPhoto(u.photoUrl || '');
          setEditCover(u.coverUrl || '');
          setEditPrivacy(u.privacyLevel);
        }
      }
    });

    const unsubPosts = onSnapshot(
      isMe
        ? query(collection(db, 'posts'), where('authorUid', '==', firebaseUser.uid))
        : query(
            collection(db, 'posts'),
            where('visibility', 'in', ['public', 'friends', 'community'])
          ),
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...d.data() } as Post))
          .filter((p) => (isMe ? true : p.authorUid === viewUid));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setPosts(list);
      },
      () => {}
    );

    const unsubSparks = onSnapshot(
      query(collection(db, 'sparkVideos'), where('authorUid', '==', viewUid)),
      (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as SparkVideo));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setSparks(list);
      },
      () => {}
    );

    const unsubHighlights = onSnapshot(
      isMe
        ? query(collection(db, 'stories'), where('authorUid', '==', firebaseUser.uid))
        : query(collection(db, 'stories'), where('privacy', 'in', ['public', 'friends'])),
      (snap) => {
        const list = snap.docs
          .map((d) => ({ id: d.id, ...d.data() } as Story))
          .filter((st) => st.isHighlight && (isMe || st.authorUid === viewUid));
        setHighlights(list);
      },
      () => {}
    );

    let unsubSaved = () => {};
    if (isMe) {
      unsubSaved = onSnapshot(
        query(collection(db, 'savedPosts'), where('uid', '==', firebaseUser.uid)),
        async (snap) => {
          const postIds = snap.docs
            .map((d) => d.data())
            .filter((d) => d.targetType === 'post')
            .map((d) => d.targetId as string);
          const loaded: Post[] = [];
          await Promise.all(
            postIds.slice(0, 20).map(async (pid) => {
              const ps = await getDoc(doc(db, 'posts', pid));
              if (ps.exists()) loaded.push({ id: ps.id, ...ps.data() } as Post);
            })
          );
          setSavedPosts(loaded);
        },
        () => {}
      );
    }

    const friendshipId = makeFriendshipId(firebaseUser.uid, viewUid);
    const unsubFriend = !isMe
      ? onSnapshot(doc(db, 'friendships', friendshipId), (s) => setIsFriend(s.exists()))
      : () => {};
    const unsubFollow = !isMe
      ? onSnapshot(doc(db, 'follows', `${firebaseUser.uid}_${viewUid}`), (s) => setIsFollowing(s.exists()))
      : () => {};

    const unsubCreatorApp = isMe
      ? onSnapshot(
          query(collection(db, 'creatorMonetizationApplications'), where('uid', '==', firebaseUser.uid)),
          (s) => {
            const apps = s.docs.map(
              (d) => ({ id: d.id, ...d.data() } as CreatorMonetizationAppRecord)
            );
            apps.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
            setLatestCreatorApp(apps[0] || null);
          },
          () => {}
        )
      : () => {};

    return () => {
      unsubUser();
      unsubPosts();
      unsubSparks();
      unsubHighlights();
      unsubSaved();
      unsubFriend();
      unsubFollow();
      unsubCreatorApp();
    };
  }, [viewUid, firebaseUser?.uid, isMe]);

  if (!viewedUser) {
    return (
      <div className="max-w-3xl mx-auto p-10 text-center text-xs text-slate-500">
        Loading profile...
      </div>
    );
  }

  const accountAgeDays = viewedUser.createdAt?.toDate
    ? Math.floor((Date.now() - viewedUser.createdAt.toDate().getTime()) / 86400000)
    : 0;
  const creatorEligible =
    viewedUser.followersCount >= platformSettings.creatorMinFollowers &&
    accountAgeDays >= platformSettings.creatorMinAgeDays;

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    try {
      await updateDoc(doc(db, 'users', firebaseUser.uid), {
        displayName: editName.trim().slice(0, 80),
        bio: editBio.trim().slice(0, 500),
        photoUrl: editPhoto.trim().slice(0, 1024),
        coverUrl: editCover.trim().slice(0, 1024),
        privacyLevel: editPrivacy,
        updatedAt: serverTimestamp(),
      });
      setEditing(false);
      pushToast('Profile updated!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    }
  };

  const applyForCreatorMonetization = async () => {
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email before applying.', 'error');
      return;
    }
    setBusyCreatorApp(true);
    const appId = makeSafeId('capp');
    try {
      await setDoc(doc(db, 'creatorMonetizationApplications', appId), {
        uid: firebaseUser.uid,
        followersCount: viewedUser.followersCount,
        accountAgeDays,
        originalContentAttested: true,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      pushToast('Personal Creator Monetization application submitted for Admin review.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `creatorMonetizationApplications/${appId}`);
    } finally {
      setBusyCreatorApp(false);
    }
  };

  const photoPosts = posts.filter((p) => (p.mediaUrls?.length || 0) > 0 && p.postType !== 'video');
  const videoPosts = posts.filter((p) => p.postType === 'video');

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Cover + Profile Header Card */}
      <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] overflow-hidden">
        <div className="h-44 sm:h-56 bg-[#0A0B0E] relative">
          <img
            src={viewedUser.coverUrl || BRAND_ASSETS.defaultProfileCover}
            alt="Profile cover"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
        </div>

        <div className="px-5 pb-5">
          <div className="flex flex-wrap items-end justify-between gap-4 -mt-12 relative z-10">
            <Avatar
              src={viewedUser.photoUrl}
              name={viewedUser.displayName}
              size="xl"
              className="ring-4 ring-white dark:ring-[#13151B]"
            />

            <div className="flex flex-wrap items-center gap-2 pt-2">
              {isMe ? (
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-[#1B1E26] text-xs font-semibold cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5 text-[#D4AF37]" /> Edit Profile
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={async () => {
                      if (!firebaseUser) return;
                      await toggleFollow(
                        firebaseUser.uid,
                        viewedUser.uid,
                        'user',
                        isFollowing,
                        myProfile?.displayName || 'Someone'
                      );
                    }}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold border cursor-pointer ${
                      isFollowing
                        ? 'border-[#3B82F6] text-[#3B82F6]'
                        : 'border-slate-200 dark:border-white/15'
                    }`}
                  >
                    {isFollowing ? 'Following' : 'Follow'}
                  </button>

                  {isFriend ? (
                    <button
                      type="button"
                      onClick={async () => {
                        if (!firebaseUser) return;
                        const cid = await openOrCreateDirectConversation(firebaseUser.uid, viewedUser.uid);
                        onOpenChat(cid);
                      }}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#3B82F6] text-white text-xs font-semibold cursor-pointer"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> Message
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={async () => {
                        if (!firebaseUser) return;
                        try {
                          await sendFriendRequest(
                            firebaseUser.uid,
                            viewedUser.uid,
                            myProfile?.displayName || 'Someone'
                          );
                          pushToast('Friend request sent!', 'success');
                        } catch (err) {
                          pushToast(err instanceof Error ? err.message : 'Unable to send request.', 'error');
                        }
                      }}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
                    >
                      <UserPlus className="w-3.5 h-3.5" /> Add Friend
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={async () => {
                      if (!firebaseUser) return;
                      await blockUser(firebaseUser.uid, viewedUser.uid);
                      pushToast('User blocked.', 'info');
                    }}
                    className="p-2 rounded-xl border border-slate-200 dark:border-white/10 text-slate-400 hover:text-rose-500 cursor-pointer"
                    title="Block User"
                  >
                    <Ban className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (!firebaseUser) return;
                      await submitReport({
                        reporterUid: firebaseUser.uid,
                        targetType: 'user',
                        targetId: viewedUser.uid,
                        reason: 'Profile safety report',
                      });
                      pushToast('Profile reported.', 'info');
                    }}
                    className="p-2 rounded-xl border border-slate-200 dark:border-white/10 text-slate-400 hover:text-amber-500 cursor-pointer"
                    title="Report User"
                  >
                    <Flag className="w-4 h-4" />
                  </button>
                </>
              )}

              <button
                type="button"
                onClick={async () => {
                  await navigator.clipboard.writeText(`${window.location.origin}/?u=${viewedUser.username}`);
                  pushToast('Profile link copied!', 'info');
                }}
                className="p-2 rounded-xl border border-slate-200 dark:border-white/10 text-slate-500 hover:text-[#D4AF37] cursor-pointer"
                title="Share Profile"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="mt-4 space-y-2">
            <div className="flex items-center gap-2">
              <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                {viewedUser.displayName}
              </h1>
              {viewedUser.creatorMonetizationStatus === 'approved' && (
                <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
              )}
            </div>
            <p className="text-xs text-slate-500">@{viewedUser.username}</p>
            {viewedUser.bio && (
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {viewedUser.bio}
              </p>
            )}
            {(viewedUser.locationCity || viewedUser.locationCountry) && (
              <p className="text-xs text-slate-500 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-[#D4AF37]" />
                {[viewedUser.locationCity, viewedUser.locationCountry].filter(Boolean).join(', ')}
              </p>
            )}

            {/* Separate Friends, Followers, Following counts */}
            <div className="flex flex-wrap items-center gap-5 pt-2 text-xs">
              <span>
                <strong className="font-mono tabular-nums text-sm text-slate-900 dark:text-white">
                  {viewedUser.friendsCount}
                </strong>{' '}
                <span className="text-slate-500">Friends</span>
              </span>
              <span>
                <strong className="font-mono tabular-nums text-sm text-slate-900 dark:text-white">
                  {viewedUser.followersCount}
                </strong>{' '}
                <span className="text-slate-500">Followers</span>
              </span>
              <span>
                <strong className="font-mono tabular-nums text-sm text-slate-900 dark:text-white">
                  {viewedUser.followingCount}
                </strong>{' '}
                <span className="text-slate-500">Following</span>
              </span>
            </div>
          </div>

          {/* Story Highlights */}
          {highlights.length > 0 && (
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-white/5 flex items-center gap-3 overflow-x-auto">
              {highlights.map((hl) => (
                <div key={hl.id} className="shrink-0 w-16 text-center space-y-1">
                  <div className="w-14 h-14 mx-auto rounded-full border-2 border-[#D4AF37] overflow-hidden bg-black flex items-center justify-center">
                    {hl.mediaUrl ? (
                      <img src={hl.mediaUrl} alt="Highlight" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-xs text-white px-1 truncate">{hl.text}</span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-500 truncate">{hl.highlightTitle || 'Highlight'}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Profile Sub-Tabs */}
        <div className="px-5 border-t border-slate-200 dark:border-white/10 flex items-center gap-4 overflow-x-auto text-xs font-semibold">
          {[
            { id: 'posts', label: `Posts (${posts.length})` },
            { id: 'photos', label: `Photos (${photoPosts.length})` },
            { id: 'videos', label: `Videos (${videoPosts.length + sparks.length})` },
            ...(isMe ? [{ id: 'saved', label: `Saved (${savedPosts.length})` }] : []),
            ...(isMe ? [{ id: 'creator', label: 'Creator Monetization' }] : []),
          ].map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setSubTab(item.id as typeof subTab)}
              className={`py-3 border-b-2 transition-colors whitespace-nowrap cursor-pointer ${
                subTab === item.id
                  ? 'border-[#D4AF37] text-[#D4AF37]'
                  : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      {subTab === 'posts' && (
        <div className="space-y-4">
          {posts.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-8 text-center text-xs text-slate-500">
              No posts published yet.
            </div>
          ) : (
            posts.map((p) => (
              <PostCard
                key={p.id}
                post={p}
                author={viewedUser}
                onOpenProfile={onOpenProfile}
                onBoostPost={isMe ? (post) => setBoostTarget(post) : undefined}
              />
            ))
          )}
        </div>
      )}

      {subTab === 'photos' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {photoPosts.flatMap((p) => p.mediaUrls || []).map((url, idx) => (
            <img
              key={idx}
              src={url}
              alt="Profile media"
              referrerPolicy="no-referrer"
              className="w-full h-44 object-cover rounded-xl border border-slate-200 dark:border-white/10"
            />
          ))}
          {photoPosts.length === 0 && (
            <p className="col-span-full text-center text-xs text-slate-500 py-8">No photos yet.</p>
          )}
        </div>
      )}

      {subTab === 'videos' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {sparks.map((v) => (
            <div key={v.id} className="rounded-xl border border-slate-200 dark:border-white/10 bg-black overflow-hidden">
              <video src={v.videoUrl} controls muted className="w-full h-56 object-contain" />
              <p className="p-3 text-xs text-slate-300">{v.description || v.soundTitle}</p>
            </div>
          ))}
          {videoPosts.map((p) => (
            <div key={p.id} className="rounded-xl border border-slate-200 dark:border-white/10 bg-black overflow-hidden">
              <video src={p.mediaUrls?.[0]} controls muted className="w-full h-56 object-contain" />
              <p className="p-3 text-xs text-slate-300">{p.content}</p>
            </div>
          ))}
          {sparks.length + videoPosts.length === 0 && (
            <p className="col-span-full text-center text-xs text-slate-500 py-8">No videos yet.</p>
          )}
        </div>
      )}

      {subTab === 'saved' && isMe && (
        <div className="space-y-4">
          {savedPosts.length === 0 ? (
            <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-8 text-center text-xs text-slate-500">
              No saved posts yet.
            </div>
          ) : (
            savedPosts.map((p) => (
              <PostCard key={p.id} post={p} onOpenProfile={onOpenProfile} />
            ))
          )}
        </div>
      )}

      {/* Personal Creator Monetization (Separate from Page Monetization) */}
      {subTab === 'creator' && isMe && (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h2 className="font-display font-bold text-base flex items-center gap-2">
                <Award className="w-5 h-5 text-[#D4AF37]" />
                Personal Creator Monetization
              </h2>
              <p className="text-xs text-slate-500 mt-1">
                Separate from Public Page Monetization. Funded strictly from verified, reconciled creator reward pools.
              </p>
            </div>
            <span className="text-xs font-semibold capitalize text-[#D4AF37]">
              {viewedUser.creatorMonetizationStatus.replace('_', ' ')}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-slate-500">Followers Requirement</p>
                <p className="font-mono tabular-nums font-semibold text-sm">
                  {viewedUser.followersCount} / {platformSettings.creatorMinFollowers}
                </p>
              </div>
              <div className="h-1.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-[#D4AF37]"
                  style={{
                    width: `${Math.min(
                      100,
                      platformSettings.creatorMinFollowers > 0
                        ? (viewedUser.followersCount / platformSettings.creatorMinFollowers) * 100
                        : 100
                    )}%`,
                  }}
                />
              </div>
            </div>
            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-slate-500">Account Age Requirement</p>
                <p className="font-mono tabular-nums font-semibold text-sm">
                  {accountAgeDays} / {platformSettings.creatorMinAgeDays} days
                </p>
              </div>
              <div className="h-1.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-[#3B82F6]"
                  style={{
                    width: `${Math.min(
                      100,
                      platformSettings.creatorMinAgeDays > 0
                        ? (accountAgeDays / platformSettings.creatorMinAgeDays) * 100
                        : 100
                    )}%`,
                  }}
                />
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-4 text-xs space-y-2">
            <p className="font-semibold text-slate-900 dark:text-white">
              Configurable Reward Pool Policy ({platformSettings.creatorPoolBps / 100}% Creator Pool / {100 - platformSettings.creatorPoolBps / 100}% Platform)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-slate-500 font-mono tabular-nums">
              <span>Spark &amp; Video: {platformSettings.creatorVideoAllocPct}%</span>
              <span>Feed Posts: {platformSettings.creatorPostAllocPct}%</span>
              <span>Quality &amp; Compliance: {platformSettings.creatorQualityAllocPct}%</span>
            </div>
            <p className="text-[11px] text-slate-500">
              Allocations represent configurable policy targets, not guaranteed payouts. Only reconciled revenue funds rewards.
            </p>
          </div>

          {viewedUser.creatorMonetizationStatus === 'approved' ? (
            <div className="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/10 text-xs">
              <div>
                <p className="font-semibold text-emerald-500">Creator Monetization Active</p>
                <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                  Reconciled creator pool rewards are credited directly to your Personal Creator Wallet.
                </p>
              </div>
              {onOpenWallet && (
                <button
                  type="button"
                  onClick={onOpenWallet}
                  className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
                >
                  Open Creator Wallet
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {latestCreatorApp?.status === 'rejected' && (
                <div className="p-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-xs text-rose-500">
                  Previous application was declined
                  {latestCreatorApp.reviewNote ? `: ${latestCreatorApp.reviewNote}` : '.'} You can re-apply once eligible.
                </div>
              )}

              {latestCreatorApp?.status !== 'pending' && (
                <label className="flex items-start gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={attestedCreator}
                    onChange={(e) => setAttestedCreator(e.target.checked)}
                    className="mt-0.5 accent-[#D4AF37]"
                  />
                  <span>
                    I attest that my profile publishes original content compliant with HEARTHLINE policies.
                  </span>
                </label>
              )}

              <button
                type="button"
                disabled={
                  busyCreatorApp ||
                  latestCreatorApp?.status === 'pending' ||
                  !creatorEligible ||
                  !attestedCreator
                }
                onClick={applyForCreatorMonetization}
                className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold disabled:opacity-45 cursor-pointer"
              >
                {latestCreatorApp?.status === 'pending'
                  ? 'Application Under Admin Review'
                  : !creatorEligible
                  ? 'Meet Follower & Account Age Requirements to Apply'
                  : latestCreatorApp?.status === 'rejected'
                  ? 'Re-apply for Personal Creator Monetization'
                  : 'Apply for Personal Creator Monetization'}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Edit Profile Modal */}
      {editing && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="max-w-md w-full rounded-2xl border border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base">Edit Profile</h3>
              <button onClick={() => setEditing(false)} className="cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSaveProfile} className="space-y-3">
              <input
                type="text"
                required
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="Display Name"
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
              />
              <textarea
                rows={3}
                value={editBio}
                onChange={(e) => setEditBio(e.target.value)}
                placeholder="Bio"
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
              />
              <MediaUploadInput
                accept="image/*"
                mediaKind="image"
                label="Update Profile Photo"
                value={editPhoto}
                onUploaded={(url) => setEditPhoto(url)}
              />
              <MediaUploadInput
                accept="image/*"
                mediaKind="image"
                label="Update Cover Photo"
                value={editCover}
                onUploaded={(url) => setEditCover(url)}
              />
              <select
                value={editPrivacy}
                onChange={(e) => setEditPrivacy(e.target.value as 'public' | 'friends' | 'private')}
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
              >
                <option value="public">Public Profile</option>
                <option value="friends">Friends Only</option>
                <option value="private">Private</option>
              </select>
              <button
                type="submit"
                className="w-full h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
              >
                Save Changes
              </button>
            </form>
          </div>
        </div>
      )}

      <BoostPostModal post={boostTarget} onClose={() => setBoostTarget(null)} />
    </div>
  );
};
