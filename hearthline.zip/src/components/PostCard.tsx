import React, { useEffect, useRef, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  increment,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import {
  Bookmark,
  ChevronDown,
  ExternalLink,
  EyeOff,
  Flag,
  Image as ImageIcon,
  Megaphone,
  MessageSquare,
  MoreHorizontal,
  Pencil,
  Repeat2,
  Share2,
  ThumbsUp,
  Trash2,
  UserPlus,
} from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import {
  CommentItem,
  LikeRecord,
  Post,
  PublicPage,
  ReactionType,
  UserProfile,
} from '../types/hearthline';
import { useAuth, createNotification } from '../context/AuthContext';
import { useToast } from './Toast';
import { Avatar } from './Avatar';
import { recordVerifiedAdEvent, submitReport, toggleFollow } from '../lib/socialActions';
import { sanitizeExternalUrl } from '../lib/url';

export const REACTION_META: Record<
  ReactionType,
  { emoji: string; label: string; textColor: string; bgColor: string }
> = {
  like: { emoji: '👍', label: 'Like', textColor: 'text-[#3B82F6]', bgColor: 'bg-[#3B82F6]/10' },
  love: { emoji: '❤️', label: 'Love', textColor: 'text-rose-500', bgColor: 'bg-rose-500/10' },
  care: { emoji: '🥰', label: 'Care', textColor: 'text-amber-500', bgColor: 'bg-amber-500/10' },
  haha: { emoji: '😂', label: 'Haha', textColor: 'text-amber-400', bgColor: 'bg-amber-400/10' },
  wow: { emoji: '😮', label: 'Wow', textColor: 'text-sky-400', bgColor: 'bg-sky-400/10' },
  sad: { emoji: '😢', label: 'Sad', textColor: 'text-indigo-400', bgColor: 'bg-indigo-400/10' },
  angry: { emoji: '😡', label: 'Angry', textColor: 'text-orange-500', bgColor: 'bg-orange-500/10' },
};

const REACTION_LIST: ReactionType[] = ['like', 'love', 'care', 'haha', 'wow', 'sad', 'angry'];

interface PostCardProps {
  post: Post;
  author?: UserProfile;
  page?: PublicPage;
  isSponsored?: boolean;
  sponsoredCampaignId?: string;
  onOpenProfile: (uid: string) => void;
  onBoostPost?: (post: Post) => void;
  onHidePost?: (postId: string) => void;
  onSponsoredNavigate?: () => void;
  canModerate?: boolean;
}

function isVideoMediaUrl(url: string, postType: Post['postType']): boolean {
  return (
    postType === 'video' ||
    /\/video\/upload\//i.test(url) ||
    /\.(mp4|webm|mov|m4v)(\?|$)/i.test(url)
  );
}

export const PostCard: React.FC<PostCardProps> = ({
  post,
  author,
  page,
  isSponsored,
  sponsoredCampaignId,
  onOpenProfile,
  onBoostPost,
  onHidePost,
  onSponsoredNavigate,
  canModerate = false,
}) => {
  const { firebaseUser, profile, isModerator } = useAuth();
  const { pushToast } = useToast();

  const [reactions, setReactions] = useState<LikeRecord[]>([]);
  const [showReactionTray, setShowReactionTray] = useState(false);
  const [saved, setSaved] = useState(false);
  const [followingAuthor, setFollowingAuthor] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<CommentItem[]>([]);
  const [commentUsers, setCommentUsers] = useState<Record<string, UserProfile>>({});
  const [commentText, setCommentText] = useState('');
  const [replyTo, setReplyTo] = useState<CommentItem | null>(null);
  const [editingCommentId, setEditingCommentId] = useState<string | null>(null);
  const [editingCommentText, setEditingCommentText] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editDraft, setEditDraft] = useState(post.content);
  const [editVisibility, setEditVisibility] = useState<Post['visibility']>(post.visibility);
  const [brokenImages, setBrokenImages] = useState<Set<number>>(new Set());
  const videoViewTrackedRef = useRef(false);

  const safeLinkUrl = sanitizeExternalUrl(post.linkUrl);
  const isOwn = firebaseUser?.uid === post.authorUid;
  const isPagePost = post.authorType === 'page' && Boolean(page);
  const myReactionRecord = reactions.find((r) => r.uid === firebaseUser?.uid);
  const myReaction: ReactionType | null = myReactionRecord
    ? myReactionRecord.reaction || 'like'
    : null;

  useEffect(() => {
    setEditDraft(post.content);
    setEditVisibility(post.visibility);
  }, [post.content, post.visibility]);

  useEffect(() => {
    if (!firebaseUser) return;

    const unsubReactions = !isSponsored
      ? onSnapshot(
          collection(db, 'posts', post.id, 'likes'),
          (snap) => {
            setReactions(snap.docs.map((d) => d.data() as LikeRecord));
          },
          () => {}
        )
      : () => {};

    const unsubSave = !isSponsored
      ? onSnapshot(
          doc(db, 'savedPosts', `${firebaseUser.uid}_${post.id}`),
          (snap) => setSaved(snap.exists()),
          () => {}
        )
      : () => {};

    const unsubFollow = !isOwn
      ? onSnapshot(
          doc(db, 'follows', `${firebaseUser.uid}_${isPagePost && page ? page.id : post.authorUid}`),
          (snap) => setFollowingAuthor(snap.exists()),
          () => {}
        )
      : () => {};

    return () => {
      unsubReactions();
      unsubSave();
      unsubFollow();
    };
  }, [firebaseUser?.uid, post.id, post.authorUid, isOwn, isSponsored, isPagePost, page?.id]);

  useEffect(() => {
    if (isSponsored && sponsoredCampaignId && firebaseUser) {
      recordVerifiedAdEvent(sponsoredCampaignId, firebaseUser.uid, 'impression');
    }
  }, [isSponsored, sponsoredCampaignId, firebaseUser?.uid]);

  useEffect(() => {
    if (!showComments || isSponsored) return;
    const q = query(collection(db, 'posts', post.id, 'comments'), orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(
      q,
      async (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as CommentItem));
        setComments(list);
        const missingUids = Array.from(new Set(list.map((c) => c.authorUid))).filter(
          (u) => !commentUsers[u]
        );
        if (missingUids.length > 0) {
          const loaded: Record<string, UserProfile> = {};
          await Promise.all(
            missingUids.map(async (u) => {
              try {
                const s = await getDoc(doc(db, 'users', u));
                if (s.exists()) loaded[u] = s.data() as UserProfile;
              } catch {
                // ignore inaccessible user
              }
            })
          );
          if (Object.keys(loaded).length > 0) {
            setCommentUsers((prev) => ({ ...prev, ...loaded }));
          }
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `posts/${post.id}/comments`)
    );
    return () => unsub();
  }, [showComments, post.id, isSponsored]);

  const handleSetReaction = async (chosenReaction: ReactionType) => {
    setShowReactionTray(false);
    if (isSponsored) return;
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to react to posts.', 'error');
      return;
    }
    const likeRef = doc(db, 'posts', post.id, 'likes', firebaseUser.uid);
    const postRef = doc(db, 'posts', post.id);

    try {
      if (myReaction === chosenReaction) {
        const batch = writeBatch(db);
        batch.delete(likeRef);
        batch.update(postRef, { likesCount: increment(-1), updatedAt: serverTimestamp() });
        await batch.commit();
      } else if (myReaction) {
        await updateDoc(likeRef, { reaction: chosenReaction });
      } else {
        const batch = writeBatch(db);
        batch.set(likeRef, {
          uid: firebaseUser.uid,
          reaction: chosenReaction,
          createdAt: serverTimestamp(),
        });
        batch.update(postRef, { likesCount: increment(1), updatedAt: serverTimestamp() });
        await batch.commit();
        if (post.authorUid !== firebaseUser.uid) {
          await createNotification({
            recipientUid: post.authorUid,
            actorUid: firebaseUser.uid,
            type: 'post_like',
            title: `Post Reaction ${REACTION_META[chosenReaction].emoji}`,
            body: `${profile?.displayName || 'Someone'} reacted (${REACTION_META[chosenReaction].label}) to your post.`,
            targetTab: 'home',
          });
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `posts/${post.id}/likes`);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSponsored) return;
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to comment.', 'error');
      return;
    }
    if (!commentText.trim()) return;
    const cId = makeSafeId('cmt');
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'posts', post.id, 'comments', cId), {
        authorUid: firebaseUser.uid,
        parentCommentId: replyTo ? replyTo.id : '',
        text: commentText.trim().slice(0, 1500),
        createdAt: serverTimestamp(),
      });
      batch.update(doc(db, 'posts', post.id), {
        commentsCount: increment(1),
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
      setCommentText('');
      setReplyTo(null);
      if (post.authorUid !== firebaseUser.uid) {
        await createNotification({
          recipientUid: post.authorUid,
          actorUid: firebaseUser.uid,
          type: 'post_comment',
          title: replyTo ? 'New Reply' : 'New Comment',
          body: `${profile?.displayName || 'Someone'} commented on your post.`,
          targetTab: 'home',
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `posts/${post.id}/comments/${cId}`);
    }
  };

  const handleUpdateComment = async (commentId: string) => {
    if (!editingCommentText.trim()) return;
    try {
      await updateDoc(doc(db, 'posts', post.id, 'comments', commentId), {
        text: editingCommentText.trim().slice(0, 1500),
      });
      setEditingCommentId(null);
      setEditingCommentText('');
      pushToast('Comment updated.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `posts/${post.id}/comments/${commentId}`);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    try {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'posts', post.id, 'comments', commentId));
      batch.update(doc(db, 'posts', post.id), {
        commentsCount: increment(-1),
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
      pushToast('Comment deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `posts/${post.id}/comments/${commentId}`);
    }
  };

  const handleRepost = async () => {
    if (isSponsored) return;
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to repost.', 'error');
      return;
    }
    const shareId = makeSafeId('post');
    try {
      const batch = writeBatch(db);
      batch.set(doc(db, 'posts', shareId), {
        authorUid: firebaseUser.uid,
        authorType: 'user',
        postType: 'shared',
        content: `Reposted from @${
          isPagePost && page ? page.username : author?.username || 'creator'
        }: ${post.content.slice(0, 400)}`,
        mediaUrls: post.mediaUrls || [],
        sharedPostId: post.id,
        visibility: 'public',
        likesCount: 0,
        commentsCount: 0,
        sharesCount: 0,
        organicImpressions: 0,
        isBoosted: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.update(doc(db, 'posts', post.id), {
        sharesCount: increment(1),
        updatedAt: serverTimestamp(),
      });
      await batch.commit();
      pushToast('Shared to your feed!', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `posts/${shareId}`);
    }
  };

  const handleToggleSave = async () => {
    if (isSponsored) return;
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to save posts.', 'error');
      return;
    }
    const saveId = `${firebaseUser.uid}_${post.id}`;
    try {
      if (saved) {
        await deleteDoc(doc(db, 'savedPosts', saveId));
        pushToast('Removed from saved posts.', 'info');
      } else {
        await setDoc(doc(db, 'savedPosts', saveId), {
          uid: firebaseUser.uid,
          targetId: post.id,
          targetType: 'post',
          createdAt: serverTimestamp(),
        });
        pushToast('Post saved!', 'success');
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `savedPosts/${saveId}`);
    }
  };

  const handleSaveEdit = async () => {
    if (!editDraft.trim() && (!post.mediaUrls || post.mediaUrls.length === 0)) return;
    try {
      await updateDoc(doc(db, 'posts', post.id), {
        content: editDraft.trim().slice(0, 5000),
        visibility: editVisibility,
        updatedAt: serverTimestamp(),
      });
      setEditing(false);
      pushToast('Post updated.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `posts/${post.id}`);
    }
  };

  const handleDelete = async () => {
    try {
      await deleteDoc(doc(db, 'posts', post.id));
      pushToast('Post deleted.', 'info');
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `posts/${post.id}`);
    }
  };

  const timeStr = post.createdAt?.toDate
    ? post.createdAt.toDate().toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
    : 'Just now';

  // Compute top reaction emojis from real reaction records
  const reactionCounts = reactions.reduce<Record<string, number>>((acc, r) => {
    const key = r.reaction || 'like';
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  const topReactions = Object.entries(reactionCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 3)
    .map(([key]) => REACTION_META[key as ReactionType]?.emoji || '👍');

  const displayCount = Math.max(post.likesCount || 0, reactions.length);

  // Organize threaded comments: top-level + grouped replies
  const topComments = comments.filter((c) => !c.parentCommentId);
  const commentIdsSet = new Set(comments.map((c) => c.id));
  const repliesByParent = comments.reduce<Record<string, CommentItem[]>>((acc, c) => {
    if (c.parentCommentId && commentIdsSet.has(c.parentCommentId)) {
      acc[c.parentCommentId] = acc[c.parentCommentId] || [];
      acc[c.parentCommentId].push(c);
    }
    return acc;
  }, {});
  const orphanReplies = comments.filter(
    (c) => c.parentCommentId && !commentIdsSet.has(c.parentCommentId)
  );
  const orderedThreads = [...topComments, ...orphanReplies];

  const renderCommentNode = (c: CommentItem, isReply: boolean) => {
    const cUser = commentUsers[c.authorUid];
    const canDelete = c.authorUid === firebaseUser?.uid || isModerator;
    const canEdit = c.authorUid === firebaseUser?.uid;
    const cTime = c.createdAt?.toDate
      ? c.createdAt.toDate().toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
      : '';

    return (
      <div key={c.id} className={`flex items-start gap-2.5 ${isReply ? 'ml-8' : ''}`}>
        <button
          type="button"
          onClick={() => onOpenProfile(c.authorUid)}
          className="cursor-pointer shrink-0 mt-0.5"
        >
          <Avatar src={cUser?.photoUrl} name={cUser?.displayName || 'U'} size="xs" />
        </button>
        <div className="flex-1 rounded-xl bg-slate-100 dark:bg-[#0A0B0E] px-3 py-2 text-xs">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 min-w-0">
              <button
                type="button"
                onClick={() => onOpenProfile(c.authorUid)}
                className="font-semibold text-slate-900 dark:text-white hover:text-[#D4AF37] truncate cursor-pointer"
              >
                {cUser?.displayName || 'Member'}
              </button>
              {cTime && <span className="text-[10px] text-slate-400">{cTime}</span>}
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setReplyTo(c);
                  setEditingCommentId(null);
                }}
                className="text-[11px] text-[#3B82F6] hover:underline cursor-pointer"
              >
                Reply
              </button>
              {canEdit && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingCommentId(c.id);
                    setEditingCommentText(c.text);
                  }}
                  className="text-[11px] text-slate-500 hover:text-slate-900 dark:hover:text-white cursor-pointer"
                >
                  Edit
                </button>
              )}
              {canDelete && (
                <button
                  type="button"
                  onClick={() => handleDeleteComment(c.id)}
                  className="text-[11px] text-rose-500 hover:underline cursor-pointer"
                >
                  Delete
                </button>
              )}
            </div>
          </div>

          {editingCommentId === c.id ? (
            <div className="mt-1.5 flex items-center gap-2">
              <input
                type="text"
                value={editingCommentText}
                onChange={(e) => setEditingCommentText(e.target.value)}
                className="flex-1 h-8 px-2.5 rounded-lg border border-[#D4AF37] bg-white dark:bg-[#13151B] text-xs"
              />
              <button
                type="button"
                onClick={() => handleUpdateComment(c.id)}
                className="h-8 px-2.5 rounded-lg bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Save
              </button>
              <button
                type="button"
                onClick={() => setEditingCommentId(null)}
                className="h-8 px-2 text-slate-400 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          ) : (
            <p className="text-slate-700 dark:text-slate-300 mt-0.5 break-words">{c.text}</p>
          )}
        </div>
      </div>
    );
  };

  return (
    <article
      className={`rounded-2xl border bg-white dark:bg-[#13151B] p-4 sm:p-5 space-y-3.5 ${
        isSponsored ? 'border-[#D4AF37]/40' : 'border-slate-200 dark:border-white/10'
      }`}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => onOpenProfile(post.authorUid)}
            className="cursor-pointer shrink-0"
          >
            <Avatar
              src={isPagePost ? page?.avatarUrl : author?.photoUrl}
              name={isPagePost ? page?.name || 'Page' : author?.displayName || 'User'}
              size="md"
            />
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => onOpenProfile(post.authorUid)}
                className="font-semibold text-sm text-slate-900 dark:text-white hover:text-[#D4AF37] truncate cursor-pointer"
              >
                {isPagePost ? page?.name : author?.displayName || 'HEARTHLINE Member'}
              </button>
              {!isOwn && (
                <button
                  type="button"
                  onClick={async () => {
                    if (!firebaseUser) return;
                    const targetId = isPagePost && page ? page.id : post.authorUid;
                    const targetType = isPagePost && page ? 'page' : 'user';
                    const next = await toggleFollow(
                      firebaseUser.uid,
                      targetId,
                      targetType,
                      followingAuthor,
                      profile?.displayName || 'Someone'
                    );
                    setFollowingAuthor(next);
                  }}
                  className="inline-flex items-center gap-1 text-xs font-medium text-[#3B82F6] hover:underline cursor-pointer shrink-0"
                >
                  {!followingAuthor && <UserPlus className="w-3 h-3" />}
                  {followingAuthor ? 'Following' : 'Follow'}
                </button>
              )}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
              <span>@{isPagePost ? page?.username : author?.username || 'member'}</span>
              <span aria-hidden="true">·</span>
              {isSponsored ? (
                <span className="font-semibold text-[#D4AF37]">Sponsored</span>
              ) : (
                <>
                  <span>{timeStr}</span>
                  <span aria-hidden="true">·</span>
                  <span className="capitalize">
                    {isPagePost ? 'Page' : post.visibility.replace('_', ' ')}
                  </span>
                  {post.sharedPostId && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span>Repost</span>
                    </>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        <div className="relative">
          <button
            type="button"
            onClick={() => setMenuOpen((o) => !o)}
            className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
            aria-label="Post options"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>
          {menuOpen && (
            <div className="absolute right-0 mt-1 w-44 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#1B1E26] shadow-xl py-1 z-20 text-xs">
              {(isOwn || isModerator || canModerate) && (
                <>
                  {(isOwn || (isPagePost && canModerate)) && (
                    <button
                      type="button"
                      onClick={() => {
                        setEditing(true);
                        setMenuOpen(false);
                      }}
                      className="w-full px-3.5 py-2.5 text-left flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                    >
                      <Pencil className="w-3.5 h-3.5" /> Edit Post
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => {
                      handleDelete();
                      setMenuOpen(false);
                    }}
                    className="w-full px-3.5 py-2.5 text-left flex items-center gap-2 text-rose-500 hover:bg-rose-500/10 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Delete Post
                  </button>
                </>
              )}
              {!isOwn && onHidePost && (
                <button
                  type="button"
                  onClick={() => {
                    onHidePost(post.id);
                    setMenuOpen(false);
                  }}
                  className="w-full px-3.5 py-2.5 text-left flex items-center gap-2 hover:bg-slate-100 dark:hover:bg-white/5 cursor-pointer"
                >
                  <EyeOff className="w-3.5 h-3.5" /> Hide Post
                </button>
              )}
              <button
                type="button"
                onClick={async () => {
                  if (!firebaseUser) return;
                  await submitReport({
                    reporterUid: firebaseUser.uid,
                    targetType: 'post',
                    targetId: post.id,
                    reason: 'Policy or spam concern',
                  });
                  pushToast('Report submitted to moderation team.', 'info');
                  setMenuOpen(false);
                }}
                className="w-full px-3.5 py-2.5 text-left flex items-center gap-2 text-amber-500 hover:bg-amber-500/10 cursor-pointer"
              >
                <Flag className="w-3.5 h-3.5" /> Report Post
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Content */}
      {editing ? (
        <div className="space-y-2.5">
          <textarea
            rows={3}
            value={editDraft}
            onChange={(e) => setEditDraft(e.target.value)}
            className="w-full p-3 rounded-xl border border-[#D4AF37] bg-slate-50 dark:bg-[#0A0B0E] text-sm"
          />
          <div className="flex items-center justify-between gap-2">
            {post.authorType === 'user' ? (
              <select
                value={editVisibility}
                onChange={(e) => setEditVisibility(e.target.value as Post['visibility'])}
                className="h-9 px-3 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
              >
                <option value="public">Public</option>
                <option value="friends">Friends Only</option>
                <option value="only_me">Only Me</option>
              </select>
            ) : (
              <span />
            )}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="px-3 py-1.5 rounded-lg text-xs text-slate-500 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveEdit}
                className="px-3.5 py-1.5 rounded-lg bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      ) : (
        post.content && (
          <p className="text-[15px] leading-relaxed text-slate-800 dark:text-slate-200 whitespace-pre-wrap break-words">
            {post.content}
          </p>
        )
      )}

      {/* Media */}
      {post.mediaUrls && post.mediaUrls.length > 0 && (
        <div className={`grid gap-2 ${post.mediaUrls.length > 1 ? 'grid-cols-2' : 'grid-cols-1'}`}>
          {post.mediaUrls.map((url, idx) =>
            isVideoMediaUrl(url, post.postType) ? (
              <video
                key={idx}
                src={url}
                controls
                muted
                playsInline
                onPlay={async () => {
                  if (
                    isSponsored &&
                    sponsoredCampaignId &&
                    firebaseUser &&
                    !videoViewTrackedRef.current
                  ) {
                    videoViewTrackedRef.current = true;
                    await recordVerifiedAdEvent(sponsoredCampaignId, firebaseUser.uid, 'video_view');
                  }
                }}
                className="w-full max-h-[420px] rounded-xl bg-black object-contain"
              />
            ) : brokenImages.has(idx) ? (
              <div
                key={idx}
                className="w-full h-48 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-100 dark:bg-[#0A0B0E] flex flex-col items-center justify-center gap-1.5 text-slate-400 text-xs"
              >
                <ImageIcon className="w-6 h-6" />
                <span>Media unavailable</span>
              </div>
            ) : (
              <img
                key={idx}
                src={url}
                alt="Post attachment"
                loading="lazy"
                referrerPolicy="no-referrer"
                onError={() => setBrokenImages((prev) => new Set(prev).add(idx))}
                onClick={async () => {
                  if (isSponsored && sponsoredCampaignId && firebaseUser) {
                    await recordVerifiedAdEvent(sponsoredCampaignId, firebaseUser.uid, 'click');
                  }
                }}
                className="w-full max-h-[420px] rounded-xl object-cover bg-slate-100 dark:bg-black/40"
              />
            )
          )}
        </div>
      )}

      {/* Link Preview (strictly sanitized http/https URLs only) */}
      {safeLinkUrl && (
        <a
          href={safeLinkUrl}
          target="_blank"
          rel="noopener noreferrer"
          onClick={async () => {
            if (isSponsored && sponsoredCampaignId && firebaseUser) {
              await recordVerifiedAdEvent(sponsoredCampaignId, firebaseUser.uid, 'click');
            }
          }}
          className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-3 hover:border-[#D4AF37]/50 transition-colors"
        >
          <div className="min-w-0">
            <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
              {post.linkTitle || safeLinkUrl}
            </p>
            <p className="text-[11px] text-slate-500 truncate">{safeLinkUrl}</p>
          </div>
          <ExternalLink className="w-4 h-4 text-[#3B82F6] shrink-0" />
        </a>
      )}

      {/* Sponsored Call-to-Action Bar */}
      {isSponsored && (isPagePost || onSponsoredNavigate) && (
        <div className="flex items-center justify-between gap-3 rounded-xl border border-[#D4AF37]/25 bg-[#D4AF37]/10 px-3.5 py-2.5 text-xs">
          <div className="min-w-0">
            <p className="font-semibold text-slate-900 dark:text-white truncate">
              {post.linkTitle || (isPagePost && page ? page.name : 'Sponsored Promotion')}
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {isPagePost ? 'Public Page Promotion' : 'Verified HEARTHLINE Campaign'}
            </p>
          </div>
          <button
            type="button"
            onClick={async () => {
              if (sponsoredCampaignId && firebaseUser) {
                await recordVerifiedAdEvent(sponsoredCampaignId, firebaseUser.uid, 'click');
              }
              if (safeLinkUrl) {
                window.open(safeLinkUrl, '_blank', 'noopener,noreferrer');
              } else {
                onSponsoredNavigate?.();
              }
            }}
            className="px-3.5 py-2 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold hover:bg-[#E5C158] cursor-pointer shrink-0 whitespace-nowrap"
          >
            {isPagePost ? 'Explore Page' : 'Learn More'}
          </button>
        </div>
      )}

      {/* Reaction Summary Strip */}
      {!isSponsored && (displayCount > 0 || post.commentsCount > 0 || post.sharesCount > 0) && (
        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-1">
          <div className="flex items-center gap-1.5">
            {topReactions.length > 0 && (
              <span className="tracking-tight" aria-hidden="true">
                {topReactions.join('')}
              </span>
            )}
            {displayCount > 0 && (
              <span className="font-mono tabular-nums">{displayCount}</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {post.commentsCount > 0 && (
              <button
                type="button"
                onClick={() => setShowComments((s) => !s)}
                className="hover:underline cursor-pointer tabular-nums"
              >
                {post.commentsCount} {post.commentsCount === 1 ? 'comment' : 'comments'}
              </button>
            )}
            {post.sharesCount > 0 && (
              <span className="tabular-nums">
                {post.sharesCount} {post.sharesCount === 1 ? 'share' : 'shares'}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Boost Post Banner for Own Eligible Public Post */}
      {isOwn && post.visibility === 'public' && onBoostPost && !isSponsored && (
        <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-white/5">
          <span className="text-xs text-slate-500">
            {post.isBoosted ? 'Boost campaign linked' : 'Reach more people in Dhaka & beyond'}
          </span>
          <button
            type="button"
            onClick={() => onBoostPost(post)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#D4AF37]/15 text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-semibold hover:bg-[#D4AF37] hover:text-[#0A0B0E] transition-colors cursor-pointer whitespace-nowrap"
          >
            <Megaphone className="w-3.5 h-3.5" />
            {post.isBoosted ? 'Boost Again' : 'Boost Post'}
          </button>
        </div>
      )}

      {/* Engagement Actions */}
      <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-white/10 text-xs text-slate-500 dark:text-slate-400">
        <div className="flex items-center gap-0.5 sm:gap-1.5 relative">
          {/* Reaction button + tray */}
          <div
            className="relative flex items-center"
            onMouseLeave={() => setShowReactionTray(false)}
          >
            {showReactionTray && !isSponsored && (
              <div className="absolute bottom-full left-0 mb-1.5 flex items-center gap-1 px-2 py-1.5 rounded-2xl border border-slate-200 dark:border-white/15 bg-white dark:bg-[#1B1E26] shadow-2xl z-30">
                {REACTION_LIST.map((rKey) => (
                  <button
                    key={rKey}
                    type="button"
                    title={REACTION_META[rKey].label}
                    onClick={() => handleSetReaction(rKey)}
                    className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg hover:scale-125 transition-transform cursor-pointer ${
                      myReaction === rKey ? 'bg-[#D4AF37]/20 ring-1 ring-[#D4AF37]' : ''
                    }`}
                  >
                    {REACTION_META[rKey].emoji}
                  </button>
                ))}
              </div>
            )}

            <button
              type="button"
              onClick={() => handleSetReaction(myReaction || 'like')}
              onMouseEnter={() => !isSponsored && setShowReactionTray(true)}
              className={`inline-flex items-center gap-1.5 min-h-[40px] px-2.5 py-2 rounded-l-xl transition-colors cursor-pointer whitespace-nowrap ${
                myReaction
                  ? `${REACTION_META[myReaction].textColor} ${REACTION_META[myReaction].bgColor} font-semibold`
                  : 'hover:bg-slate-100 dark:hover:bg-white/5'
              }`}
            >
              {myReaction ? (
                <span className="text-sm leading-none">{REACTION_META[myReaction].emoji}</span>
              ) : (
                <ThumbsUp className="w-4 h-4" />
              )}
              <span>{myReaction ? REACTION_META[myReaction].label : 'Like'}</span>
            </button>
            {!isSponsored && (
              <button
                type="button"
                aria-label="Choose reaction"
                onClick={() => setShowReactionTray((s) => !s)}
                className={`min-h-[40px] px-1.5 rounded-r-xl transition-colors cursor-pointer ${
                  myReaction
                    ? `${REACTION_META[myReaction].textColor} ${REACTION_META[myReaction].bgColor}`
                    : 'hover:bg-slate-100 dark:hover:bg-white/5'
                }`}
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={() => setShowComments((s) => !s)}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-2.5 py-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 transition-colors cursor-pointer whitespace-nowrap"
          >
            <MessageSquare className="w-4 h-4" />
            <span className="font-mono tabular-nums">{post.commentsCount}</span>
          </button>

          <button
            type="button"
            onClick={handleRepost}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-2.5 py-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Repeat2 className="w-4 h-4" />
            <span className="font-mono tabular-nums">{post.sharesCount}</span>
          </button>

          <button
            type="button"
            onClick={async () => {
              if (navigator.share) {
                try {
                  await navigator.share({
                    title: 'HEARTHLINE Post',
                    text: post.content.slice(0, 120),
                    url: window.location.href,
                  });
                } catch {}
              } else {
                await navigator.clipboard.writeText(window.location.href);
                pushToast('Post link copied.', 'info');
              }
            }}
            className="inline-flex items-center gap-1.5 min-h-[40px] px-2.5 py-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5 transition-colors cursor-pointer"
            aria-label="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>

        <button
          type="button"
          onClick={handleToggleSave}
          className={`inline-flex items-center gap-1.5 min-h-[40px] px-2.5 py-2 rounded-xl transition-colors cursor-pointer ${
            saved ? 'text-[#D4AF37] bg-[#D4AF37]/10' : 'hover:bg-slate-100 dark:hover:bg-white/5'
          }`}
          aria-label="Save post"
        >
          <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Comments Drawer */}
      {showComments && !isSponsored && (
        <div className="pt-3 border-t border-slate-200 dark:border-white/10 space-y-3">
          {orderedThreads.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-2">
              No comments yet. Be the first to reply.
            </p>
          ) : (
            <div className="space-y-2.5">
              {orderedThreads.map((c) => (
                <React.Fragment key={c.id}>
                  {renderCommentNode(c, Boolean(c.parentCommentId))}
                  {(repliesByParent[c.id] || []).map((reply) => renderCommentNode(reply, true))}
                </React.Fragment>
              ))}
            </div>
          )}

          <form onSubmit={handleAddComment} className="space-y-1.5">
            {replyTo && (
              <div className="flex items-center justify-between text-[11px] text-[#3B82F6] px-1">
                <span>Replying to {commentUsers[replyTo.authorUid]?.displayName || 'comment'}</span>
                <button type="button" onClick={() => setReplyTo(null)} className="cursor-pointer">
                  Cancel
                </button>
              </div>
            )}
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                placeholder="Write a comment..."
                className="flex-1 h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs text-slate-900 dark:text-white focus:outline-none focus:border-[#D4AF37]"
              />
              <button
                type="submit"
                className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold hover:bg-[#E5C158] cursor-pointer whitespace-nowrap"
              >
                Post
              </button>
            </div>
          </form>
        </div>
      )}
    </article>
  );
};
