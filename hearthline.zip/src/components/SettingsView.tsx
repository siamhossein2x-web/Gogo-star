import React, { useEffect, useMemo, useState } from 'react';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  ArrowLeft,
  Bell,
  Check,
  CreditCard,
  Download,
  Eye,
  FileText,
  Flag,
  Globe,
  HelpCircle,
  Image as ImageIcon,
  Info,
  Key,
  Lock,
  Loader2,
  Megaphone,
  MessageSquare,
  Moon,
  Search,
  Settings,
  Shield,
  ShieldAlert,
  Smartphone,
  Sun,
  Trash2,
  User,
  Users,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { getCloudinaryConfig, isCloudinaryConfigured, saveCloudinaryConfig } from '../lib/cloudinary';
import { useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { formatBDT } from '../lib/finance';
import { blockUser, unblockUser } from '../lib/socialActions';
import { UserProfile } from '../types/hearthline';
import { Avatar } from './Avatar';

type SettingsSectionId =
  | 'account'
  | 'security'
  | 'privacy'
  | 'notifications'
  | 'friends'
  | 'messages'
  | 'pages'
  | 'monetization'
  | 'ads'
  | 'appearance'
  | 'accessibility'
  | 'help'
  | 'data'
  | 'about';

interface SectionMeta {
  id: SettingsSectionId;
  title: string;
  subtitle: string;
  icon: React.ElementType;
}

const SETTINGS_SECTIONS: SectionMeta[] = [
  { id: 'account', title: '1. Account Settings', subtitle: 'Manage display name, username, bio, and location', icon: User },
  { id: 'security', title: '2. Security & Login', subtitle: 'Password status, email verification, and security alerts', icon: Lock },
  { id: 'privacy', title: '3. Privacy Settings', subtitle: 'Profile visibility and who can interact with you', icon: Shield },
  { id: 'notifications', title: '4. Notifications', subtitle: 'Push & in-app alerts for friends, messages, and stories', icon: Bell },
  { id: 'friends', title: '5. Friends & Followers', subtitle: 'Follow permissions and blocked accounts list', icon: Users },
  { id: 'messages', title: '6. Messages Settings', subtitle: 'Direct chat filtering and read receipts', icon: MessageSquare },
  { id: 'pages', title: '7. Pages & Communities', subtitle: 'Default page preferences and community moderation', icon: Flag },
  { id: 'monetization', title: '8. Monetization & Wallet', subtitle: '40/60 Page revenue split, creator rewards, and payout methods', icon: CreditCard },
  { id: 'ads', title: '9. Ads & Promotions', subtitle: 'Ad personalization and campaign currency (BDT ৳)', icon: Megaphone },
  { id: 'appearance', title: '10. Appearance & Language', subtitle: 'Obsidian dark mode, English & বাংলা localization', icon: Globe },
  { id: 'accessibility', title: '11. Accessibility', subtitle: 'High contrast, font scaling, and reduced motion', icon: Smartphone },
  { id: 'help', title: '12. Help & Support', subtitle: 'FAQ, contact HEARTHLINE support, and bug reports', icon: HelpCircle },
  { id: 'data', title: '13. Data & Permissions', subtitle: 'Download your personal archive and connected apps', icon: FileText },
  { id: 'about', title: '14. About HEARTHLINE', subtitle: 'Version v1.4.0, Terms of Service, and platform mission', icon: Info },
];

export const SettingsView: React.FC = () => {
  const { firebaseUser, profile, privateData, theme, setTheme, language, setLanguage, signOut } =
    useAuth();
  const { pushToast } = useToast();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();

  const [activeSection, setActiveSection] = useState<SettingsSectionId | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [busy, setBusy] = useState(false);
  const [showPrivacyCheckup, setShowPrivacyCheckup] = useState(false);

  // Editable form states
  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [username, setUsername] = useState(profile?.username || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [locationCity, setLocationCity] = useState(profile?.locationCity || '');
  const [locationCountry, setLocationCountry] = useState(profile?.locationCountry || 'Bangladesh');

  const [privacyLevel, setPrivacyLevel] = useState<'public' | 'friends' | 'private'>(
    profile?.privacyLevel || 'public'
  );

  // Preferences states
  const [notifPush, setNotifPush] = useState(true);
  const [notifEmail, setNotifEmail] = useState(true);
  const [readReceipts, setReadReceipts] = useState(true);
  const [highContrast, setHighContrast] = useState(false);
  const [fontSize, setFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');

  // Cloudinary settings
  const initialCld = getCloudinaryConfig();
  const envActive = Boolean(
    import.meta.env.VITE_CLOUDINARY_CLOUD_NAME && import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET
  );
  const [cloudName, setCloudName] = useState(initialCld.cloudName);
  const [uploadPreset, setUploadPreset] = useState(initialCld.uploadPreset);

  const [confirmDelete, setConfirmDelete] = useState(false);
  const [supportMessage, setSupportMessage] = useState('');

  // Load user preferences from Firestore on mount
  useEffect(() => {
    if (!firebaseUser) return;
    (async () => {
      try {
        const prefRef = doc(db, 'userPreferences', firebaseUser.uid);
        const snap = await getDoc(prefRef);
        if (snap.exists()) {
          const data = snap.data();
          if (typeof data.notifPush === 'boolean') setNotifPush(data.notifPush);
          if (typeof data.notifEmail === 'boolean') setNotifEmail(data.notifEmail);
          if (typeof data.readReceipts === 'boolean') setReadReceipts(data.readReceipts);
          if (typeof data.highContrast === 'boolean') setHighContrast(data.highContrast);
          if (data.fontSize) setFontSize(data.fontSize);
        }
      } catch {}
    })();
  }, [firebaseUser?.uid]);

  const [blockedUsersList, setBlockedUsersList] = useState<Array<{ id: string; blockedUid: string; profile?: UserProfile }>>([]);
  const [blockInput, setBlockInput] = useState('');

  useEffect(() => {
    if (!firebaseUser) return;
    const q = query(collection(db, 'blockedUsers'), where('blockerUid', '==', firebaseUser.uid));
    const unsub = onSnapshot(
      q,
      async (snap) => {
        const items = snap.docs.map((d) => ({ id: d.id, ...d.data() } as { id: string; blockedUid: string }));
        const detailed = await Promise.all(
          items.map(async (item) => {
            try {
              const uSnap = await getDoc(doc(db, 'users', item.blockedUid));
              return { ...item, profile: uSnap.exists() ? (uSnap.data() as UserProfile) : undefined };
            } catch {
              return item;
            }
          })
        );
        setBlockedUsersList(detailed);
      },
      () => {}
    );
    return () => unsub();
  }, [firebaseUser?.uid]);

  const handleBlockByInput = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !blockInput.trim()) return;
    const target = blockInput.trim();
    if (target === firebaseUser.uid) {
      pushToast('You cannot block yourself.', 'error');
      return;
    }
    setBusy(true);
    try {
      let targetUid = target;
      if (!target.startsWith('user_') && target.length < 20) {
        const q = query(collection(db, 'users'), where('username', '==', target.toLowerCase().replace('@', '')));
        const snaps = await getDocs(q);
        if (!snaps.empty) {
          targetUid = snaps.docs[0].id;
        }
      }
      await blockUser(firebaseUser.uid, targetUid);
      setBlockInput('');
      pushToast('User blocked successfully.', 'success');
    } catch {
      pushToast('Could not block user.', 'error');
    } finally {
      setBusy(false);
    }
  };

  const handleUnblockUser = async (blockedUid: string) => {
    if (!firebaseUser) return;
    try {
      await unblockUser(firebaseUser.uid, blockedUid);
      pushToast('User unblocked.', 'info');
    } catch {
      pushToast('Could not unblock user.', 'error');
    }
  };

  const filteredSections = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return SETTINGS_SECTIONS;
    return SETTINGS_SECTIONS.filter(
      (s) => s.title.toLowerCase().includes(q) || s.subtitle.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  const handleSaveAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    setBusy(true);
    try {
      await updateDoc(doc(db, 'users', firebaseUser.uid), {
        displayName: displayName.trim().slice(0, 50),
        username: username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 30),
        bio: bio.trim().slice(0, 250),
        locationCity: locationCity.trim().slice(0, 50),
        locationCountry: locationCountry.trim().slice(0, 50),
        updatedAt: serverTimestamp(),
      });
      pushToast('Account profile settings saved successfully.', 'success');
      setActiveSection(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    } finally {
      setBusy(false);
    }
  };

  const handleSavePreferences = async (updates: Record<string, any>) => {
    if (!firebaseUser) return;
    try {
      const prefRef = doc(db, 'userPreferences', firebaseUser.uid);
      await setDoc(
        prefRef,
        {
          ...updates,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );
      pushToast('Preferences updated.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `userPreferences/${firebaseUser.uid}`);
    }
  };

  const handlePrivacySave = async (val: 'public' | 'friends' | 'private') => {
    setPrivacyLevel(val);
    if (!firebaseUser) return;
    try {
      await updateDoc(doc(db, 'users', firebaseUser.uid), {
        privacyLevel: val,
        updatedAt: serverTimestamp(),
      });
      pushToast(`Account privacy updated to ${val}.`, 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    }
  };

  const handleSaveCloudinary = (e: React.FormEvent) => {
    e.preventDefault();
    saveCloudinaryConfig(cloudName, uploadPreset);
    pushToast('Cloudinary unsigned upload preset saved locally.', 'success');
  };

  const handleDeactivateToggle = async () => {
    if (!firebaseUser || !profile) return;
    const next = profile.accountStatus === 'deactivated' ? 'active' : 'deactivated';
    try {
      await updateDoc(doc(db, 'users', firebaseUser.uid), {
        accountStatus: next,
        updatedAt: serverTimestamp(),
      });
      pushToast(
        next === 'deactivated' ? 'Account marked as deactivated.' : 'Account reactivated.',
        'info'
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    }
  };

  const handleRequestDeletion = async () => {
    if (!firebaseUser) return;
    try {
      await updateDoc(doc(db, 'users', firebaseUser.uid), {
        accountStatus: 'pending_deletion',
        updatedAt: serverTimestamp(),
      });
      setConfirmDelete(false);
      pushToast('Account deletion request recorded. Signing out...', 'info');
      await signOut();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    }
  };

  const handleSendSupport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser || !supportMessage.trim()) return;
    setBusy(true);
    try {
      const repId = `sup_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      await setDoc(doc(db, 'reports', repId), {
        reporterUid: firebaseUser.uid,
        targetType: 'system',
        targetId: 'hearthline_support',
        reason: 'User Support Request',
        details: supportMessage.trim().slice(0, 1000),
        status: 'open',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setSupportMessage('');
      pushToast('Support request sent to HEARTHLINE team.', 'success');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'reports');
    } finally {
      setBusy(false);
    }
  };

  // Render Sub-Section View
  if (activeSection) {
    const meta = SETTINGS_SECTIONS.find((s) => s.id === activeSection);
    const Icon = meta?.icon || Settings;

    return (
      <div className="max-w-2xl mx-auto space-y-5 animate-in fade-in duration-200">
        <div className="flex items-center gap-3 pb-2 border-b border-slate-200 dark:border-white/10">
          <button
            type="button"
            onClick={() => setActiveSection(null)}
            className="w-10 h-10 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] flex items-center justify-center text-slate-700 dark:text-slate-200 hover:border-[#D4AF37] cursor-pointer"
            aria-label="Back to Settings overview"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-display text-lg font-bold flex items-center gap-2 text-slate-900 dark:text-white">
              <Icon className="w-5 h-5 text-[#D4AF37]" /> {meta?.title}
            </h1>
            <p className="text-xs text-slate-500">{meta?.subtitle}</p>
          </div>
        </div>

        {/* 1. Account Settings */}
        {activeSection === 'account' && (
          <form onSubmit={handleSaveAccount} className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Display Name</label>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full h-10 px-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Username (@handle)</label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full h-10 px-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] font-mono"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Bio</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">City</label>
                <input
                  type="text"
                  value={locationCity}
                  onChange={(e) => setLocationCity(e.target.value)}
                  className="w-full h-10 px-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Country</label>
                <input
                  type="text"
                  value={locationCountry}
                  onChange={(e) => setLocationCountry(e.target.value)}
                  className="w-full h-10 px-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                />
              </div>
            </div>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busy}
                className="px-5 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                Save Changes
              </button>
            </div>
          </form>
        )}

        {/* 2. Security & Login */}
        {activeSection === 'security' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div className="flex items-center justify-between p-4 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
              <div>
                <p className="font-semibold text-sm text-slate-900 dark:text-white">Email Authentication</p>
                <p className="text-slate-500 font-mono mt-0.5">{firebaseUser?.email || 'No email'}</p>
              </div>
              <span
                className={`px-3 py-1 rounded-full font-semibold ${
                  firebaseUser?.emailVerified
                    ? 'bg-emerald-500/15 text-emerald-500'
                    : 'bg-amber-500/15 text-amber-500'
                }`}
              >
                {firebaseUser?.emailVerified ? 'Verified' : 'Unverified'}
              </span>
            </div>

            <div className="space-y-2 pt-2">
              <h3 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-[#D4AF37]" /> Session Security
              </h3>
              <p className="text-slate-500 leading-relaxed">
                HEARTHLINE uses secure Google OAuth and token-based Firebase sessions. Your credentials remain protected by Firebase Auth encryption protocols.
              </p>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}

        {/* 3. Privacy Settings & Blocked Users Management */}
        {activeSection === 'privacy' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-6 text-xs shadow-sm">
            <div className="space-y-3">
              <h3 className="font-semibold text-slate-900 dark:text-white">Profile Visibility Level</h3>
              <div className="grid grid-cols-3 gap-2">
                {(['public', 'friends', 'private'] as const).map((lvl) => (
                  <button
                    key={lvl}
                    type="button"
                    onClick={() => handlePrivacySave(lvl)}
                    className={`py-3 rounded-xl border font-semibold capitalize cursor-pointer transition-colors ${
                      privacyLevel === lvl
                        ? 'border-[#D4AF37] bg-[#D4AF37]/15 text-[#D4AF37]'
                        : 'border-slate-200 dark:border-white/10 text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
              <p className="text-slate-500 leading-relaxed">
                <strong>Public:</strong> Anyone on HEARTHLINE can view your profile and public posts.<br />
                <strong>Friends:</strong> Only confirmed friends can see your activity.<br />
                <strong>Private:</strong> Strictly restricted access.
              </p>
            </div>

            {/* Blocked Users Management */}
            <div className="pt-4 border-t border-slate-200 dark:border-white/10 space-y-3">
              <h3 className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-500" /> Blocked Users Management ({blockedUsersList.length})
              </h3>
              <p className="text-slate-500">
                Blocked users cannot view your profile, send you messages, or interact with your posts.
              </p>

              <form onSubmit={handleBlockByInput} className="flex gap-2">
                <input
                  type="text"
                  value={blockInput}
                  onChange={(e) => setBlockInput(e.target.value)}
                  placeholder="Enter username (@handle) or User UID to block..."
                  className="flex-1 h-10 px-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                />
                <button
                  type="submit"
                  disabled={busy}
                  className="px-4 py-2 rounded-xl bg-rose-600 text-white font-semibold cursor-pointer disabled:opacity-50"
                >
                  Block User
                </button>
              </form>

              {blockedUsersList.length === 0 ? (
                <p className="text-slate-400 py-3">No blocked users.</p>
              ) : (
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {blockedUsersList.map((bu) => (
                    <div
                      key={bu.id}
                      className="flex items-center justify-between p-2.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Avatar src={bu.profile?.photoUrl} name={bu.profile?.displayName || 'User'} size="sm" />
                        <div className="min-w-0">
                          <p className="font-semibold text-slate-900 dark:text-white truncate">
                            {bu.profile?.displayName || 'Unknown User'}
                          </p>
                          <p className="text-[11px] text-slate-500 font-mono truncate">
                            @{bu.profile?.username || bu.blockedUid.slice(0, 10)}
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleUnblockUser(bu.blockedUid)}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-white/15 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-white/10 font-semibold cursor-pointer"
                      >
                        Unblock
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}

        {/* 4. Notifications */}
        {activeSection === 'notifications' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">Push Notifications</p>
                <p className="text-slate-500 text-[11px]">Receive real-time alerts for messages and friend requests.</p>
              </div>
              <input
                type="checkbox"
                checked={notifPush}
                onChange={(e) => {
                  setNotifPush(e.target.checked);
                  handleSavePreferences({ notifPush: e.target.checked });
                }}
                className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">Email Digest</p>
                <p className="text-slate-500 text-[11px]">Receive weekly activity summary via email.</p>
              </div>
              <input
                type="checkbox"
                checked={notifEmail}
                onChange={(e) => {
                  setNotifEmail(e.target.checked);
                  handleSavePreferences({ notifEmail: e.target.checked });
                }}
                className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
              />
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Save &amp; Close
              </button>
            </div>
          </div>
        )}

        {/* 5. Friends & Followers */}
        {activeSection === 'friends' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <h3 className="font-semibold text-slate-900 dark:text-white">Follower &amp; Connection Controls</h3>
            <p className="text-slate-500 leading-relaxed">
              Manage who can send you friend requests and follow your public updates. Confirmed friendships unlock direct messaging.
            </p>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}

        {/* 6. Messages Settings */}
        {activeSection === 'messages' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">Read Receipts</p>
                <p className="text-slate-500 text-[11px]">Let others see when you have read their messages.</p>
              </div>
              <input
                type="checkbox"
                checked={readReceipts}
                onChange={(e) => {
                  setReadReceipts(e.target.checked);
                  handleSavePreferences({ readReceipts: e.target.checked });
                }}
                className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
              />
            </div>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Save &amp; Close
              </button>
            </div>
          </div>
        )}

        {/* 7. Pages & Communities */}
        {activeSection === 'pages' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <h3 className="font-semibold text-slate-900 dark:text-white">Page &amp; Community Defaults</h3>
            <p className="text-slate-500 leading-relaxed">
              Public Pages you own or moderate participate in HEARTHLINE&apos;s 40/60 revenue split when eligible. Communities provide interest-based moderation spaces.
            </p>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}

        {/* 8. Monetization & Wallet */}
        {activeSection === 'monetization' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div className="p-4 rounded-2xl border border-[#D4AF37]/30 bg-[#D4AF37]/10 space-y-2">
              <h3 className="font-bold text-slate-900 dark:text-white">Page Monetization (40/60 Rule)</h3>
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                Eligible verified Pages receive 40% of net ad revenue directly into the Page Owner&apos;s Wallet, while HEARTHLINE retains 60% for platform infrastructure.
              </p>
            </div>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Back to Settings
              </button>
            </div>
          </div>
        )}

        {/* 9. Ads & Promotions */}
        {activeSection === 'ads' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <h3 className="font-semibold text-slate-900 dark:text-white">Ads Manager &amp; Currency (BDT ৳)</h3>
            <p className="text-slate-500 leading-relaxed">
              All HEARTHLINE ad campaigns and creator boosts are billed transparently in BDT (৳) with manual payment verification (bKash, Nagad, Bank Transfer) and Admin review.
            </p>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}

        {/* 10. Appearance & Language */}
        {activeSection === 'appearance' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
              <span className="font-semibold flex items-center gap-2">
                {theme === 'dark' ? <Moon className="w-4 h-4 text-[#D4AF37]" /> : <Sun className="w-4 h-4 text-[#D4AF37]" />}
                Theme: {theme === 'dark' ? 'Obsidian Dark' : 'Light'}
              </span>
              <button
                type="button"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="px-3.5 py-2 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Switch Theme
              </button>
            </div>

            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
              <span className="font-semibold flex items-center gap-2">
                <Globe className="w-4 h-4 text-[#3B82F6]" />
                Language: {language === 'en' ? 'English' : 'বাংলা'}
              </span>
              <button
                type="button"
                onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
                className="px-3.5 py-2 rounded-xl border border-slate-300 dark:border-white/15 font-semibold cursor-pointer"
              >
                {language === 'en' ? 'বাংলা' : 'English'}
              </button>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Save &amp; Close
              </button>
            </div>
          </div>
        )}

        {/* 11. Accessibility */}
        {activeSection === 'accessibility' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div className="flex items-center justify-between p-3.5 rounded-2xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">High Contrast UI</p>
                <p className="text-slate-500 text-[11px]">Enhance border definitions and text legibility.</p>
              </div>
              <input
                type="checkbox"
                checked={highContrast}
                onChange={(e) => {
                  setHighContrast(e.target.checked);
                  handleSavePreferences({ highContrast: e.target.checked });
                }}
                className="w-4 h-4 accent-[#D4AF37] cursor-pointer"
              />
            </div>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}

        {/* 12. Help & Support */}
        {activeSection === 'help' && (
          <form onSubmit={handleSendSupport} className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Contact HEARTHLINE Support / Report Bug
              </label>
              <textarea
                rows={4}
                required
                value={supportMessage}
                onChange={(e) => setSupportMessage(e.target.value)}
                placeholder="Describe your issue or feedback..."
                className="w-full p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              />
            </div>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="submit"
                disabled={busy}
                className="px-5 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold flex items-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                Send Support Request
              </button>
            </div>
          </form>
        )}

        {/* 13. Data & Permissions */}
        {activeSection === 'data' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <h3 className="font-semibold text-slate-900 dark:text-white">Your HEARTHLINE Data Archive</h3>
            <p className="text-slate-500 leading-relaxed">
              Download a JSON summary of your account profile, posts, stories, and connections.
            </p>
            <button
              type="button"
              onClick={() => {
                const archive = { profile, privateData, exportedAt: new Date().toISOString() };
                const blob = new Blob([JSON.stringify(archive, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `hearthline_archive_${firebaseUser?.uid || 'user'}.json`;
                a.click();
                pushToast('Data archive downloaded successfully.', 'success');
              }}
              className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold inline-flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" /> Download Personal Data Archive
            </button>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 font-semibold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}

        {/* 14. About HEARTHLINE */}
        {activeSection === 'about' && (
          <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-sm">
            <div className="flex items-center gap-3">
              <span className="w-12 h-12 rounded-2xl bg-[#D4AF37] text-[#0A0B0E] flex items-center justify-center font-display font-extrabold text-xl">
                H
              </span>
              <div>
                <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">HEARTHLINE Social</h3>
                <p className="text-slate-500">Version 1.4.0 Professional Production</p>
              </div>
            </div>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              HEARTHLINE is a premium social media platform connecting friends, creators, and public Pages with verified monetization and robust privacy standards.
            </p>
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => setActiveSection(null)}
                className="px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Header & Search */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-xl font-bold flex items-center gap-2">
            <Settings className="w-5 h-5 text-[#D4AF37]" /> Settings &amp; Privacy
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage your account, privacy controls, preferences, and security across HEARTHLINE.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowPrivacyCheckup(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#3B82F6] text-white text-xs font-semibold hover:bg-blue-600 cursor-pointer transition-colors"
        >
          <Shield className="w-4 h-4" /> Privacy Checkup
        </button>
      </div>

      {/* Search within Settings */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
        <input
          type="search"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search settings (e.g. privacy, notifications, language)..."
          className="w-full h-10 pl-10 pr-4 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-xs text-slate-900 dark:text-white placeholder:text-slate-500 focus:outline-none focus:border-[#D4AF37]"
        />
      </div>

      {/* 14 Settings Sections Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {filteredSections.map((sec) => {
          const Icon = sec.icon;
          return (
            <button
              key={sec.id}
              type="button"
              onClick={() => setActiveSection(sec.id)}
              className="text-left rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-1.5 hover:border-[#D4AF37] transition-all cursor-pointer group flex items-start gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-[#D4AF37]/10 text-[#D4AF37] flex items-center justify-center shrink-0 group-hover:bg-[#D4AF37] group-hover:text-[#0A0B0E] transition-colors">
                <Icon className="w-5 h-5" />
              </div>
              <div className="min-w-0 flex-1">
                <h2 className="font-display font-semibold text-xs sm:text-sm text-slate-900 dark:text-white group-hover:text-[#D4AF37] transition-colors truncate">
                  {sec.title}
                </h2>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                  {sec.subtitle}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Cloudinary & PWA Helpers */}
      <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4 text-xs">
        <div className="flex items-center justify-between">
          <h2 className="font-display font-bold text-sm flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-[#D4AF37]" /> Cloudinary Media Uploads
          </h2>
          <span className="text-[11px] font-semibold text-emerald-500">
            {isCloudinaryConfigured() ? 'Ready' : 'Config'}
          </span>
        </div>
        {!envActive && (
          <form onSubmit={handleSaveCloudinary} className="space-y-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                value={cloudName}
                onChange={(e) => setCloudName(e.target.value)}
                placeholder="Cloudinary Cloud Name"
                className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              />
              <input
                type="text"
                value={uploadPreset}
                onChange={(e) => setUploadPreset(e.target.value)}
                placeholder="Unsigned Upload Preset"
                className="h-9 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]"
              />
            </div>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
            >
              Save Cloudinary Preset
            </button>
          </form>
        )}
      </div>

      {/* PWA Install */}
      <div className="rounded-3xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3 text-xs">
        <h2 className="font-display font-bold text-sm flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-[#3B82F6]" /> Install HEARTHLINE App (PWA)
        </h2>
        {isInstalled ? (
          <p className="text-emerald-500 font-semibold">HEARTHLINE is installed on this device.</p>
        ) : isInstallable ? (
          <button
            type="button"
            onClick={install}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
          >
            <Download className="w-4 h-4" /> Install HEARTHLINE App
          </button>
        ) : (
          <p className="text-slate-500">
            Open in Chrome or Android Edge and select &ldquo;Install App&rdquo; from the browser menu.
          </p>
        )}
      </div>

      {/* Account Actions & Sign Out */}
      <div className="rounded-3xl border border-rose-500/20 bg-white dark:bg-[#13151B] p-5 space-y-4 text-xs">
        <h2 className="font-display font-bold text-sm flex items-center gap-2 text-rose-500">
          <ShieldAlert className="w-4 h-4" /> Danger Zone &amp; Actions
        </h2>
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={handleDeactivateToggle}
            className="px-4 py-2.5 rounded-xl border border-amber-500/40 text-amber-500 font-semibold cursor-pointer"
          >
            {profile?.accountStatus === 'deactivated' ? 'Reactivate Account' : 'Deactivate Account'}
          </button>
          {!confirmDelete ? (
            <button
              type="button"
              onClick={() => setConfirmDelete(true)}
              className="px-4 py-2.5 rounded-xl bg-rose-500/15 text-rose-500 font-semibold cursor-pointer"
            >
              Request Account Deletion
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-rose-500 font-semibold">Are you sure?</span>
              <button
                type="button"
                onClick={handleRequestDeletion}
                className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-semibold cursor-pointer"
              >
                Yes, Delete
              </button>
              <button
                type="button"
                onClick={() => setConfirmDelete(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 cursor-pointer"
              >
                Cancel
              </button>
            </div>
          )}
          <button
            type="button"
            onClick={signOut}
            className="ml-auto px-4 py-2.5 rounded-xl border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-300 font-semibold inline-flex items-center gap-2 hover:border-rose-500 cursor-pointer"
          >
            <Trash2 className="w-4 h-4 text-rose-500" /> Sign Out
          </button>
        </div>
      </div>

      {/* Privacy Checkup Modal */}
      {showPrivacyCheckup && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl border border-[#D4AF37]/40 bg-white dark:bg-[#13151B] p-6 space-y-4 text-xs shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base flex items-center gap-2 text-slate-900 dark:text-white">
                <Shield className="w-5 h-5 text-[#3B82F6]" /> Privacy Checkup Wizard
              </h3>
              <button
                type="button"
                onClick={() => setShowPrivacyCheckup(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
              Your profile privacy is currently set to <strong className="capitalize text-[#D4AF37]">{privacyLevel}</strong>.
            </p>
            <div className="space-y-2">
              <p className="font-semibold text-slate-900 dark:text-white">Quick Review:</p>
              <ul className="space-y-1.5 text-slate-500 list-disc list-inside">
                <li>Email verification: {firebaseUser?.emailVerified ? 'Verified' : 'Unverified'}</li>
                <li>Profile indexing: Enabled</li>
                <li>Friend request filtering: Active</li>
              </ul>
            </div>
            <button
              type="button"
              onClick={() => {
                setShowPrivacyCheckup(false);
                pushToast('Privacy Checkup completed successfully.', 'success');
              }}
              className="w-full h-11 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold cursor-pointer"
            >
              All Set — Finish Checkup
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
