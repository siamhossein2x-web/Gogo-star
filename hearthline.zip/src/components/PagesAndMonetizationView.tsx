import React, { useEffect, useState } from 'react';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
} from 'firebase/firestore';
import {
  BarChart3,
  CheckCircle2,
  Coins,
  Flag,
  Lock,
  Megaphone,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  Trash2,
  UserPlus,
  X,
} from 'lucide-react';
import { db, handleFirestoreError, makeSafeId, OperationType } from '../lib/firebase';
import {
  PageLedgerEntry,
  PageRole,
  PageRoleType,
  PageWallet,
  Post,
  PublicPage,
  UserProfile,
} from '../types/hearthline';
import { createNotification, useAuth } from '../context/AuthContext';
import { useToast } from './Toast';
import { Avatar } from './Avatar';
import { PostCard } from './PostCard';
import { MediaUploadInput } from './MediaUploadInput';
import { BRAND_ASSETS } from '../lib/assets';
import { formatBDT } from '../lib/finance';
import { submitReport, toggleFollow } from '../lib/socialActions';

interface Props {
  onOpenProfile: (uid: string) => void;
  onPromotePage: (page: PublicPage) => void;
  onOpenWallet: () => void;
}

interface PageMonetizationApplication {
  id: string;
  pageId: string;
  ownerUid: string;
  followersCount: number;
  pageAgeDays: number;
  status: 'pending' | 'approved' | 'rejected';
  reviewNote?: string;
  createdAt?: Timestamp;
}

const PAGE_CATEGORIES = [
  'Media & Entertainment',
  'Technology & Software',
  'Education & Culture',
  'Food & Lifestyle',
  'Business & Commerce',
];

export const PagesAndMonetizationView: React.FC<Props> = ({
  onOpenProfile,
  onPromotePage,
  onOpenWallet,
}) => {
  const { firebaseUser, profile, platformSettings } = useAuth();
  const { pushToast } = useToast();

  const [pages, setPages] = useState<PublicPage[]>([]);
  const [myRoleByPage, setMyRoleByPage] = useState<Record<string, PageRoleType>>({});
  const [directoryFilter, setDirectoryFilter] = useState<'all' | 'mine' | 'following'>('all');
  const [searchText, setSearchText] = useState('');

  const [selectedPage, setSelectedPage] = useState<PublicPage | null>(null);
  const [pageSubTab, setPageSubTab] = useState<'posts' | 'monetization' | 'roles' | 'settings'>('posts');

  const [pagePosts, setPagePosts] = useState<Post[]>([]);
  const [pageRoles, setPageRoles] = useState<PageRole[]>([]);
  const [pageWallet, setPageWallet] = useState<PageWallet | null>(null);
  const [pageLedger, setPageLedger] = useState<PageLedgerEntry[]>([]);
  const [usersMap, setUsersMap] = useState<Record<string, UserProfile>>({});
  const [followingPageIds, setFollowingPageIds] = useState<Set<string>>(new Set());

  // Create Page modal
  const [showCreate, setShowCreate] = useState(false);
  const [pName, setPName] = useState('');
  const [pUsername, setPUsername] = useState('');
  const [pCategory, setPCategory] = useState('Media & Entertainment');
  const [pDesc, setPDesc] = useState('');
  const [pCountry, setPCountry] = useState('Bangladesh');
  const [pAvatar, setPAvatar] = useState('');
  const [pCover, setPCover] = useState('');
  const [busyCreate, setBusyCreate] = useState(false);

  // Page Post composer
  const [newPostText, setNewPostText] = useState('');
  const [newPostMedia, setNewPostMedia] = useState('');
  const [newPostKind, setNewPostKind] = useState<'image' | 'video'>('image');
  const [busyPost, setBusyPost] = useState(false);

  // Role invite
  const [roleUsername, setRoleUsername] = useState('');
  const [roleType, setRoleType] = useState<Exclude<PageRoleType, 'owner'>>('admin');
  const [busyRole, setBusyRole] = useState(false);

  // Page settings edit
  const [editName, setEditName] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editCountry, setEditCountry] = useState('');
  const [editAvatar, setEditAvatar] = useState('');
  const [editCover, setEditCover] = useState('');
  const [busySettings, setBusySettings] = useState(false);

  // Monetization application state
  const [latestMonetizationApp, setLatestMonetizationApp] =
    useState<PageMonetizationApplication | null>(null);
  const [attestedOriginal, setAttestedOriginal] = useState(true);
  const [busyApply, setBusyApply] = useState(false);

  useEffect(() => {
    if (!firebaseUser) return;
    const unsub = onSnapshot(
      query(collection(db, 'pages'), orderBy('createdAt', 'desc')),
      async (snap) => {
        const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as PublicPage));
        setPages(list);
        setSelectedPage((prev) => {
          if (!prev) return null;
          return list.find((p) => p.id === prev.id) || prev;
        });

        // Resolve current user's roles across pages
        const rolesLoaded: Record<string, PageRoleType> = {};
        await Promise.all(
          list.map(async (pg) => {
            if (pg.ownerUid === firebaseUser.uid) {
              rolesLoaded[pg.id] = 'owner';
              return;
            }
            try {
              const roleSnap = await getDoc(doc(db, 'pages', pg.id, 'admins', firebaseUser.uid));
              if (roleSnap.exists()) {
                rolesLoaded[pg.id] = (roleSnap.data() as PageRole).role;
              }
            } catch {
              // ignore non-staff
            }
          })
        );
        setMyRoleByPage(rolesLoaded);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'pages')
    );

    const unsubFol = onSnapshot(
      query(
        collection(db, 'follows'),
        where('followerUid', '==', firebaseUser.uid),
        where('targetType', '==', 'page')
      ),
      (s) => setFollowingPageIds(new Set(s.docs.map((d) => d.data().targetId as string))),
      () => {}
    );

    return () => {
      unsub();
      unsubFol();
    };
  }, [firebaseUser?.uid]);

  useEffect(() => {
    if (!selectedPage || !firebaseUser) return;
    setEditName(selectedPage.name);
    setEditCategory(selectedPage.category);
    setEditDesc(selectedPage.description || '');
    setEditCountry(selectedPage.country || 'Bangladesh');
    setEditAvatar(selectedPage.avatarUrl || '');
    setEditCover(selectedPage.coverUrl || '');

    const isOwner = selectedPage.ownerUid === firebaseUser.uid;

    const uPosts = onSnapshot(
      query(
        collection(db, 'posts'),
        where('pageId', '==', selectedPage.id),
        where('visibility', '==', 'public')
      ),
      (s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as Post));
        list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
        setPagePosts(list);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'posts')
    );

    const uRoles = onSnapshot(
      collection(db, 'pages', selectedPage.id, 'admins'),
      async (s) => {
        const list = s.docs.map((d) => d.data() as PageRole);
        list.sort((a, b) => (a.role === 'owner' ? -1 : b.role === 'owner' ? 1 : 0));
        setPageRoles(list);
        const uids = list.map((r) => r.uid).filter((u) => !usersMap[u]);
        if (uids.length > 0) {
          const loaded: Record<string, UserProfile> = {};
          await Promise.all(
            uids.map(async (u) => {
              try {
                const us = await getDoc(doc(db, 'users', u));
                if (us.exists()) loaded[u] = us.data() as UserProfile;
              } catch {
                // ignore
              }
            })
          );
          if (Object.keys(loaded).length > 0) {
            setUsersMap((p) => ({ ...p, ...loaded }));
          }
        }
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `pages/${selectedPage.id}/admins`)
    );

    // STRICT BENEFICIARY RULE: Only verified Page Owner accesses pageWallets, pageLedgerEntries, and monetization applications!
    let uWallet = () => {};
    let uLedger = () => {};
    let uApp = () => {};
    if (isOwner) {
      uWallet = onSnapshot(
        doc(db, 'pageWallets', selectedPage.id),
        (s) => setPageWallet(s.exists() ? ({ id: s.id, ...s.data() } as PageWallet) : null),
        () => setPageWallet(null)
      );
      uLedger = onSnapshot(
        query(
          collection(db, 'pageLedgerEntries'),
          where('pageId', '==', selectedPage.id),
          where('ownerUid', '==', firebaseUser.uid)
        ),
        (s) => {
          const list = s.docs.map((d) => ({ id: d.id, ...d.data() } as PageLedgerEntry));
          list.sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
          setPageLedger(list);
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'pageLedgerEntries')
      );
      uApp = onSnapshot(
        query(
          collection(db, 'pageMonetizationApplications'),
          where('pageId', '==', selectedPage.id),
          where('ownerUid', '==', firebaseUser.uid)
        ),
        (s) => {
          const apps = s.docs.map(
            (d) => ({ id: d.id, ...d.data() } as PageMonetizationApplication)
          );
          apps.sort(
            (a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0)
          );
          setLatestMonetizationApp(apps[0] || null);
        },
        (err) => handleFirestoreError(err, OperationType.LIST, 'pageMonetizationApplications')
      );
    } else {
      setPageWallet(null);
      setPageLedger([]);
      setLatestMonetizationApp(null);
    }

    return () => {
      uPosts();
      uRoles();
      uWallet();
      uLedger();
      uApp();
    };
  }, [selectedPage?.id, firebaseUser?.uid]);

  const handleCreatePage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser?.emailVerified) {
      pushToast('Verify your email to create a Public Page.', 'error');
      return;
    }
    const cleanUsername = pUsername.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (cleanUsername.length < 3 || cleanUsername.length > 40) {
      pushToast('Page username must be 3–40 lowercase letters, numbers, or underscores.', 'error');
      return;
    }
    if (pName.trim().length < 2) {
      pushToast('Page name must be at least 2 characters.', 'error');
      return;
    }

    setBusyCreate(true);
    const pageId = makeSafeId('page');
    try {
      await runTransaction(db, async (tx) => {
        const unameRef = doc(db, 'usernames', cleanUsername);
        const unameSnap = await tx.get(unameRef);
        if (unameSnap.exists()) {
          throw new Error('That Page username is already taken.');
        }

        tx.set(unameRef, {
          uid: firebaseUser.uid,
          targetType: 'page',
          targetId: pageId,
          createdAt: serverTimestamp(),
        });

        tx.set(doc(db, 'pages', pageId), {
          ownerUid: firebaseUser.uid,
          name: pName.trim().slice(0, 100),
          username: cleanUsername,
          category: pCategory,
          description: pDesc.trim().slice(0, 1000),
          avatarUrl: pAvatar,
          coverUrl: pCover || BRAND_ASSETS.defaultPageCover,
          country: pCountry.trim().slice(0, 60) || 'Bangladesh',
          followersCount: 0,
          monetizationStatus: 'not_eligible',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        tx.set(doc(db, 'pages', pageId, 'admins', firebaseUser.uid), {
          uid: firebaseUser.uid,
          pageId,
          role: 'owner',
          assignedBy: firebaseUser.uid,
          createdAt: serverTimestamp(),
        });

        tx.set(doc(db, 'pageWallets', pageId), {
          pageId,
          ownerUid: firebaseUser.uid,
          pendingPoisha: 0,
          availablePoisha: 0,
          processingPoisha: 0,
          paidPoisha: 0,
          reversedPoisha: 0,
          totalVerifiedGrossPoisha: 0,
          totalDeductionsPoisha: 0,
          totalEligibleNetPoisha: 0,
          totalOwner40Poisha: 0,
          totalPlatform60Poisha: 0,
          updatedAt: serverTimestamp(),
        });
      });

      setShowCreate(false);
      setPName('');
      setPUsername('');
      setPDesc('');
      setPAvatar('');
      setPCover('');
      pushToast('Public Page & Owner-Only 40/60 Page Wallet created!', 'success');
    } catch (err) {
      if (err instanceof Error && err.message.includes('already taken')) {
        pushToast(err.message, 'error');
      } else {
        handleFirestoreError(err, OperationType.WRITE, `pages/${pageId}`);
      }
    } finally {
      setBusyCreate(false);
    }
  };

  if (selectedPage) {
    const isOwner = selectedPage.ownerUid === firebaseUser?.uid;
    const myRole = pageRoles.find((r) => r.uid === firebaseUser?.uid)?.role || (isOwner ? 'owner' : undefined);
    const isStaff = isOwner || Boolean(myRole);
    const isAdminOrOwner = isOwner || myRole === 'admin';
    const isFollowing = followingPageIds.has(selectedPage.id);

    const pageAgeDays = selectedPage.createdAt?.toDate
      ? Math.floor((Date.now() - selectedPage.createdAt.toDate().getTime()) / 86400000)
      : 0;
    const meetsEligibility =
      selectedPage.followersCount >= platformSettings.pageMinFollowers &&
      pageAgeDays >= platformSettings.pageMinAgeDays;

    const totalEngagement = pagePosts.reduce(
      (sum, p) => sum + (p.likesCount || 0) + (p.commentsCount || 0) + (p.sharesCount || 0),
      0
    );

    return (
      <div className="max-w-4xl mx-auto space-y-5">
        <button
          type="button"
          onClick={() => {
            setSelectedPage(null);
            setPageSubTab('posts');
          }}
          className="text-xs font-medium text-[#D4AF37] hover:underline cursor-pointer"
        >
          ← All Public Pages
        </button>

        {/* Page Header */}
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] overflow-hidden">
          <div className="h-44 sm:h-52 bg-[#0A0B0E] relative">
            <img
              src={selectedPage.coverUrl || BRAND_ASSETS.defaultPageCover}
              alt={selectedPage.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="p-5 space-y-4">
            <div className="flex flex-wrap items-end justify-between gap-4 -mt-12 relative z-10">
              <Avatar
                src={selectedPage.avatarUrl}
                name={selectedPage.name}
                size="xl"
                className="ring-4 ring-white dark:ring-[#13151B]"
              />
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    if (!firebaseUser) return;
                    try {
                      await toggleFollow(
                        firebaseUser.uid,
                        selectedPage.id,
                        'page',
                        isFollowing,
                        profile?.displayName || 'Someone'
                      );
                    } catch (err) {
                      pushToast(
                        err instanceof Error ? err.message : 'Could not update follow status.',
                        'error'
                      );
                    }
                  }}
                  className={`h-10 px-4 rounded-xl text-xs font-semibold cursor-pointer ${
                    isFollowing
                      ? 'border border-[#3B82F6] text-[#3B82F6]'
                      : 'bg-[#D4AF37] text-[#0A0B0E]'
                  }`}
                >
                  {isFollowing ? 'Following Page' : 'Follow Page'}
                </button>

                {isAdminOrOwner && (
                  <button
                    type="button"
                    onClick={() => onPromotePage(selectedPage)}
                    className="h-10 inline-flex items-center gap-1.5 px-3.5 rounded-xl bg-[#3B82F6] text-white text-xs font-semibold cursor-pointer"
                  >
                    <Megaphone className="w-3.5 h-3.5" /> Promote Page
                  </button>
                )}

                <button
                  type="button"
                  onClick={async () => {
                    if (!firebaseUser) return;
                    await submitReport({
                      reporterUid: firebaseUser.uid,
                      targetType: 'page',
                      targetId: selectedPage.id,
                      reason: 'Page safety report',
                    });
                    pushToast('Page reported to moderation.', 'info');
                  }}
                  className="h-10 w-10 inline-flex items-center justify-center rounded-xl border border-slate-200 dark:border-white/10 text-slate-400 hover:text-amber-500 cursor-pointer"
                  title="Report Page"
                >
                  <Flag className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display text-xl font-bold">{selectedPage.name}</h1>
                {selectedPage.monetizationStatus === 'approved' && (
                  <CheckCircle2 className="w-4 h-4 text-[#D4AF37]" />
                )}
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                @{selectedPage.username} · {selectedPage.category}
                {selectedPage.country ? ` · ${selectedPage.country}` : ''} ·{' '}
                <span className="font-mono tabular-nums">{selectedPage.followersCount}</span> followers
                {myRole && (
                  <>
                    {' · '}
                    <span className="text-[#D4AF37] font-semibold capitalize">Your role: {myRole}</span>
                  </>
                )}
              </p>
              {selectedPage.description && (
                <p className="text-sm text-slate-600 dark:text-slate-300 mt-2">
                  {selectedPage.description}
                </p>
              )}
            </div>
          </div>

          <div className="px-5 border-t border-slate-200 dark:border-white/10 flex items-center gap-5 overflow-x-auto text-xs font-semibold">
            {[
              { id: 'posts', label: 'Posts & Insights' },
              { id: 'monetization', label: 'Monetization (40/60)' },
              ...(isStaff ? [{ id: 'roles', label: 'Page Roles' }] : []),
              ...(isAdminOrOwner ? [{ id: 'settings', label: 'Page Settings' }] : []),
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setPageSubTab(t.id as typeof pageSubTab)}
                className={`py-3 border-b-2 whitespace-nowrap cursor-pointer ${
                  pageSubTab === t.id
                    ? 'border-[#D4AF37] text-[#D4AF37]'
                    : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Sub-tab: Posts & Insights */}
        {pageSubTab === 'posts' && (
          <div className="space-y-4">
            {isStaff && (
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
                  <span className="font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <BarChart3 className="w-4 h-4 text-[#D4AF37]" /> Page Insights Summary
                  </span>
                  <span>
                    Posts: <strong className="font-mono tabular-nums">{pagePosts.length}</strong> · Followers:{' '}
                    <strong className="font-mono tabular-nums">{selectedPage.followersCount}</strong> · Interactions:{' '}
                    <strong className="font-mono tabular-nums">{totalEngagement}</strong>
                  </span>
                </div>

                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (!firebaseUser?.emailVerified) {
                      pushToast('Verify your email to publish Page posts.', 'error');
                      return;
                    }
                    if (!newPostText.trim() && !newPostMedia) return;
                    setBusyPost(true);
                    const pid = makeSafeId('post');
                    try {
                      await setDoc(doc(db, 'posts', pid), {
                        authorUid: firebaseUser.uid,
                        authorType: 'page',
                        pageId: selectedPage.id,
                        postType: newPostMedia ? newPostKind : 'text',
                        content: newPostText.trim().slice(0, 5000),
                        mediaUrls: newPostMedia ? [newPostMedia] : [],
                        visibility: 'public',
                        likesCount: 0,
                        commentsCount: 0,
                        sharesCount: 0,
                        isBoosted: false,
                        createdAt: serverTimestamp(),
                        updatedAt: serverTimestamp(),
                      });
                      setNewPostText('');
                      setNewPostMedia('');
                      pushToast('Published to Page feed!', 'success');
                    } catch (err) {
                      handleFirestoreError(err, OperationType.CREATE, `posts/${pid}`);
                    } finally {
                      setBusyPost(false);
                    }
                  }}
                  className="space-y-2.5 pt-2 border-t border-slate-100 dark:border-white/5"
                >
                  <textarea
                    rows={2}
                    value={newPostText}
                    onChange={(e) => setNewPostText(e.target.value)}
                    placeholder={`Publish as ${selectedPage.name}...`}
                    className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <MediaUploadInput
                      accept="image/*,video/*"
                      mediaKind="auto"
                      label="Add Photo / Video"
                      value={newPostMedia}
                      onUploaded={(url, kind) => {
                        setNewPostMedia(url);
                        setNewPostKind(kind);
                      }}
                    />
                    <button
                      type="submit"
                      disabled={busyPost || (!newPostText.trim() && !newPostMedia)}
                      className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold disabled:opacity-45 cursor-pointer"
                    >
                      {busyPost ? 'Publishing...' : 'Publish Page Post'}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {pagePosts.map((p) => (
              <PostCard
                key={p.id}
                post={p}
                page={selectedPage}
                canModerate={isAdminOrOwner}
                onOpenProfile={onOpenProfile}
              />
            ))}
            {pagePosts.length === 0 && (
              <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-8 text-center text-xs text-slate-500">
                No Page posts yet.
              </div>
            )}
          </div>
        )}

        {/* Sub-tab: MANDATORY 40/60 PAGE MONETIZATION DASHBOARD */}
        {pageSubTab === 'monetization' && (
          <div className="space-y-4">
            {!isOwner ? (
              <div className="rounded-2xl border border-amber-500/30 bg-white dark:bg-[#13151B] p-6 space-y-3">
                <div className="flex items-center gap-2.5 text-amber-500">
                  <Lock className="w-5 h-5" />
                  <h2 className="font-display font-bold text-base">
                    Page Owner Exclusive Financial Access
                  </h2>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Under HEARTHLINE&apos;s Mandatory 40/60 Beneficiary Policy, the 40% Page Owner share is credited exclusively to the verified Page Owner&apos;s personal Page Earnings Wallet. Page Admins, Editors, and Moderators can manage content and run ad campaigns, but cannot view, redirect, or withdraw Page Owner earnings.
                </p>
              </div>
            ) : (
              <>
                <div className="rounded-2xl border border-[#D4AF37]/30 bg-white dark:bg-[#13151B] p-6 space-y-5">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div>
                      <h2 className="font-display font-bold text-base flex items-center gap-2">
                        <Coins className="w-5 h-5 text-[#D4AF37]" />
                        Page Monetization — Mandatory 40/60 Split
                      </h2>
                      <p className="text-xs text-slate-500 mt-1">
                        Verified Page Owner (<span className="font-mono">{selectedPage.ownerUid.slice(0, 8)}</span>) receives{' '}
                        <strong>{platformSettings.pageOwnerShareBps / 100}%</strong> of eligible net collected Page ad revenue; HEARTHLINE retains{' '}
                        <strong>{platformSettings.platformShareBps / 100}%</strong>.
                      </p>
                    </div>
                    <span className="text-xs font-semibold capitalize text-[#D4AF37]">
                      {selectedPage.monetizationStatus.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Eligibility Progress & Application */}
                  {selectedPage.monetizationStatus !== 'approved' && (
                    <div className="rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] p-4 space-y-3 text-xs">
                      <p className="font-semibold text-slate-900 dark:text-white">Eligibility Progress</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-1.5">
                          <div className="flex justify-between">
                            <span className="text-slate-500">Followers</span>
                            <span className="font-mono tabular-nums font-semibold">
                              {selectedPage.followersCount} / {platformSettings.pageMinFollowers}
                            </span>
                          </div>
                          <div className="h-1.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                            <div
                              className="h-full bg-[#D4AF37]"
                              style={{
                                width: `${Math.min(
                                  100,
                                  platformSettings.pageMinFollowers > 0
                                    ? (selectedPage.followersCount / platformSettings.pageMinFollowers) * 100
                                    : 100
                                )}%`,
                              }}
                            />
                          </div>
                        </div>
                        <div className="space-y-1.5">
                          <div className="flex justify-between">
                            <span className="text-slate-500">Page Age</span>
                            <span className="font-mono tabular-nums font-semibold">
                              {pageAgeDays} / {platformSettings.pageMinAgeDays} days
                            </span>
                          </div>
                          <div className="h-1.5 rounded-full bg-slate-200 dark:bg-white/10 overflow-hidden">
                            <div
                              className="h-full bg-[#3B82F6]"
                              style={{
                                width: `${Math.min(
                                  100,
                                  platformSettings.pageMinAgeDays > 0
                                    ? (pageAgeDays / platformSettings.pageMinAgeDays) * 100
                                    : 100
                                )}%`,
                              }}
                            />
                          </div>
                        </div>
                      </div>

                      {latestMonetizationApp?.status === 'rejected' && (
                        <div className="p-3 rounded-lg border border-rose-500/30 bg-rose-500/10 text-rose-500">
                          Previous application declined
                          {latestMonetizationApp.reviewNote
                            ? `: ${latestMonetizationApp.reviewNote}`
                            : '.'}{' '}
                          You can submit a fresh application once ready.
                        </div>
                      )}

                      {latestMonetizationApp?.status !== 'pending' && (
                        <label className="flex items-start gap-2 text-slate-600 dark:text-slate-300 cursor-pointer pt-1">
                          <input
                            type="checkbox"
                            checked={attestedOriginal}
                            onChange={(e) => setAttestedOriginal(e.target.checked)}
                            className="mt-0.5 accent-[#D4AF37]"
                          />
                          <span>
                            I attest this Page publishes original content compliant with HEARTHLINE policies and accept the mandatory 40% Owner / 60% Platform revenue split.
                          </span>
                        </label>
                      )}

                      <button
                        type="button"
                        disabled={
                          busyApply ||
                          latestMonetizationApp?.status === 'pending' ||
                          !meetsEligibility ||
                          !attestedOriginal
                        }
                        onClick={async () => {
                          if (!firebaseUser?.emailVerified) {
                            pushToast('Verify your email before applying.', 'error');
                            return;
                          }
                          setBusyApply(true);
                          const appId = makeSafeId('pmapp');
                          try {
                            await setDoc(doc(db, 'pageMonetizationApplications', appId), {
                              pageId: selectedPage.id,
                              ownerUid: firebaseUser.uid,
                              followersCount: selectedPage.followersCount,
                              pageAgeDays,
                              originalContentAttested: true,
                              country: selectedPage.country || 'Bangladesh',
                              status: 'pending',
                              createdAt: serverTimestamp(),
                              updatedAt: serverTimestamp(),
                            });
                            pushToast('Monetization application submitted for Admin approval.', 'success');
                          } catch (err) {
                            handleFirestoreError(
                              err,
                              OperationType.CREATE,
                              `pageMonetizationApplications/${appId}`
                            );
                          } finally {
                            setBusyApply(false);
                          }
                        }}
                        className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] font-semibold disabled:opacity-45 cursor-pointer"
                      >
                        {latestMonetizationApp?.status === 'pending'
                          ? 'Application Pending Admin Review'
                          : !meetsEligibility
                          ? 'Meet Thresholds to Apply'
                          : latestMonetizationApp?.status === 'rejected'
                          ? 'Re-apply for Page Monetization'
                          : 'Apply for Page Monetization'}
                      </button>
                    </div>
                  )}

                  {/* 40/60 Verified Revenue Breakdown */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
                      <p className="text-slate-500">Verified Gross Revenue</p>
                      <p className="font-mono tabular-nums font-bold text-base mt-1">
                        {formatBDT(pageWallet?.totalVerifiedGrossPoisha || 0)}
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
                      <p className="text-slate-500">Eligible Net (After Fees)</p>
                      <p className="font-mono tabular-nums font-bold text-base mt-1">
                        {formatBDT(pageWallet?.totalEligibleNetPoisha || 0)}
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl border border-[#D4AF37]/40 bg-[#D4AF37]/10">
                      <p className="text-[#D4AF37] font-semibold">Page Owner 40% Share</p>
                      <p className="font-mono tabular-nums font-bold text-base text-[#D4AF37] mt-1">
                        {formatBDT(pageWallet?.totalOwner40Poisha || 0)}
                      </p>
                    </div>
                    <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E]">
                      <p className="text-slate-500">HEARTHLINE 60% Share</p>
                      <p className="font-mono tabular-nums font-bold text-base mt-1">
                        {formatBDT(pageWallet?.totalPlatform60Poisha || 0)}
                      </p>
                    </div>
                  </div>

                  {/* Owner Wallet Balances */}
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-xs pt-2 border-t border-slate-200 dark:border-white/10">
                    <div>
                      <p className="text-slate-500">Pending</p>
                      <p className="font-mono tabular-nums font-semibold mt-0.5">
                        {formatBDT(pageWallet?.pendingPoisha || 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Available</p>
                      <p className="font-mono tabular-nums font-semibold text-emerald-500 mt-0.5">
                        {formatBDT(pageWallet?.availablePoisha || 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Processing</p>
                      <p className="font-mono tabular-nums font-semibold text-[#3B82F6] mt-0.5">
                        {formatBDT(pageWallet?.processingPoisha || 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Paid</p>
                      <p className="font-mono tabular-nums font-semibold mt-0.5">
                        {formatBDT(pageWallet?.paidPoisha || 0)}
                      </p>
                    </div>
                    <div>
                      <p className="text-slate-500">Reversed</p>
                      <p className="font-mono tabular-nums font-semibold text-rose-500 mt-0.5">
                        {formatBDT(pageWallet?.reversedPoisha || 0)}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    <p className="text-[11px] text-slate-500">
                      Advertiser spend and unspent deposits are never counted as Page earnings.
                    </p>
                    <button
                      type="button"
                      onClick={onOpenWallet}
                      className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer whitespace-nowrap"
                    >
                      Withdraw in Wallet
                    </button>
                  </div>
                </div>

                {/* Immutable Page 40/60 Settlement Ledger */}
                <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-3">
                  <h3 className="font-display font-semibold text-sm">Immutable Page Revenue Ledger</h3>
                  {pageLedger.length === 0 ? (
                    <p className="text-xs text-slate-500">No verified Page revenue settlements recorded yet.</p>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs text-left">
                        <thead className="text-slate-500 border-b border-slate-200 dark:border-white/10">
                          <tr>
                            <th className="py-2 pr-3">Event</th>
                            <th className="py-2 pr-3 text-right">Gross</th>
                            <th className="py-2 pr-3 text-right">Deductions</th>
                            <th className="py-2 pr-3 text-right">Eligible Net</th>
                            <th className="py-2 pr-3 text-right text-[#D4AF37]">Owner 40%</th>
                            <th className="py-2 text-right">Platform 60%</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-white/5 font-mono tabular-nums">
                          {pageLedger.map((e) => (
                            <tr key={e.id}>
                              <td className="py-2.5 pr-3 font-sans capitalize">
                                {e.eventType.replace(/_/g, ' ')}
                              </td>
                              <td className="py-2.5 pr-3 text-right">{formatBDT(e.grossPoisha)}</td>
                              <td className="py-2.5 pr-3 text-right">{formatBDT(e.deductionsPoisha)}</td>
                              <td className="py-2.5 pr-3 text-right">{formatBDT(e.eligibleNetPoisha)}</td>
                              <td className="py-2.5 pr-3 text-right text-[#D4AF37] font-semibold">
                                {formatBDT(e.ownerShare40Poisha)}
                              </td>
                              <td className="py-2.5 text-right">{formatBDT(e.platformShare60Poisha)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        )}

        {/* Sub-tab: Page Roles */}
        {pageSubTab === 'roles' && isStaff && (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4">
            <div>
              <h3 className="font-display font-bold text-base flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#D4AF37]" /> Page Access &amp; Roles
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Owner holds exclusive access to 40% earnings and role assignment · Admin manages settings, ads, and posts · Editor publishes posts · Moderator moderates content.
              </p>
            </div>

            {isOwner && (
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (!firebaseUser) return;
                  const clean = roleUsername.trim().toLowerCase().replace(/^@/, '');
                  if (!clean) return;
                  setBusyRole(true);
                  try {
                    const uSnap = await getDoc(doc(db, 'usernames', clean));
                    if (!uSnap.exists() || uSnap.data().targetType !== 'user') {
                      pushToast('User not found.', 'error');
                      setBusyRole(false);
                      return;
                    }
                    const targetUid = uSnap.data().uid as string;
                    if (targetUid === selectedPage.ownerUid) {
                      pushToast('Page Owner role cannot be changed.', 'error');
                      setBusyRole(false);
                      return;
                    }
                    const existingRole = pageRoles.find((r) => r.uid === targetUid);
                    if (existingRole) {
                      await updateDoc(doc(db, 'pages', selectedPage.id, 'admins', targetUid), {
                        role: roleType,
                        assignedBy: firebaseUser.uid,
                      });
                    } else {
                      await setDoc(doc(db, 'pages', selectedPage.id, 'admins', targetUid), {
                        uid: targetUid,
                        pageId: selectedPage.id,
                        role: roleType,
                        assignedBy: firebaseUser.uid,
                        createdAt: serverTimestamp(),
                      });
                    }
                    await createNotification({
                      recipientUid: targetUid,
                      actorUid: firebaseUser.uid,
                      type: 'page_role',
                      title: 'Page Role Updated',
                      body: `You were assigned as ${roleType} on ${selectedPage.name}.`,
                      targetTab: 'pages',
                    });
                    setRoleUsername('');
                    pushToast(`Assigned @${clean} as Page ${roleType}.`, 'success');
                  } catch (err) {
                    handleFirestoreError(err, OperationType.WRITE, `pages/${selectedPage.id}/admins`);
                  } finally {
                    setBusyRole(false);
                  }
                }}
                className="flex flex-wrap items-center gap-2"
              >
                <input
                  type="text"
                  required
                  value={roleUsername}
                  onChange={(e) => setRoleUsername(e.target.value)}
                  placeholder="Enter @username..."
                  className="flex-1 min-w-[180px] h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
                />
                <select
                  value={roleType}
                  onChange={(e) => setRoleType(e.target.value as Exclude<PageRoleType, 'owner'>)}
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
                >
                  <option value="admin">Page Admin</option>
                  <option value="editor">Editor</option>
                  <option value="moderator">Moderator</option>
                </select>
                <button
                  type="submit"
                  disabled={busyRole}
                  className="h-10 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" /> Assign Role
                </button>
              </form>
            )}

            <div className="divide-y divide-slate-100 dark:divide-white/5">
              {pageRoles.map((r) => {
                const u = usersMap[r.uid];
                return (
                  <div key={r.uid} className="py-3 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => onOpenProfile(r.uid)}
                      className="flex items-center gap-2.5 text-left cursor-pointer"
                    >
                      <Avatar src={u?.photoUrl} name={u?.displayName || r.uid} size="sm" />
                      <div>
                        <p className="font-semibold hover:text-[#D4AF37]">{u?.displayName || r.uid}</p>
                        <p className="text-slate-500">@{u?.username || 'member'}</p>
                      </div>
                    </button>
                    <div className="flex items-center gap-2">
                      {isOwner && r.role !== 'owner' ? (
                        <>
                          <select
                            value={r.role}
                            onChange={async (e) => {
                              const nextRole = e.target.value as Exclude<PageRoleType, 'owner'>;
                              try {
                                await updateDoc(doc(db, 'pages', selectedPage.id, 'admins', r.uid), {
                                  role: nextRole,
                                  assignedBy: firebaseUser!.uid,
                                });
                                pushToast(`Updated role to ${nextRole}.`, 'success');
                              } catch (err) {
                                handleFirestoreError(
                                  err,
                                  OperationType.UPDATE,
                                  `pages/${selectedPage.id}/admins/${r.uid}`
                                );
                              }
                            }}
                            className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs capitalize"
                          >
                            <option value="admin">Admin</option>
                            <option value="editor">Editor</option>
                            <option value="moderator">Moderator</option>
                          </select>
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                await deleteDoc(doc(db, 'pages', selectedPage.id, 'admins', r.uid));
                                pushToast('Role removed.', 'info');
                              } catch (err) {
                                handleFirestoreError(
                                  err,
                                  OperationType.DELETE,
                                  `pages/${selectedPage.id}/admins/${r.uid}`
                                );
                              }
                            }}
                            className="w-9 h-9 inline-flex items-center justify-center rounded-lg text-rose-500 hover:bg-rose-500/10 cursor-pointer"
                            title="Remove staff role"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </>
                      ) : (
                        <span className="capitalize font-semibold text-[#D4AF37]">{r.role}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Sub-tab: Settings */}
        {pageSubTab === 'settings' && isAdminOrOwner && (
          <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-6 space-y-4">
            <h3 className="font-display font-bold text-base flex items-center gap-2">
              <Settings className="w-5 h-5 text-[#D4AF37]" /> Page Settings
            </h3>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (editName.trim().length < 2) {
                  pushToast('Page name must be at least 2 characters.', 'error');
                  return;
                }
                setBusySettings(true);
                try {
                  await updateDoc(doc(db, 'pages', selectedPage.id), {
                    name: editName.trim().slice(0, 100),
                    category: editCategory.trim().slice(0, 60) || selectedPage.category,
                    description: editDesc.trim().slice(0, 1000),
                    country: editCountry.trim().slice(0, 60),
                    avatarUrl: editAvatar,
                    coverUrl: editCover || BRAND_ASSETS.defaultPageCover,
                    updatedAt: serverTimestamp(),
                  });
                  pushToast('Page settings saved.', 'success');
                } catch (err) {
                  handleFirestoreError(err, OperationType.UPDATE, `pages/${selectedPage.id}`);
                } finally {
                  setBusySettings(false);
                }
              }}
              className="space-y-3"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-500 mb-1">Page Name</label>
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-500 mb-1">Category</label>
                  <select
                    value={PAGE_CATEGORIES.includes(editCategory) ? editCategory : 'Media & Entertainment'}
                    onChange={(e) => setEditCategory(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
                  >
                    {PAGE_CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Country</label>
                <input
                  type="text"
                  value={editCountry}
                  onChange={(e) => setEditCountry(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={editDesc}
                  onChange={(e) => setEditDesc(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
                />
              </div>
              <MediaUploadInput
                accept="image/*"
                mediaKind="image"
                label="Update Page Logo"
                value={editAvatar}
                onUploaded={(url) => setEditAvatar(url)}
              />
              <MediaUploadInput
                accept="image/*"
                mediaKind="image"
                label="Update Page Cover"
                value={editCover}
                onUploaded={(url) => setEditCover(url)}
              />
              <button
                type="submit"
                disabled={busySettings}
                className="h-10 px-5 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
              >
                {busySettings ? 'Saving...' : 'Save Page Info'}
              </button>
            </form>
          </div>
        )}
      </div>
    );
  }

  const filteredPages = pages.filter((pg) => {
    if (directoryFilter === 'mine' && !myRoleByPage[pg.id]) return false;
    if (directoryFilter === 'following' && !followingPageIds.has(pg.id)) return false;
    const q = searchText.trim().toLowerCase();
    if (!q) return true;
    return (
      pg.name.toLowerCase().includes(q) ||
      pg.username.toLowerCase().includes(q) ||
      pg.category.toLowerCase().includes(q)
    );
  });

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-xl font-bold">Public Pages</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Create brand or creator Pages with 40/60 owner-only revenue monetization.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowCreate(true)}
          className="h-10 inline-flex items-center gap-1.5 px-4 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
        >
          <Plus className="w-4 h-4" /> Create Page
        </button>
      </div>

      {/* Directory Search & Filter */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-white dark:bg-[#13151B] border border-slate-200 dark:border-white/10 p-1 rounded-xl text-xs font-semibold">
          {(
            [
              ['all', 'All Pages'],
              ['mine', 'My Pages'],
              ['following', 'Following'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setDirectoryFilter(id)}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                directoryFilter === id
                  ? 'bg-[#D4AF37] text-[#0A0B0E]'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="relative flex-1 min-w-[200px] max-w-xs">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            placeholder="Search pages..."
            className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] text-xs"
          />
        </div>
      </div>

      {filteredPages.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] p-10 text-center space-y-3">
          <Flag className="w-8 h-8 text-[#D4AF37] mx-auto" />
          <p className="text-sm font-semibold">No matching Public Pages</p>
          <p className="text-xs text-slate-500">
            Launch your first Public Page with a unique username and 40/60 owner wallet.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredPages.map((pg) => {
            const role = myRoleByPage[pg.id];
            return (
              <button
                key={pg.id}
                type="button"
                onClick={() => setSelectedPage(pg)}
                className="text-left rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#13151B] overflow-hidden hover:border-[#D4AF37]/60 transition-colors cursor-pointer"
              >
                <div className="h-28 bg-[#0A0B0E]">
                  <img
                    src={pg.coverUrl || BRAND_ASSETS.defaultPageCover}
                    alt={pg.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-4 flex items-center gap-3">
                  <Avatar src={pg.avatarUrl} name={pg.name} size="md" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-display font-bold text-sm truncate">{pg.name}</h3>
                      {pg.monetizationStatus === 'approved' && (
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-slate-500 truncate">
                      @{pg.username} · {pg.category} ·{' '}
                      <span className="font-mono tabular-nums">{pg.followersCount}</span> followers
                      {role ? ` · ${role}` : ''}
                    </p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="max-w-md w-full rounded-2xl border border-white/10 bg-white dark:bg-[#13151B] p-5 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base">Create Public Page</h3>
              <button type="button" onClick={() => setShowCreate(false)} className="cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreatePage} className="space-y-3">
              <input
                type="text"
                required
                value={pName}
                onChange={(e) => setPName(e.target.value)}
                placeholder="Page Name (e.g. Dhaka Creative Studio)"
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
              />
              <input
                type="text"
                required
                value={pUsername}
                onChange={(e) => setPUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                placeholder="Unique Page username (e.g. dhakacreative)"
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
              />
              <select
                value={pCategory}
                onChange={(e) => setPCategory(e.target.value)}
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
              >
                {PAGE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <textarea
                rows={3}
                value={pDesc}
                onChange={(e) => setPDesc(e.target.value)}
                placeholder="Describe what your Page publishes..."
                className="w-full p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-sm"
              />
              <input
                type="text"
                value={pCountry}
                onChange={(e) => setPCountry(e.target.value)}
                placeholder="Country (e.g. Bangladesh)"
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#0A0B0E] text-xs"
              />
              <MediaUploadInput
                accept="image/*"
                mediaKind="image"
                label="Upload Page Logo"
                value={pAvatar}
                onUploaded={(url) => setPAvatar(url)}
              />
              <MediaUploadInput
                accept="image/*"
                mediaKind="image"
                label="Upload Page Cover"
                value={pCover}
                onUploaded={(url) => setPCover(url)}
              />
              <button
                type="submit"
                disabled={busyCreate}
                className="w-full h-10 rounded-xl bg-[#D4AF37] text-[#0A0B0E] text-xs font-semibold cursor-pointer"
              >
                {busyCreate ? 'Creating...' : 'Create Public Page'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
