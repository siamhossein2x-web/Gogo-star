import React, { useState } from 'react';

interface AvatarProps {
  src?: string;
  name: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const SIZE_MAP = {
  xs: 'w-7 h-7 text-[11px]',
  sm: 'w-9 h-9 text-xs',
  md: 'w-11 h-11 text-sm',
  lg: 'w-16 h-16 text-lg',
  xl: 'w-24 h-24 text-2xl',
};

export const Avatar: React.FC<AvatarProps> = ({ src, name, size = 'md', className = '' }) => {
  const [failed, setFailed] = useState(false);
  const initials = (name || 'H')
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() || '')
    .join('');

  if (src && !failed) {
    return (
      <img
        src={src}
        alt={name}
        referrerPolicy="no-referrer"
        onError={() => setFailed(true)}
        className={`${SIZE_MAP[size]} rounded-full object-cover border border-slate-200 dark:border-white/10 shrink-0 ${className}`}
      />
    );
  }

  return (
    <div
      className={`${SIZE_MAP[size]} rounded-full bg-gradient-to-br from-[#D4AF37]/30 via-[#1E222D] to-[#3B82F6]/30 border border-[#D4AF37]/30 flex items-center justify-center font-semibold text-[#D4AF37] shrink-0 select-none ${className}`}
      aria-label={name}
    >
      {initials || 'H'}
    </div>
  );
};
